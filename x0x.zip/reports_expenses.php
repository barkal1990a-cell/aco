<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// إجمالي المبيعات
$stmt_sales = $pdo->prepare("SELECT SUM(total_amount) AS total_sales FROM invoices WHERE DATE(created_at) BETWEEN ? AND ?");
$stmt_sales->execute([$start_date, $end_date]);
$total_sales = $stmt_sales->fetchColumn() ?: 0;

// إجمالي المشتريات
$stmt_purchases = $pdo->prepare("SELECT SUM(total_amount) AS total_purchases FROM purchase_invoices WHERE DATE(created_at) BETWEEN ? AND ?");
$stmt_purchases->execute([$start_date, $end_date]);
$total_purchases = $stmt_purchases->fetchColumn() ?: 0;

// إجمالي المصاريف التشغيلية
$stmt_exp = $pdo->prepare("SELECT SUM(amount) AS total_expenses FROM expenses WHERE DATE(created_at) BETWEEN ? AND ?");
$stmt_exp->execute([$start_date, $end_date]);
$total_expenses = $stmt_exp->fetchColumn() ?: 0;

// قائمة المصاريف التفصيلية
$stmt_list = $pdo->prepare("SELECT * FROM expenses WHERE DATE(created_at) BETWEEN ? AND ? ORDER BY created_at DESC");
$stmt_list->execute([$start_date, $end_date]);
$expenses_list = $stmt_list->fetchAll();

$net_profit = $total_sales - $total_purchases - $total_expenses;
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-calculator me-2"></i>تقرير المصاريف والأرباح</h2>
        <a href="reports.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-right me-1"></i> العودة للتقارير</a>
    </div>

    <!-- تصفية حسب التاريخ -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">من تاريخ</label>
                    <input type="date" name="start_date" class="form-control" value="<?= htmlspecialchars($start_date) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">إلى تاريخ</label>
                    <input type="date" name="end_date" class="form-control" value="<?= htmlspecialchars($end_date) ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-filter me-1"></i> تطبيق الفلتر</button>
                </div>
            </form>
        </div>
    </div>

    <!-- بطاقات الملخص -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white p-3 text-center">
                <h6>إجمالي المبيعات</h6>
                <h4><?= number_format($total_sales, 2) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white p-3 text-center">
                <h6>إجمالي المشتريات</h6>
                <h4><?= number_format($total_purchases, 2) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white p-3 text-center">
                <h6>المصاريف التشغيلية</h6>
                <h4><?= number_format($total_expenses, 2) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card <?= $net_profit >= 0 ? 'bg-success' : 'bg-warning text-dark' ?> text-white p-3 text-center">
                <h6>صافي الربح</h6>
                <h4><?= number_format($net_profit, 2) ?></h4>
            </div>
        </div>
    </div>

    <!-- جدول المصاريف -->
    <div class="card shadow-sm">
        <div class="card-header bg-white py-3">
            <h5 class="mb-0">سجل المصاريف خلال الفترة</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>البيان / الوصف</th>
                            <th>المبلغ</th>
                            <th>التاريخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($expenses_list)): ?>
                            <tr><td colspan="4" class="text-center py-3 text-muted">لا توجد مصاريف مسجلة خلال الفترة المحددة</td></tr>
                        <?php else: ?>
                            <?php foreach ($expenses_list as $index => $exp): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= htmlspecialchars($exp['title'] ?? $exp['notes'] ?? 'مصروف') ?></td>
                                    <td class="text-danger fw-bold"><?= number_format($exp['amount'], 2) ?></td>
                                    <td><?= date('Y-m-d H:i', strtotime($exp['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>