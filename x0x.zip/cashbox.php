<?php
require_once 'config/database.php';
require_once 'includes/header.php';

/*
|--------------------------------------------------------------------------
| إنشاء جدول الأرصدة الشهرية للصندوق
|--------------------------------------------------------------------------
*/
$pdo->exec("
    CREATE TABLE IF NOT EXISTS cashbox_monthly_balances (
        id INT AUTO_INCREMENT PRIMARY KEY,
        balance_year INT NOT NULL,
        balance_month INT NOT NULL,
        opening_balance DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ON UPDATE CURRENT_TIMESTAMP,

        UNIQUE KEY unique_cashbox_month (
            balance_year,
            balance_month
        )
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

/*
|--------------------------------------------------------------------------
| أسماء الأشهر العربية
|--------------------------------------------------------------------------
*/
$arabicMonths = [
    1  => 'كانون الثاني',
    2  => 'شباط',
    3  => 'آذار',
    4  => 'نيسان',
    5  => 'أيار',
    6  => 'حزيران',
    7  => 'تموز',
    8  => 'آب',
    9  => 'أيلول',
    10 => 'تشرين الأول',
    11 => 'تشرين الثاني',
    12 => 'كانون الأول'
];

/*
|--------------------------------------------------------------------------
| تحديد الشهر والسنة المعروضين
|--------------------------------------------------------------------------
*/
$selectedMonth = isset($_GET['month'])
    ? (int)$_GET['month']
    : (int)date('n');

$selectedYear = isset($_GET['year'])
    ? (int)$_GET['year']
    : (int)date('Y');

if ($selectedMonth < 1 || $selectedMonth > 12) {
    $selectedMonth = (int)date('n');
}

if ($selectedYear < 2000 || $selectedYear > 2100) {
    $selectedYear = (int)date('Y');
}

$selectedMonthName = $arabicMonths[$selectedMonth];

$currentPageUrl = 'cashbox.php?month='
    . $selectedMonth
    . '&year='
    . $selectedYear;

/*
|--------------------------------------------------------------------------
| دالة الرصيد الافتتاحي الشهري
|--------------------------------------------------------------------------
*/
function getCashboxMonthlyOpeningBalance(
    PDO $pdo,
    int $year,
    int $month
): float {
    $currentStmt = $pdo->prepare("
        SELECT opening_balance
        FROM cashbox_monthly_balances
        WHERE balance_year = ?
          AND balance_month = ?
        LIMIT 1
    ");

    $currentStmt->execute([
        $year,
        $month
    ]);

    $savedOpeningBalance = $currentStmt->fetchColumn();

    if ($savedOpeningBalance !== false) {
        return (float)$savedOpeningBalance;
    }

    $currentDate = new DateTime(
        sprintf('%04d-%02d-01', $year, $month)
    );

    $currentDate->modify('-1 month');

    $previousYear = (int)$currentDate->format('Y');
    $previousMonth = (int)$currentDate->format('n');

    $previousOpeningStmt = $pdo->prepare("
        SELECT opening_balance
        FROM cashbox_monthly_balances
        WHERE balance_year = ?
          AND balance_month = ?
        LIMIT 1
    ");

    $previousOpeningStmt->execute([
        $previousYear,
        $previousMonth
    ]);

    $previousOpeningValue = $previousOpeningStmt->fetchColumn();

    $previousOpeningBalance = $previousOpeningValue !== false
        ? (float)$previousOpeningValue
        : 0.00;

    $previousInStmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount), 0)
        FROM cashbox
        WHERE type = 'in'
          AND YEAR(created_at) = ?
          AND MONTH(created_at) = ?
    ");

    $previousInStmt->execute([
        $previousYear,
        $previousMonth
    ]);

    $previousIn = (float)$previousInStmt->fetchColumn();

    $previousOutStmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount), 0)
        FROM cashbox
        WHERE type = 'out'
          AND YEAR(created_at) = ?
          AND MONTH(created_at) = ?
    ");

    $previousOutStmt->execute([
        $previousYear,
        $previousMonth
    ]);

    $previousOut = (float)$previousOutStmt->fetchColumn();

    $openingBalance = $previousOpeningBalance
        + $previousIn
        - $previousOut;

    $saveOpeningStmt = $pdo->prepare("
        INSERT INTO cashbox_monthly_balances (
            balance_year,
            balance_month,
            opening_balance
        ) VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE
            opening_balance = opening_balance
    ");

    $saveOpeningStmt->execute([
        $year,
        $month,
        $openingBalance
    ]);

    return $openingBalance;
}

/*
|--------------------------------------------------------------------------
| دوال عرض الرصيد
|--------------------------------------------------------------------------
*/
function customerBalanceLabel(PDO $pdo, float $balance): string
{
    $balance = round($balance, 2);
    if ($balance > 0) {
        return 'على الزبون: '
            . format_money($pdo, $balance);
    }

    if ($balance < 0) {
        return 'للزبون رصيد: '
            . format_money($pdo, abs($balance));
    }

    return 'لا يوجد رصيد';
}

function supplierBalanceLabel(PDO $pdo, float $balance): string
{
    $balance = round($balance, 2);
    if ($balance > 0) {
        return 'للمورد: '
            . format_money($pdo, $balance);
    }

    if ($balance < 0) {
        return 'لنا عند المورد: '
            . format_money($pdo, abs($balance));
    }

    return 'لا يوجد رصيد';
}

/*
|--------------------------------------------------------------------------
| معالجة الطلبات
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
     * استلام دفعة من زبون أو إيداع نقدي عادي.
     */
    if (isset($_POST['add_cash_entry'])) {
        $entryMode = $_POST['entry_mode'] ?? 'normal';

        $amount = round(
            max(0, (float)($_POST['amount'] ?? 0)),
            2
        );

        $description = trim($_POST['description'] ?? '');

        $customerId = !empty($_POST['customer_id'])
            ? (int)$_POST['customer_id']
            : 0;

        if ($amount <= 0) {
            set_flash(
                'error',
                'يرجى إدخال مبلغ صحيح أكبر من الصفر.'
            );

            redirect($currentPageUrl);
        }

        $pdo->beginTransaction();

        try {
            if ($entryMode === 'customer_payment') {
                if ($customerId <= 0) {
                    throw new Exception(
                        'يرجى اختيار الزبون قبل تسجيل الدفعة.'
                    );
                }

                $customerStmt = $pdo->prepare("
                    SELECT
                        id,
                        name,
                        balance
                    FROM customers
                    WHERE id = ?
                    LIMIT 1
                    FOR UPDATE
                ");

                $customerStmt->execute([
                    $customerId
                ]);

                $customer = $customerStmt->fetch(PDO::FETCH_ASSOC);

                if (!$customer) {
                    throw new Exception(
                        'الزبون المحدد غير موجود.'
                    );
                }

                $customerBalance = round(
                    (float)$customer['balance'],
                    2
                );

                /*
                 * السماح بالدفع الزائد:
                 * الموجب = الزبون عليه دين.
                 * السالب = للزبون رصيد عند المحل.
                 */
                $remainingCustomerBalance = round(
                    $customerBalance - $amount,
                    2
                );

                $customerCredit = $remainingCustomerBalance < 0
                    ? abs($remainingCustomerBalance)
                    : 0;

                $updateCustomerStmt = $pdo->prepare("
                    UPDATE customers
                    SET balance = ?
                    WHERE id = ?
                ");

                $updateCustomerStmt->execute([
                    $remainingCustomerBalance,
                    $customerId
                ]);

                $cashDescription =
                    'استلام دفعة من الزبون: '
                    . $customer['name'];

                if ($description !== '') {
                    $cashDescription .= ' - ' . $description;
                }

                $insertCashStmt = $pdo->prepare("
                    INSERT INTO cashbox (
                        type,
                        reference_id,
                        amount,
                        description
                    ) VALUES ('in', ?, ?, ?)
                ");

                $insertCashStmt->execute([
                    $customerId,
                    $amount,
                    $cashDescription
                ]);

                $pdo->commit();

                if ($customerCredit > 0) {
                    set_flash(
                        'success',
                        'تم استلام الدفعة وإضافتها إلى الصندوق. '
                        . 'للزبون رصيد دائن بقيمة: '
                        . format_money($pdo, $customerCredit)
                        . ' ويُخصم من مشترياته القادمة.'
                    );
                } else {
                    set_flash(
                        'success',
                        'تم استلام دفعة الزبون وإضافتها إلى الصندوق بنجاح.'
                    );
                }
            } else {
                $cashDescription = $description !== ''
                    ? $description
                    : 'إيداع نقدي عادي';

                $insertCashStmt = $pdo->prepare("
                    INSERT INTO cashbox (
                        type,
                        reference_id,
                        amount,
                        description
                    ) VALUES ('in', ?, ?, ?)
                ");

                $insertCashStmt->execute([
                    0,
                    $amount,
                    $cashDescription
                ]);

                $pdo->commit();

                set_flash(
                    'success',
                    'تمت إضافة الإيداع إلى الصندوق بنجاح.'
                );
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            set_flash(
                'error',
                'فشل حفظ الحركة: ' . $e->getMessage()
            );
        }

        redirect($currentPageUrl);
    }

    /*
     * دفع دفعة لمورد.
     */
    if (isset($_POST['supplier_payment'])) {
        $supplierId = (int)($_POST['supplier_id'] ?? 0);

        $amount = round(
            max(0, (float)($_POST['amount'] ?? 0)),
            2
        );

        $description = trim($_POST['description'] ?? '');

        if ($supplierId <= 0 || $amount <= 0) {
            set_flash(
                'error',
                'يرجى اختيار المورد وإدخال مبلغ صحيح أكبر من الصفر.'
            );

            redirect($currentPageUrl);
        }

        $pdo->beginTransaction();

        try {
            $supplierStmt = $pdo->prepare("
                SELECT
                    id,
                    name,
                    balance
                FROM suppliers
                WHERE id = ?
                LIMIT 1
                FOR UPDATE
            ");

            $supplierStmt->execute([
                $supplierId
            ]);

            $supplier = $supplierStmt->fetch(PDO::FETCH_ASSOC);

            if (!$supplier) {
                throw new Exception(
                    'المورد المحدد غير موجود.'
                );
            }

            $supplierBalance = round(
                (float)$supplier['balance'],
                2
            );

            /*
             * السماح بالدفع الزائد:
             * الموجب = للمورد مبلغ مستحق.
             * السالب = لنا رصيد عند المورد.
             */
            $remainingSupplierBalance = round(
                $supplierBalance - $amount,
                2
            );

            $supplierCredit = $remainingSupplierBalance < 0
                ? abs($remainingSupplierBalance)
                : 0;

            $updateSupplierStmt = $pdo->prepare("
                UPDATE suppliers
                SET balance = ?
                WHERE id = ?
            ");

            $updateSupplierStmt->execute([
                $remainingSupplierBalance,
                $supplierId
            ]);

            $cashDescription =
                'دفع دفعة للمورد: '
                . $supplier['name'];

            if ($description !== '') {
                $cashDescription .= ' - ' . $description;
            }

            $insertCashStmt = $pdo->prepare("
                INSERT INTO cashbox (
                    type,
                    reference_id,
                    amount,
                    description
                ) VALUES ('out', ?, ?, ?)
            ");

            $insertCashStmt->execute([
                $supplierId,
                $amount,
                $cashDescription
            ]);

            $pdo->commit();

            if ($supplierCredit > 0) {
                set_flash(
                    'success',
                    'تم دفع المبلغ وخصمه من الصندوق. '
                    . 'أصبح للمحل رصيد لدى المورد بقيمة: '
                    . format_money($pdo, $supplierCredit)
                    . ' ويُخصم من الفواتير القادمة.'
                );
            } else {
                set_flash(
                    'success',
                    'تم دفع الدفعة للمورد وخصمها من الصندوق بنجاح.'
                );
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            set_flash(
                'error',
                'فشل تسجيل دفعة المورد: ' . $e->getMessage()
            );
        }

        redirect($currentPageUrl);
    }
}

/*
|--------------------------------------------------------------------------
| التأكد من وجود عمود رصيد المورد
|--------------------------------------------------------------------------
*/
$supplierBalanceColumn = $pdo->query("
    SHOW COLUMNS FROM suppliers LIKE 'balance'
");

if ($supplierBalanceColumn->rowCount() === 0) {
    $pdo->exec("
        ALTER TABLE suppliers
        ADD COLUMN balance DECIMAL(12,2) NOT NULL DEFAULT 0.00
    ");
}

/*
|--------------------------------------------------------------------------
| الزبائن
|--------------------------------------------------------------------------
*/
$customers = $pdo->query("
    SELECT
        id,
        name,
        phone,
        balance
    FROM customers
    ORDER BY name ASC
")->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| الرصيد الافتتاحي للشهر
|--------------------------------------------------------------------------
*/
$openingBalance = getCashboxMonthlyOpeningBalance(
    $pdo,
    $selectedYear,
    $selectedMonth
);

/*
|--------------------------------------------------------------------------
| حركات الشهر المحدد
|--------------------------------------------------------------------------
*/
$rowsStmt = $pdo->prepare("
    SELECT
        id,
        type,
        reference_id,
        amount,
        description,
        created_at
    FROM cashbox
    WHERE YEAR(created_at) = ?
      AND MONTH(created_at) = ?
    ORDER BY created_at DESC, id DESC
");

$rowsStmt->execute([
    $selectedYear,
    $selectedMonth
]);

$rows = $rowsStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| المقبوضات والمدفوعات للشهر
|--------------------------------------------------------------------------
*/
$inStmt = $pdo->prepare("
    SELECT COALESCE(SUM(amount), 0)
    FROM cashbox
    WHERE type = 'in'
      AND YEAR(created_at) = ?
      AND MONTH(created_at) = ?
");

$inStmt->execute([
    $selectedYear,
    $selectedMonth
]);

$in = (float)$inStmt->fetchColumn();

$outStmt = $pdo->prepare("
    SELECT COALESCE(SUM(amount), 0)
    FROM cashbox
    WHERE type = 'out'
      AND YEAR(created_at) = ?
      AND MONTH(created_at) = ?
");

$outStmt->execute([
    $selectedYear,
    $selectedMonth
]);

$out = (float)$outStmt->fetchColumn();

$balance = $openingBalance + $in - $out;

/*
|--------------------------------------------------------------------------
| أرصدة الزبائن
|--------------------------------------------------------------------------
*/
$totalCustomerDebts = (float)$pdo->query("
    SELECT COALESCE(SUM(balance), 0)
    FROM customers
    WHERE ROUND(balance, 2) > 0
")->fetchColumn();

$totalCustomerCredits = (float)$pdo->query("
    SELECT COALESCE(SUM(ABS(balance)), 0)
    FROM customers
    WHERE ROUND(balance, 2) < 0
")->fetchColumn();

$customersWithBalances = $pdo->query("
    SELECT
        id,
        name,
        phone,
        balance
    FROM customers
    WHERE ROUND(balance, 2) != 0
    ORDER BY balance DESC, name ASC
")->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| أرصدة الموردين
|--------------------------------------------------------------------------
*/
$totalSupplierPayables = (float)$pdo->query("
    SELECT COALESCE(SUM(balance), 0)
    FROM suppliers
    WHERE ROUND(balance, 2) > 0
")->fetchColumn();

$totalSupplierCredits = (float)$pdo->query("
    SELECT COALESCE(SUM(ABS(balance)), 0)
    FROM suppliers
    WHERE ROUND(balance, 2) < 0
")->fetchColumn();

$suppliersWithBalances = $pdo->query("
    SELECT
        id,
        name,
        phone,
        balance
    FROM suppliers
    WHERE ROUND(balance, 2) != 0
    ORDER BY balance DESC, name ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.stat-card {
    background: #ffffff;
    padding: 1.25rem;
    border-radius: 10px;
    border: 1px solid #eef2f5;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

.stat-label {
    display: block;
    font-size: 0.85rem;
    color: #6c757d;
    margin-bottom: 0.35rem;
}

.stat-value {
    font-size: 1.35rem;
    font-weight: 700;
    color: #2d3748;
}

.success-text { color: #10b981; }
.danger-text { color: #ef4444; }
.primary-text { color: #3b82f6; }
.warning-text { color: #d97706; }

.card {
    background: #ffffff;
    border-radius: 10px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    margin-bottom: 1.5rem;
    overflow: hidden;
}

.card-header {
    padding: 1rem 1.25rem;
    border-bottom: 1px solid #e2e8f0;
    background-color: #f8fafc;
}

.card-body {
    padding: 1.25rem;
}

.card-title {
    margin: 0;
    font-size: 1.15rem;
    color: #2d3748;
    font-weight: 700;
}

.flex-between {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.75rem;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    align-items: end;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 0.35rem;
}

.form-group label {
    font-size: 0.875rem;
    font-weight: 600;
    color: #4a5568;
}

.form-group input,
.form-group select,
.form-control-sm {
    padding: 0.55rem 0.75rem;
    border: 1px solid #cbd5e0;
    border-radius: 6px;
    font-size: 0.9rem;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
    width: 100%;
    box-sizing: border-box;
    background-color: #ffffff;
}

.form-group input:focus,
.form-group select:focus,
.form-control-sm:focus {
    border-color: #3182ce;
    box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.15);
}

.btn {
    padding: 0.55rem 1rem;
    border-radius: 6px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid transparent;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease-in-out;
}

.btn-success {
    background-color: #10b981;
    color: #ffffff;
}

.btn-success:hover {
    background-color: #059669;
}

.btn-primary {
    background-color: #3b82f6;
    color: #ffffff;
}

.btn-primary:hover {
    background-color: #2563eb;
}

.btn-warning {
    background-color: #d97706;
    color: #ffffff;
}

.btn-warning:hover {
    background-color: #b45309;
}

.btn-secondary {
    background-color: #64748b;
    color: #ffffff;
}

.btn-secondary:hover {
    background-color: #475569;
}

.table-responsive {
    overflow-x: auto;
}

.table {
    width: 100%;
    border-collapse: collapse;
    text-align: right;
}

.table th,
.table td {
    padding: 0.85rem 1rem;
    border-bottom: 1px solid #e2e8f0;
    font-size: 0.9rem;
}

.table th {
    background-color: #f7fafc;
    color: #4a5568;
    font-weight: 600;
}

.table-hover tbody tr:hover {
    background-color: #f8fafc;
}

.badge-id {
    background: #edf2f7;
    color: #4a5568;
    padding: 0.2rem 0.5rem;
    border-radius: 6px;
    font-size: 0.8rem;
    font-weight: 600;
}

.badge {
    padding: 0.25rem 0.6rem;
    border-radius: 20px;
    font-size: 0.78rem;
    font-weight: 700;
    display: inline-block;
}

.badge-in {
    background-color: #d1fae5;
    color: #065f46;
}

.badge-out {
    background-color: #fee2e2;
    color: #991b1b;
}

.badge-debt {
    background-color: #fef3c7;
    color: #92400e;
}

.badge-payable {
    background-color: #fee2e2;
    color: #991b1b;
}

.badge-credit {
    background-color: #d1fae5;
    color: #065f46;
}

.empty-state {
    padding: 2.5rem;
    color: #a0aec0;
    text-align: center;
    font-size: 0.95rem;
}

.font-weight-bold {
    font-weight: 600;
}

.text-muted {
    color: #718096;
    font-size: 0.85rem;
}

.debts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
    gap: 1.5rem;
    margin-bottom: 1.5rem;
}

.debt-card-header {
    padding: 1rem 1.25rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 0.75rem;
    flex-wrap: wrap;
}

.debt-card-header.customer {
    background: #fffbeb;
    border-bottom: 1px solid #fde68a;
}

.debt-card-header.supplier {
    background: #fef2f2;
    border-bottom: 1px solid #fecaca;
}

.debt-list {
    max-height: 340px;
    overflow-y: auto;
}

.debt-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.85rem 1.25rem;
    border-bottom: 1px solid #f1f5f9;
    gap: 1rem;
}

.debt-row:last-child {
    border-bottom: none;
}

.debt-row:hover {
    background: #f8fafc;
}

.debt-name {
    font-weight: 700;
    color: #334155;
}

.debt-phone {
    font-size: 0.78rem;
    color: #94a3b8;
    margin-top: 0.15rem;
}

.debt-amount {
    white-space: nowrap;
    font-weight: 700;
    font-size: 0.84rem;
}

.debt-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    justify-content: flex-end;
}

.no-debts {
    padding: 2rem 1.25rem;
    text-align: center;
    color: #94a3b8;
    font-size: 0.9rem;
}

.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    inset: 0;
    background: rgba(15, 23, 42, 0.45);
    overflow-y: auto;
    padding: 20px;
}

.modal-content {
    width: min(100%, 460px);
    margin: 8vh auto;
    background: #ffffff;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 20px 45px rgba(0,0,0,0.2);
}

.modal-title {
    margin: 0 0 0.4rem;
    font-size: 1.15rem;
    color: #1e293b;
    font-weight: 700;
}

.modal-subtitle {
    margin: 0 0 1.25rem;
    font-size: 0.85rem;
    color: #64748b;
}

.payment-summary {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.75rem;
    margin-bottom: 1rem;
}

.payment-box {
    border: 1px solid #e2e8f0;
    padding: 0.75rem;
    border-radius: 8px;
    background: #f8fafc;
}

.payment-box-label {
    display: block;
    font-size: 0.75rem;
    color: #64748b;
    margin-bottom: 0.25rem;
}

.payment-box-value {
    font-size: 0.9rem;
    font-weight: 700;
    line-height: 1.5;
}

.payment-actions {
    display: flex;
    gap: 0.75rem;
    justify-content: flex-end;
    margin-top: 1.25rem;
}

.month-filter-form {
    display: flex;
    align-items: end;
    gap: 8px;
    flex-wrap: wrap;
}

.month-filter-form .form-group {
    margin: 0;
}

@media (max-width: 600px) {
    .debts-grid {
        grid-template-columns: 1fr;
    }

    .debt-row {
        align-items: flex-start;
        flex-direction: column;
    }

    .debt-actions {
        justify-content: flex-start;
    }

    .payment-summary {
        grid-template-columns: 1fr;
    }

    .payment-actions {
        flex-direction: column;
    }

    .payment-actions .btn {
        width: 100%;
    }

    .month-filter-form {
        width: 100%;
    }

    .month-filter-form .form-group,
    .month-filter-form .btn {
        width: 100%;
    }
}
</style>

<div class="card">
    <div class="card-header flex-between">
        <div>
            <h2 class="card-title">
                كشف صندوق شهر
                <?= e($selectedMonthName) ?>
                <?= e((string)$selectedYear) ?>
            </h2>

            <div class="text-muted" style="margin-top:4px;">
                يتم ترحيل رصيد نهاية الشهر السابق تلقائيًا كرصد افتتاحي للشهر المحدد.
            </div>
        </div>

        <form method="get" class="month-filter-form">
            <div class="form-group" style="min-width:150px;">
                <label for="month">الشهر</label>

                <select id="month" name="month">
                    <?php foreach ($arabicMonths as $monthNumber => $monthName): ?>
                        <option
                            value="<?= e((string)$monthNumber) ?>"
                            <?= $selectedMonth === $monthNumber ? 'selected' : '' ?>
                        >
                            <?= e($monthName) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group" style="min-width:120px;">
                <label for="year">السنة</label>

                <input
                    type="number"
                    id="year"
                    name="year"
                    min="2000"
                    max="2100"
                    value="<?= e((string)$selectedYear) ?>"
                >
            </div>

            <button type="submit" class="btn btn-primary">
                عرض الشهر
            </button>
        </form>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <span class="stat-label">الرصيد الافتتاحي المرحل</span>

        <span class="stat-value primary-text">
            <?= format_money($pdo, $openingBalance) ?>
        </span>
    </div>

    <div class="stat-card">
        <span class="stat-label">إجمالي المقبوضات خلال الشهر</span>

        <span class="stat-value success-text">
            + <?= format_money($pdo, $in) ?>
        </span>
    </div>

    <div class="stat-card">
        <span class="stat-label">إجمالي المدفوعات خلال الشهر</span>

        <span class="stat-value danger-text">
            - <?= format_money($pdo, $out) ?>
        </span>
    </div>

    <div class="stat-card">
        <span class="stat-label">
            رصيد نهاية شهر <?= e($selectedMonthName) ?>
        </span>

        <span
            class="stat-value <?= $balance >= 0 ? 'primary-text' : 'danger-text' ?>"
        >
            <?= format_money($pdo, $balance) ?>
        </span>
    </div>

    <div class="stat-card">
        <span class="stat-label">إجمالي ديون الزبائن</span>

        <span class="stat-value warning-text">
            <?= format_money($pdo, $totalCustomerDebts) ?>
        </span>
    </div>

    <div class="stat-card">
        <span class="stat-label">إجمالي أرصدة الزبائن لديهم</span>

        <span class="stat-value success-text">
            <?= format_money($pdo, $totalCustomerCredits) ?>
        </span>
    </div>

    <div class="stat-card">
        <span class="stat-label">إجمالي مستحقات الموردين</span>

        <span class="stat-value danger-text">
            <?= format_money($pdo, $totalSupplierPayables) ?>
        </span>
    </div>

    <div class="stat-card">
        <span class="stat-label">إجمالي الرصيد لنا عند الموردين</span>

        <span class="stat-value success-text">
            <?= format_money($pdo, $totalSupplierCredits) ?>
        </span>
    </div>
</div>

<div class="debts-grid">
    <div class="card" style="margin-bottom:0;">
        <div class="debt-card-header customer">
            <div>
                <h2 class="card-title" style="color:#92400e;">
                    أرصدة الزبائن
                </h2>

                <div class="text-muted">
                    عدد الزبائن ذوي الأرصدة:
                    <?= e((string)count($customersWithBalances)) ?>
                </div>
            </div>

            <span class="badge badge-debt">
                عليهم:
                <?= format_money($pdo, $totalCustomerDebts) ?>
            </span>

            <span class="badge badge-credit">
                لهم:
                <?= format_money($pdo, $totalCustomerCredits) ?>
            </span>
        </div>

        <div class="debt-list">
            <?php if (empty($customersWithBalances)): ?>
                <div class="no-debts">
                    لا توجد أرصدة للزبائن حاليًا.
                </div>
            <?php else: ?>
                <?php foreach ($customersWithBalances as $customer): ?>
                    <?php
                        $customerBalance = round((float)$customer['balance'], 2);

                        $customerBalanceClass = $customerBalance > 0
                            ? 'warning-text'
                            : 'success-text';
                    ?>

                    <div class="debt-row">
                        <div>
                            <div class="debt-name">
                                <?= e($customer['name']) ?>
                            </div>

                            <?php if (!empty($customer['phone'])): ?>
                                <div class="debt-phone">
                                    <?= e($customer['phone']) ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="debt-actions">
                            <div
                                class="debt-amount <?= $customerBalanceClass ?>"
                            >
                                <?= e(
                                    customerBalanceLabel(
                                        $pdo,
                                        $customerBalance
                                    )
                                ) ?>
                            </div>

                            <button
                                type="button"
                                class="btn btn-success customer-payment-btn"
                                style="font-size:11px; padding:5px 9px;"
                                data-customer-id="<?= (int)$customer['id'] ?>"
                                data-customer-name="<?= e($customer['name']) ?>"
                                data-customer-balance="<?= $customerBalance ?>"
                            >
                                استلام دفعة
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="card" style="margin-bottom:0;">
        <div class="debt-card-header supplier">
            <div>
                <h2 class="card-title" style="color:#991b1b;">
                    أرصدة الموردين
                </h2>

                <div class="text-muted">
                    عدد الموردين ذوي الأرصدة:
                    <?= e((string)count($suppliersWithBalances)) ?>
                </div>
            </div>

            <span class="badge badge-payable">
                لهم:
                <?= format_money($pdo, $totalSupplierPayables) ?>
            </span>

            <span class="badge badge-credit">
                لنا:
                <?= format_money($pdo, $totalSupplierCredits) ?>
            </span>
        </div>

        <div class="debt-list">
            <?php if (empty($suppliersWithBalances)): ?>
                <div class="no-debts">
                    لا توجد أرصدة للموردين حاليًا.
                </div>
            <?php else: ?>
                <?php foreach ($suppliersWithBalances as $supplier): ?>
                    <?php
                        $supplierBalance = round((float)$supplier['balance'], 2);

                        $supplierBalanceClass = $supplierBalance > 0
                            ? 'danger-text'
                            : 'success-text';
                    ?>

                    <div class="debt-row">
                        <div>
                            <div class="debt-name">
                                <?= e($supplier['name']) ?>
                            </div>

                            <?php if (!empty($supplier['phone'])): ?>
                                <div class="debt-phone">
                                    <?= e($supplier['phone']) ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="debt-actions">
                            <div
                                class="debt-amount <?= $supplierBalanceClass ?>"
                            >
                                <?= e(
                                    supplierBalanceLabel(
                                        $pdo,
                                        $supplierBalance
                                    )
                                ) ?>
                            </div>

                            <button
                                type="button"
                                class="btn btn-warning supplier-payment-btn"
                                style="font-size:11px; padding:5px 9px;"
                                data-supplier-id="<?= (int)$supplier['id'] ?>"
                                data-supplier-name="<?= e($supplier['name']) ?>"
                                data-supplier-balance="<?= $supplierBalance ?>"
                            >
                                دفع دفعة
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">
            إضافة إيداع نقدي للصندوق
        </h2>
    </div>

    <div class="card-body">
        <form method="post" class="form-grid">
            <input
                type="hidden"
                name="add_cash_entry"
                value="1"
            >

            <div class="form-group">
                <label for="entry_mode">نوع الإدخال</label>

                <select
                    name="entry_mode"
                    id="entry_mode"
                    onchange="toggleCustomerPayment()"
                >
                    <option value="normal">
                        إيداع نقدي عادي
                    </option>

                    <option value="customer_payment">
                        دفعة من زبون / تنزيل من الدين
                    </option>
                </select>
            </div>

            <div
                class="form-group"
                id="customer_field"
                style="display:none;"
            >
                <label for="customer_id">اختيار الزبون</label>

                <select name="customer_id" id="customer_id">
                    <option value="">-- اختر الزبون --</option>

                    <?php foreach ($customers as $customer): ?>
                        <?php $customerBalance = (float)$customer['balance']; ?>

                        <option value="<?= e((string)$customer['id']) ?>">
                            <?= e($customer['name']) ?>
                            —
                            <?= e(
                                customerBalanceLabel(
                                    $pdo,
                                    $customerBalance
                                )
                            ) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="amount">المبلغ</label>

                <input
                    type="number"
                    id="amount"
                    step="0.01"
                    min="0.01"
                    name="amount"
                    required
                    placeholder="0.00"
                >
            </div>

            <div class="form-group">
                <label for="description">البيان / الملاحظات</label>

                <input
                    type="text"
                    id="description"
                    name="description"
                    placeholder="مثال: إيداع رأس مال أو قبض مبيعات نقدية"
                >
            </div>

            <div class="form-group">
                <label>&nbsp;</label>

                <button class="btn btn-success">
                    إضافة إلى الصندوق
                </button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header flex-between">
        <div>
            <h2 class="card-title">
                حركات صندوق شهر
                <?= e($selectedMonthName) ?>
                <?= e((string)$selectedYear) ?>
            </h2>

            <div class="text-muted" style="margin-top:4px;">
                تظهر هنا الحركات المسجلة في الشهر المحدد فقط.
            </div>
        </div>

        <input
            type="text"
            id="tableSearch"
            class="form-control-sm"
            style="max-width:220px;"
            placeholder="بحث في الحركات..."
            onkeyup="filterCashbox()"
        >
    </div>

    <div class="table-responsive">
        <table class="table table-hover" id="cashboxTable">
            <thead>
                <tr>
                    <th style="width:60px;">#</th>
                    <th style="width:100px;">النوع</th>
                    <th>المبلغ</th>
                    <th>البيان / التفاصيل</th>
                    <th style="width:180px;">التاريخ والوقت</th>
                </tr>
            </thead>

            <tbody>
                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="5" class="empty-state">
                            لا توجد حركات مسجلة في شهر
                            <?= e($selectedMonthName) ?>
                            <?= e((string)$selectedYear) ?>.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rows as $row): ?>
                        <?php $isIn = $row['type'] === 'in'; ?>

                        <tr>
                            <td>
                                <span class="badge-id">
                                    #<?= e((string)$row['id']) ?>
                                </span>
                            </td>

                            <td>
                                <span
                                    class="badge <?= $isIn ? 'badge-in' : 'badge-out' ?>"
                                >
                                    <?= $isIn
                                        ? 'قبض / إيداع'
                                        : 'صرف / سحب'
                                    ?>
                                </span>
                            </td>

                            <td
                                class="
                                    font-weight-bold
                                    <?= $isIn
                                        ? 'success-text'
                                        : 'danger-text'
                                    ?>
                                "
                            >
                                <?= $isIn ? '+' : '-' ?>

                                <?= format_money(
                                    $pdo,
                                    $row['amount']
                                ) ?>
                            </td>

                            <td class="font-weight-bold">
                                <?= e($row['description']) ?>
                            </td>

                            <td class="text-muted">
                                <?= e($row['created_at']) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة استلام دفعة من زبون -->
<div class="modal" id="customerPaymentModal">
    <div class="modal-content">
        <h3 class="modal-title">
            استلام دفعة من زبون
        </h3>

        <p class="modal-subtitle">
            يمكن إدخال مبلغ أكبر من دين الزبون، وستتحول الزيادة إلى رصيد لصالحه.
        </p>

        <form method="post">
            <input
                type="hidden"
                name="add_cash_entry"
                value="1"
            >

            <input
                type="hidden"
                name="entry_mode"
                value="customer_payment"
            >

            <input
                type="hidden"
                name="customer_id"
                id="modal_customer_id"
            >

            <div class="form-group">
                <label>اسم الزبون</label>

                <input
                    type="text"
                    id="modal_customer_name"
                    readonly
                    style="background:#f8fafc;"
                >
            </div>

            <div class="payment-summary">
                <div class="payment-box">
                    <span class="payment-box-label">
                        رصيد الزبون الحالي
                    </span>

                    <span
                        class="payment-box-value warning-text"
                        id="modal_customer_balance"
                    >
                        0.00
                    </span>
                </div>

                <div class="payment-box">
                    <span class="payment-box-label">
                        الرصيد بعد العملية
                    </span>

                    <span
                        class="payment-box-value success-text"
                        id="modal_customer_remaining"
                    >
                        0.00
                    </span>
                </div>
            </div>

            <div class="form-group">
                <label for="modal_customer_amount">
                    قيمة الدفعة المستلمة
                </label>

                <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    name="amount"
                    id="modal_customer_amount"
                    required
                    placeholder="0.00"
                >
            </div>

            <div class="form-group">
                <label for="modal_customer_description">
                    ملاحظات
                </label>

                <input
                    type="text"
                    name="description"
                    id="modal_customer_description"
                    placeholder="ملاحظة اختيارية"
                >
            </div>

            <div class="payment-actions">
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-close-modal="customerPaymentModal"
                >
                    إلغاء
                </button>

                <button
                    type="submit"
                    class="btn btn-success"
                >
                    استلام وإضافة للصندوق
                </button>
            </div>
        </form>
    </div>
</div>

<!-- نافذة دفع دفعة لمورد -->
<div class="modal" id="supplierPaymentModal">
    <div class="modal-content">
        <h3 class="modal-title">
            دفع دفعة لمورد
        </h3>

        <p class="modal-subtitle">
            يمكن دفع مبلغ أكبر من مستحق المورد، وستتحول الزيادة إلى رصيد لصالح المحل عند المورد.
        </p>

        <form method="post">
            <input
                type="hidden"
                name="supplier_payment"
                value="1"
            >

            <input
                type="hidden"
                name="supplier_id"
                id="modal_supplier_id"
            >

            <div class="form-group">
                <label>اسم المورد</label>

                <input
                    type="text"
                    id="modal_supplier_name"
                    readonly
                    style="background:#f8fafc;"
                >
            </div>

            <div class="payment-summary">
                <div class="payment-box">
                    <span class="payment-box-label">
                        رصيد المورد الحالي
                    </span>

                    <span
                        class="payment-box-value danger-text"
                        id="modal_supplier_balance"
                    >
                        0.00
                    </span>
                </div>

                <div class="payment-box">
                    <span class="payment-box-label">
                        الرصيد بعد العملية
                    </span>

                    <span
                        class="payment-box-value success-text"
                        id="modal_supplier_remaining"
                    >
                        0.00
                    </span>
                </div>
            </div>

            <div class="form-group">
                <label for="modal_supplier_amount">
                    قيمة الدفعة المدفوعة
                </label>

                <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    name="amount"
                    id="modal_supplier_amount"
                    required
                    placeholder="0.00"
                >
            </div>

            <div class="form-group">
                <label for="modal_supplier_description">
                    ملاحظات
                </label>

                <input
                    type="text"
                    name="description"
                    id="modal_supplier_description"
                    placeholder="ملاحظة اختيارية"
                >
            </div>

            <div class="payment-actions">
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-close-modal="supplierPaymentModal"
                >
                    إلغاء
                </button>

                <button
                    type="submit"
                    class="btn btn-warning"
                >
                    دفع وخصم من الصندوق
                </button>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    'use strict';

    let selectedCustomerBalance = 0;
    let selectedSupplierBalance = 0;

    const currency = <?= json_encode(
        app_setting($pdo, 'currency', 'ل.س'),
        JSON_UNESCAPED_UNICODE
    ) ?>;

    function formatCashMoney(value) {
        return Number(value || 0).toFixed(2) + ' ' + currency;
    }

    function openModal(modalId) {
        const modal = document.getElementById(modalId);

        if (!modal) {
            console.error('لم يتم العثور على النافذة: ' + modalId);
            return;
        }

        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }

    function closeModal(modalId) {
        const modal = document.getElementById(modalId);

        if (modal) {
            modal.style.display = 'none';
        }

        document.body.style.overflow = '';
    }

    function getCustomerBalanceText(balance) {
        if (balance > 0) {
            return 'على الزبون: ' + formatCashMoney(balance);
        }

        if (balance < 0) {
            return 'للزبون رصيد: '
                + formatCashMoney(Math.abs(balance));
        }

        return 'لا يوجد رصيد';
    }

    function getSupplierBalanceText(balance) {
        if (balance > 0) {
            return 'للمورد: ' + formatCashMoney(balance);
        }

        if (balance < 0) {
            return 'لنا عند المورد: '
                + formatCashMoney(Math.abs(balance));
        }

        return 'لا يوجد رصيد';
    }

    function updateCustomerResult() {
        const amountInput =
            document.getElementById('modal_customer_amount');

        const resultElement =
            document.getElementById('modal_customer_remaining');

        let amount = Number(amountInput.value || 0);

        if (amount < 0) {
            amount = 0;
        }

        const newBalance = selectedCustomerBalance - amount;

        resultElement.textContent =
            getCustomerBalanceText(newBalance);

        resultElement.className =
            'payment-box-value '
            + (newBalance > 0
                ? 'warning-text'
                : 'success-text');
    }

    function updateSupplierResult() {
        const amountInput =
            document.getElementById('modal_supplier_amount');

        const resultElement =
            document.getElementById('modal_supplier_remaining');

        let amount = Number(amountInput.value || 0);

        if (amount < 0) {
            amount = 0;
        }

        const newBalance = selectedSupplierBalance - amount;

        resultElement.textContent =
            getSupplierBalanceText(newBalance);

        resultElement.className =
            'payment-box-value '
            + (newBalance > 0
                ? 'danger-text'
                : 'success-text');
    }

    function openCustomerPaymentModal(button) {
        selectedCustomerBalance = Number(
            button.dataset.customerBalance || 0
        );

        document.getElementById('modal_customer_id').value =
            button.dataset.customerId || '';

        document.getElementById('modal_customer_name').value =
            button.dataset.customerName || '';

        const balanceElement =
            document.getElementById('modal_customer_balance');

        balanceElement.textContent =
            getCustomerBalanceText(selectedCustomerBalance);

        balanceElement.className =
            'payment-box-value '
            + (selectedCustomerBalance > 0
                ? 'warning-text'
                : 'success-text');

        const amountInput =
            document.getElementById('modal_customer_amount');

        amountInput.value = '';

        document.getElementById(
            'modal_customer_description'
        ).value = '';

        updateCustomerResult();

        openModal('customerPaymentModal');

        window.setTimeout(function () {
            amountInput.focus();
        }, 100);
    }

    function openSupplierPaymentModal(button) {
        selectedSupplierBalance = Number(
            button.dataset.supplierBalance || 0
        );

        document.getElementById('modal_supplier_id').value =
            button.dataset.supplierId || '';

        document.getElementById('modal_supplier_name').value =
            button.dataset.supplierName || '';

        const balanceElement =
            document.getElementById('modal_supplier_balance');

        balanceElement.textContent =
            getSupplierBalanceText(selectedSupplierBalance);

        balanceElement.className =
            'payment-box-value '
            + (selectedSupplierBalance > 0
                ? 'danger-text'
                : 'success-text');

        const amountInput =
            document.getElementById('modal_supplier_amount');

        amountInput.value = '';

        document.getElementById(
            'modal_supplier_description'
        ).value = '';

        updateSupplierResult();

        openModal('supplierPaymentModal');

        window.setTimeout(function () {
            amountInput.focus();
        }, 100);
    }

    function toggleCustomerPayment() {
        const entryMode = document.getElementById('entry_mode');
        const customerField =
            document.getElementById('customer_field');

        if (!entryMode || !customerField) {
            return;
        }

        customerField.style.display =
            entryMode.value === 'customer_payment'
                ? 'flex'
                : 'none';
    }

    function filterCashbox() {
        const input = document.getElementById('tableSearch');
        const table = document.getElementById('cashboxTable');

        if (!input || !table) {
            return;
        }

        const filter = input.value.toLowerCase();
        const rows = table.querySelectorAll('tbody tr');

        rows.forEach(function (row) {
            const rowText = (
                row.textContent || row.innerText || ''
            ).toLowerCase();

            row.style.display =
                rowText.indexOf(filter) > -1
                    ? ''
                    : 'none';
        });
    }

    document.querySelectorAll('.customer-payment-btn').forEach(
        function (button) {
            button.addEventListener('click', function () {
                openCustomerPaymentModal(button);
            });
        }
    );

    document.querySelectorAll('.supplier-payment-btn').forEach(
        function (button) {
            button.addEventListener('click', function () {
                openSupplierPaymentModal(button);
            });
        }
    );

    document.querySelectorAll('[data-close-modal]').forEach(
        function (button) {
            button.addEventListener('click', function () {
                closeModal(button.dataset.closeModal);
            });
        }
    );

    const customerAmountInput =
        document.getElementById('modal_customer_amount');

    if (customerAmountInput) {
        customerAmountInput.addEventListener(
            'input',
            updateCustomerResult
        );
    }

    const supplierAmountInput =
        document.getElementById('modal_supplier_amount');

    if (supplierAmountInput) {
        supplierAmountInput.addEventListener(
            'input',
            updateSupplierResult
        );
    }

    const entryMode = document.getElementById('entry_mode');

    if (entryMode) {
        entryMode.addEventListener(
            'change',
            toggleCustomerPayment
        );
    }

    const tableSearch = document.getElementById('tableSearch');

    if (tableSearch) {
        tableSearch.addEventListener(
            'keyup',
            filterCashbox
        );
    }

    window.addEventListener('click', function (event) {
        if (
            event.target
            && event.target.classList
            && event.target.classList.contains('modal')
        ) {
            closeModal(event.target.id);
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            closeModal('customerPaymentModal');
            closeModal('supplierPaymentModal');
        }
    });
})();
</script>

<?php require_once 'includes/footer.php'; ?>