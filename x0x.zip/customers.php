<?php
require_once 'config/database.php';
require_once 'includes/header.php';

// ---------------------------------------------------------------------
// 1. معالجة طلبات POST (إضافة، تعديل، حذف)
// ---------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // أ) إضافة زبون جديد
    if (isset($_POST['add_customer'])) {
        $name    = trim($_POST['name'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $phone   = trim($_POST['phone'] ?? '');

        if ($name === '') {
            set_flash('error', 'يرجى إدخال اسم الزبون على الأقل');
        } else {
            $stmt = $pdo->prepare("INSERT INTO customers (name, address, phone, balance) VALUES (?, ?, ?, 0.00)");
            $stmt->execute([$name, $address, $phone]);
            set_flash('success', 'تمت إضافة الزبون بنجاح');
        }
        redirect('customers.php');
    }

    // ب) تعديل بيانات زبون
    if (isset($_POST['update_customer'])) {
        $id      = (int)($_POST['customer_id'] ?? 0);
        $name    = trim($_POST['name'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $phone   = trim($_POST['phone'] ?? '');

        if ($id <= 0 || $name === '') {
            set_flash('error', 'بيانات غير مكتملة لتحديث الزبون');
        } else {
            $stmt = $pdo->prepare("UPDATE customers SET name = ?, address = ?, phone = ? WHERE id = ?");
            $stmt->execute([$name, $address, $phone, $id]);
            set_flash('success', 'تم تعديل بيانات الزبون بنجاح');
        }
        redirect('customers.php');
    }

    // ج) حذف زبون
    if (isset($_POST['delete_customer'])) {
        $customerId = (int)($_POST['customer_id'] ?? 0);

        // التحقق من وجود فواتير مرتبطة بالزبون
        $hasInvoices = $pdo->prepare("SELECT COUNT(*) FROM invoices WHERE customer_id = ?");
        $hasInvoices->execute([$customerId]);

        if ($hasInvoices->fetchColumn() > 0) {
            set_flash('error', 'لا يمكن حذف الزبون لوجود فواتير مرتبطة به في النظام');
        } else {
            $pdo->prepare("DELETE FROM customers WHERE id = ?")->execute([$customerId]);
            set_flash('warning', 'تم حذف الزبون بنجاح');
        }
        redirect('customers.php');
    }
}

// ---------------------------------------------------------------------
// 2. جلب زبون للتعديل (إن وجد)
// ---------------------------------------------------------------------
$editCustomer = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editCustomer = $stmt->fetch(PDO::FETCH_ASSOC);
}

// ---------------------------------------------------------------------
// 3. جلب قائمة الزبائن وحساب الإحصائيات
// ---------------------------------------------------------------------
$customers = $pdo->query("SELECT * FROM customers ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

$totalCustomers = count($customers);
$totalDebt      = 0;
$debtorsCount   = 0;

foreach ($customers as $c) {
    if ($c['balance'] > 0) {
        $totalDebt += $c['balance'];
        $debtorsCount++;
    }
}
?>

<!-- تنسيقات العرض الحديثة -->
<style>
    .customers-wrapper { display: flex; flex-direction: column; gap: 1.5rem; }
    .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; }
    .stat-card { background: #ffffff; padding: 1.25rem; border-radius: 12px; border: 1px solid #e5e7eb; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
    .stat-card .title { font-size: 0.875rem; color: #6b7280; font-weight: 600; margin-bottom: 0.25rem; }
    .stat-card .value { font-size: 1.5rem; font-weight: 700; color: #111827; }
    
    .card-custom { background: #ffffff; border-radius: 12px; border: 1px solid #e5e7eb; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.03); }
    .card-title { font-size: 1.15rem; font-weight: 700; color: #1f2937; margin-bottom: 1.25rem; display: flex; align-items: center; justify-content: space-between; }
    
    .form-grid-3 { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; align-items: end; }
    .form-group label { display: block; font-size: 0.875rem; font-weight: 600; color: #374151; margin-bottom: 0.35rem; }
    .form-control-custom { width: 100%; padding: 0.625rem 0.85rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.95rem; transition: border-color 0.2s, box-shadow 0.2s; outline: none; }
    .form-control-custom:focus { border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,0.1); }
    
    .badge-balance-zero { background-color: #d1fae5; color: #065f46; padding: 0.25rem 0.65rem; border-radius: 9999px; font-weight: 700; font-size: 0.85rem; display: inline-block; }
    .badge-balance-debt { background-color: #fee2e2; color: #991b1b; padding: 0.25rem 0.65rem; border-radius: 9999px; font-weight: 700; font-size: 0.85rem; display: inline-block; }
    
    .contact-actions { display: flex; gap: 0.35rem; align-items: center; }
    .contact-btn { padding: 0.25rem 0.5rem; border-radius: 6px; font-size: 0.8rem; text-decoration: none; font-weight: 600; display: inline-flex; align-items: center; gap: 0.2rem; }
    .btn-whatsapp { background-color: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
    .btn-whatsapp:hover { background-color: #bbf7d0; }
    .btn-call { background-color: #f1f5f9; color: #334155; border: 1px solid #e2e8f0; }
    .btn-call:hover { background-color: #e2e8f0; }
</style>

<div class="customers-wrapper">
    <!-- ترويسة الصفحة -->
    <div class="card-custom" style="padding: 1rem 1.5rem; background: linear-gradient(to left, #0f172a, #1e293b); color: #fff;">
        <h2 style="margin:0; font-size: 1.4rem; font-weight:700;">سجل الزبائن وحسابات الديون</h2>
        <p style="margin:0.25rem 0 0 0; color: #94a3b8; font-size:0.9rem;">إدارة بيانات الزبائن، متابعة الأرصدة والذمم المالية بشكل عصري</p>
    </div>

    <!-- البطاقات الإحصائية -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="title">إجمالي الزبائن المسجلين</div>
            <div class="value"><?= $totalCustomers ?> <span style="font-size:0.85rem; color:#6b7280; font-weight:normal;">زبون</span></div>
        </div>
        <div class="stat-card">
            <div class="title">عدد الزبائن المدينين</div>
            <div class="value" style="color: #dc2626;"><?= $debtorsCount ?> <span style="font-size:0.85rem; color:#6b7280; font-weight:normal;">زبون مطلوب</span></div>
        </div>
        <div class="stat-card">
            <div class="title">إجمالي الديون للشركاء (في السوق)</div>
            <div class="value" style="color: #2563eb;"><?= format_money($pdo, $totalDebt) ?></div>
        </div>
    </div>

    <!-- 1. نموذج الإضافة / التعديل -->
    <div class="card-custom" style="<?= $editCustomer ? 'border-top: 4px solid #f59e0b;' : 'border-top: 4px solid #2563eb;' ?>">
        <div class="card-title">
            <span><?= $editCustomer ? 'تعديل بيانات الزبون: (' . e($editCustomer['name']) . ')' : 'إضافة زبون جديد' ?></span>
            <?php if ($editCustomer): ?>
                <a href="customers.php" class="btn btn-outline-secondary btn-sm" style="font-size:0.85rem; text-decoration:none;">✕ إلغاء التعديل</a>
            <?php endif; ?>
        </div>

        <form method="post" class="form-grid-3">
            <input type="hidden" name="<?= $editCustomer ? 'update_customer' : 'add_customer' ?>" value="1">
            <?php if ($editCustomer): ?>
                <input type="hidden" name="customer_id" value="<?= e($editCustomer['id']) ?>">
            <?php endif; ?>

            <div class="form-group">
                <label>اسم الزبون <span style="color:#ef4444">*</span></label>
                <input name="name" class="form-control-custom" placeholder="مثال: أحمد المحمد" required value="<?= e($editCustomer['name'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>رقم الهاتف</label>
                <input name="phone" class="form-control-custom" placeholder="09xxxxxxxx" value="<?= e($editCustomer['phone'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>العنوان / المنطقة</label>
                <input name="address" class="form-control-custom" placeholder="مثال: دمشق - الميدان" value="<?= e($editCustomer['address'] ?? '') ?>">
            </div>

            <div class="form-group" style="grid-column: 1 / -1; display: flex; justify-content: flex-end; gap: 0.5rem; margin-top: 0.5rem;">
                <button type="submit" class="btn <?= $editCustomer ? 'btn-warning' : 'btn-primary' ?>" style="padding: 0.625rem 1.75rem; font-weight:600;">
                    <?= $editCustomer ? 'حفظ التعديلات' : '+ إضافة الزبون' ?>
                </button>
            </div>
        </form>
    </div>

    <!-- 2. جدول عرض الزبائن وتصفيات البحث -->
    <div class="card-custom">
        <div class="card-title">
            <span>قائمة الزبائن المسجلين</span>
            <!-- مربع بحث فوري -->
            <div style="width: 260px;">
                <input type="text" id="customerSearchInput" onkeyup="filterCustomers()" class="form-control-custom" placeholder="🔍 بحث عن زبون أو هاتف..." style="font-size:0.85rem; padding: 0.4rem 0.75rem;">
            </div>
        </div>

        <div style="overflow-x: auto;">
            <table class="table" id="customersTable" style="width:100%; border-collapse: collapse;">
                <thead>
                    <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0; text-align: right;">
                        <th style="padding:0.75rem;">#</th>
                        <th style="padding:0.75rem;">الاسم</th>
                        <th style="padding:0.75rem;">الهاتف / التواصل</th>
                        <th style="padding:0.75rem;">العنوان</th>
                        <th style="padding:0.75rem;">الرصيد / الدين</th>
                        <th style="padding:0.75rem; text-align:center;">إجراءات</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($customers)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 2rem; color: #9ca3af;">
                            لا يوجد زبائن مسجلون في النظام حالياً.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach($customers as $row): ?>
                        <tr class="customer-row" style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding:0.75rem; color:#6b7280;"><?= e($row['id']) ?></td>
                            <td style="padding:0.75rem; font-weight:700; color:#1e293b;" class="search-name">
                                <?= e($row['name']) ?>
                            </td>
                            <td style="padding:0.75rem;" class="search-phone">
                                <?php if (!empty($row['phone'])): ?>
                                    <?php $cleanPhone = preg_replace('/[^0-9+]/', '', $row['phone']); ?>
                                    <div class="contact-actions">
                                        <span><?= e($row['phone']) ?></span>
                                        <a href="https://wa.me/<?= $cleanPhone ?>" target="_blank" class="contact-btn btn-whatsapp" title="محادثة واتساب">واتساب</a>
                                        <a href="tel:<?= $cleanPhone ?>" class="contact-btn btn-call" title="اتصال تلفوني">اتصال</a>
                                    </div>
                                <?php else: ?>
                                    <span style="color:#9ca3af; font-size:0.85rem;">غ/م</span>
                                <?php endif; ?>
                            </td>
                            <td style="padding:0.75rem; color:#4b5563;" class="search-address">
                                <?= !empty($row['address']) ? e($row['address']) : '<span style="color:#9ca3af; font-size:0.85rem;">غ/م</span>' ?>
                            </td>
                            <td style="padding:0.75rem;">
                                <?php if ($row['balance'] > 0): ?>
                                    <span class="badge-balance-debt">
                                        مطلوب: <?= format_money($pdo, $row['balance']) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="badge-balance-zero">
                                        خالي الدين (0.00)
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td style="padding:0.75rem; text-align:center;">
                                <div style="display:flex; gap:0.4rem; justify-content:center;">
                                    <a class="btn btn-warning btn-sm" href="customers.php?edit=<?= e($row['id']) ?>" style="padding:0.25rem 0.6rem; font-size:0.8rem; text-decoration:none;">تعديل</a>
                                    
                                    <form method="post" style="display:inline;" onsubmit="return confirm('هل أنت تأكد من حذف الزبون: (<?= e($row['name']) ?>)؟')">
                                        <input type="hidden" name="delete_customer" value="1">
                                        <input type="hidden" name="customer_id" value="<?= e($row['id']) ?>">
                                        <button class="btn btn-danger btn-sm" style="padding:0.25rem 0.6rem; font-size:0.8rem;">حذف</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- جافاسكريبت للبحث المباشر والتصفية -->
<script>
function filterCustomers() {
    const input = document.getElementById("customerSearchInput");
    const filter = input.value.toLowerCase().trim();
    const rows = document.getElementsByClassName("customer-row");

    for (let i = 0; i < rows.length; i++) {
        const nameCell = rows[i].querySelector(".search-name");
        const phoneCell = rows[i].querySelector(".search-phone");
        const addressCell = rows[i].querySelector(".search-address");

        const nameText = nameCell ? nameCell.textContent.toLowerCase() : "";
        const phoneText = phoneCell ? phoneCell.textContent.toLowerCase() : "";
        const addressText = addressCell ? addressCell.textContent.toLowerCase() : "";

        if (nameText.includes(filter) || phoneText.includes(filter) || addressText.includes(filter)) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>