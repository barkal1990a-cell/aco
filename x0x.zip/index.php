<?php
require_once 'config/database.php';
require_once 'includes/header.php';

/*
|--------------------------------------------------------------------------
| الإحصائيات الرئيسية
|--------------------------------------------------------------------------
*/
$statsQuery = $pdo->query("
    SELECT 
        (SELECT COUNT(*) FROM products) AS products,
        (SELECT COUNT(*) FROM customers) AS customers,
        (SELECT COUNT(*) FROM suppliers) AS suppliers,
        (SELECT COUNT(*) FROM employees) AS employees,
        (
            SELECT COALESCE(SUM(total_amount), 0)
            FROM invoices
            WHERE DATE(created_at) = CURDATE()
        ) AS today_sales,
        (
            SELECT COALESCE(SUM(balance), 0)
            FROM customers
        ) AS debts,
        (
            SELECT COALESCE(SUM(amount), 0)
            FROM expenses
            WHERE expense_date = CURDATE()
        ) AS today_expenses,
        (
            SELECT COALESCE(SUM(amount), 0)
            FROM cashbox
            WHERE type = 'in'
        ) AS cash_in,
        (
            SELECT COALESCE(SUM(amount), 0)
            FROM cashbox
            WHERE type = 'out'
        ) AS cash_out
")->fetch(PDO::FETCH_ASSOC);

$stats = [
    'products'       => $statsQuery['products'] ?? 0,
    'customers'      => $statsQuery['customers'] ?? 0,
    'suppliers'      => $statsQuery['suppliers'] ?? 0,
    'employees'      => $statsQuery['employees'] ?? 0,
    'today_sales'    => $statsQuery['today_sales'] ?? 0,
    'debts'          => $statsQuery['debts'] ?? 0,
    'today_expenses' => $statsQuery['today_expenses'] ?? 0,
    'cash_in'        => $statsQuery['cash_in'] ?? 0,
    'cash_out'       => $statsQuery['cash_out'] ?? 0,
];

$cashBalance = (float)$stats['cash_in'] - (float)$stats['cash_out'];

/*
|--------------------------------------------------------------------------
| المنتجات الموشكة على النفاد
|--------------------------------------------------------------------------
*/
$lowStockStmt = $pdo->query("
    SELECT
        id,
        name,
        sku,
        category,
        quantity
    FROM products
    WHERE quantity < 10
    ORDER BY quantity ASC, name ASC
");

$lowStockProducts = $lowStockStmt->fetchAll(PDO::FETCH_ASSOC);

$lowStockCount = count($lowStockProducts);

/*
|--------------------------------------------------------------------------
| آخر 3 فواتير بيع لواجهة لوحة التحكم
|--------------------------------------------------------------------------
*/
$recentInvoices = $pdo->query("
    SELECT
        invoices.id,
        invoices.invoice_number,
        customers.name AS customer_name,
        invoices.total_amount,
        invoices.created_at
    FROM invoices
    LEFT JOIN customers
        ON customers.id = invoices.customer_id
    ORDER BY invoices.id DESC
    LIMIT 3
")->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| كامل فواتير البيع للنافذة المنبثقة
|--------------------------------------------------------------------------
*/
$allInvoices = $pdo->query("
    SELECT
        invoices.id,
        invoices.invoice_number,
        customers.name AS customer_name,
        invoices.total_amount,
        invoices.created_at
    FROM invoices
    LEFT JOIN customers
        ON customers.id = invoices.customer_id
    ORDER BY invoices.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| آخر 3 فواتير شراء لواجهة لوحة التحكم
|--------------------------------------------------------------------------
*/
$recentPurchaseInvoices = $pdo->query("
    SELECT
        purchase_invoices.id,
        purchase_invoices.purchase_number,
        suppliers.name AS supplier_name,
        purchase_invoices.total_amount,
        purchase_invoices.paid_amount,
        purchase_invoices.remaining_amount,
        purchase_invoices.created_at
    FROM purchase_invoices
    LEFT JOIN suppliers
        ON suppliers.id = purchase_invoices.supplier_id
    ORDER BY purchase_invoices.id DESC
    LIMIT 3
")->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| كامل فواتير الشراء للنافذة المنبثقة
|--------------------------------------------------------------------------
*/
$allPurchaseInvoices = $pdo->query("
    SELECT
        purchase_invoices.id,
        purchase_invoices.purchase_number,
        suppliers.name AS supplier_name,
        purchase_invoices.total_amount,
        purchase_invoices.paid_amount,
        purchase_invoices.remaining_amount,
        purchase_invoices.created_at
    FROM purchase_invoices
    LEFT JOIN suppliers
        ON suppliers.id = purchase_invoices.supplier_id
    ORDER BY purchase_invoices.id DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
:root {
    --dash-primary: #2563eb;
    --dash-bg-card: #ffffff;
    --dash-text-main: #0f172a;
    --dash-text-sub: #64748b;
    --dash-border: #f1f5f9;
}

.dashboard-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 12px;
}

.dashboard-title {
    font-size: 24px;
    font-weight: 800;
    color: var(--dash-text-main);
    margin: 0;
}

.clock-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 10px 18px;
    display: flex;
    align-items: center;
    gap: 14px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

.clock-live-indicator {
    width: 10px;
    height: 10px;
    background-color: #10b981;
    border-radius: 50%;
    box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
    animation: pulse-green 2s infinite;
}

@keyframes pulse-green {
    0% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
    }

    70% {
        transform: scale(1);
        box-shadow: 0 0 0 8px rgba(16, 185, 129, 0);
    }

    100% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
    }
}

.clock-time {
    font-size: 20px;
    font-weight: 800;
    color: #1e293b;
    font-family: 'Courier New', Courier, monospace;
    letter-spacing: 0.5px;
}

.clock-date {
    font-size: 13px;
    color: var(--dash-text-sub);
    font-weight: 600;
    border-right: 2px solid #e2e8f0;
    padding-right: 12px;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.stat-card {
    background: var(--dash-bg-card);
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    padding: 16px;
    display: flex;
    align-items: center;
    gap: 14px;
    transition: all 0.25s ease;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

.stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.05);
    border-color: #cbd5e1;
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.stat-icon svg {
    width: 24px;
    height: 24px;
}

.stat-info {
    display: flex;
    flex-direction: column;
}

.stat-info h3 {
    margin: 0 0 4px 0;
    font-size: 13px;
    font-weight: 600;
    color: var(--dash-text-sub);
}

.stat-info strong {
    font-size: 20px;
    font-weight: 800;
    color: var(--dash-text-main);
    line-height: 1.2;
}

.dash-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

.dash-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
    flex-wrap: wrap;
    gap: 10px;
}

.dash-card-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 700;
    color: var(--dash-text-main);
}

.modern-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.modern-table th {
    background: #f8fafc;
    color: #475569;
    font-weight: 700;
    padding: 10px 12px;
    text-align: right;
    border-bottom: 1px solid #e2e8f0;
}

.modern-table td {
    padding: 12px;
    text-align: right;
    border-bottom: 1px solid #f1f5f9;
    color: #334155;
}

.modern-table tbody tr:last-child td {
    border-bottom: none;
}

.modern-table tbody tr:hover {
    background-color: #f8fafc;
}

.badge-danger {
    background: #fef2f2;
    color: #dc2626;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    border: 1px solid #fecaca;
    display: inline-block;
}

.badge-success {
    background: #ecfdf5;
    color: #059669;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    border: 1px solid #a7f3d0;
    display: inline-block;
}

.badge-neutral {
    background: #f8fafc;
    color: #64748b;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    border: 1px solid #e2e8f0;
    display: inline-block;
}

/*
|--------------------------------------------------------------------------
| النافذة المنبثقة لسجل الفواتير
|--------------------------------------------------------------------------
*/
.invoices-dialog {
    width: min(96vw, 1180px);
    max-width: 1180px;
    max-height: 88vh;
    margin: auto;
    border: none;
    border-radius: 16px;
    padding: 0;
    background: #ffffff;
    box-shadow: 0 25px 60px rgba(15, 23, 42, 0.25);
    overflow: hidden;
}

.invoices-dialog::backdrop {
    background: rgba(15, 23, 42, 0.58);
    backdrop-filter: blur(2px);
}

.dialog-header {
    padding: 18px 20px;
    border-bottom: 1px solid #e2e8f0;
    background: #f8fafc;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
}

.dialog-header h2 {
    margin: 0;
    font-size: 18px;
    color: #0f172a;
}

.dialog-close-btn {
    width: 34px;
    height: 34px;
    padding: 0;
    border: none;
    border-radius: 8px;
    background: #fee2e2;
    color: #dc2626;
    cursor: pointer;
    font-size: 22px;
    font-weight: 700;
    line-height: 1;
}

.dialog-close-btn:hover {
    background: #fecaca;
}

.dialog-body {
    padding: 20px;
    overflow-y: auto;
    max-height: calc(88vh - 75px);
}

.dialog-tools {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 16px;
}

.dialog-search {
    width: min(100%, 300px);
    padding: 9px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    outline: none;
    font-size: 13px;
}

.dialog-search:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

.dialog-count {
    color: #64748b;
    font-size: 13px;
    font-weight: 600;
}

.dialog-table-wrapper {
    overflow-x: auto;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
}

.dialog-empty {
    padding: 28px;
    color: #64748b;
    text-align: center;
    font-size: 14px;
}

.show-more-btn {
    font-size: 12px;
    padding: 6px 14px;
    border: none;
    cursor: pointer;
}

@media (max-width: 640px) {
    .clock-card {
        width: 100%;
        justify-content: center;
    }

    .dashboard-header {
        align-items: stretch;
    }

    .invoices-dialog {
        width: 100vw;
        max-width: 100vw;
        max-height: 100vh;
        height: 100vh;
        border-radius: 0;
    }

    .dialog-body {
        max-height: calc(100vh - 75px);
        padding: 14px;
    }

    .dialog-search {
        width: 100%;
    }
}
</style>

<div class="dashboard-header">
    <h1 class="dashboard-title">لوحة التحكم</h1>

    <div class="clock-card">
        <div class="clock-live-indicator"></div>

        <div id="liveClock" class="clock-time">
            00:00:00 AM
        </div>

        <div id="liveDate" class="clock-date">
            -- --- ----
        </div>
    </div>
</div>

<div class="stats-grid">
    <!-- المنتجات -->
    <div class="stat-card">
        <div
            class="stat-icon"
            style="background:#eff6ff; color:#2563eb;"
        >
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
                ></path>
            </svg>
        </div>

        <div class="stat-info">
            <h3>عدد المنتجات</h3>

            <strong>
                <?= e($stats['products']) ?>
            </strong>
        </div>
    </div>

    <!-- الزبائن -->
    <div class="stat-card">
        <div
            class="stat-icon"
            style="background:#f0fdf4; color:#16a34a;"
        >
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                ></path>
            </svg>
        </div>

        <div class="stat-info">
            <h3>عدد الزبائن</h3>

            <strong>
                <?= e($stats['customers']) ?>
            </strong>
        </div>
    </div>

    <!-- الموردون -->
    <div class="stat-card">
        <div
            class="stat-icon"
            style="background:#f0f9ff; color:#0284c7;"
        >
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M8 4H6a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-2m-4-1v8m0 0l3-3m-3 3L9 8m-5 5h2.586a1 1 0 01.707.293l2.414 2.414a1 1 0 00.707.293h3.172a1 1 0 00.707-.293l2.414-2.414a1 1 0 01.707-.293H20"
                ></path>
            </svg>
        </div>

        <div class="stat-info">
            <h3>عدد الموردين</h3>

            <strong>
                <?= e($stats['suppliers']) ?>
            </strong>
        </div>
    </div>

    <!-- الموظفون -->
    <div class="stat-card">
        <div
            class="stat-icon"
            style="background:#faf5ff; color:#9333ea;"
        >
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 012-2h2a2 2 0 012 2v1m-4 0h4"
                ></path>
            </svg>
        </div>

        <div class="stat-info">
            <h3>عدد الموظفين</h3>

            <strong>
                <?= e($stats['employees']) ?>
            </strong>
        </div>
    </div>

    <!-- مبيعات اليوم -->
    <div class="stat-card">
        <div
            class="stat-icon"
            style="background:#ecfdf5; color:#059669;"
        >
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                ></path>
            </svg>
        </div>

        <div class="stat-info">
            <h3>مبيعات اليوم</h3>

            <strong>
                <?= format_money(
                    $pdo,
                    $stats['today_sales']
                ) ?>
            </strong>
        </div>
    </div>

    <!-- ديون الزبائن -->
    <div class="stat-card">
        <div
            class="stat-icon"
            style="background:#fffbeb; color:#d97706;"
        >
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                ></path>
            </svg>
        </div>

        <div class="stat-info">
            <h3>ديون الزبائن</h3>

            <strong>
                <?= format_money(
                    $pdo,
                    $stats['debts']
                ) ?>
            </strong>
        </div>
    </div>

    <!-- الصندوق -->
    <div class="stat-card">
        <div
            class="stat-icon"
            style="background:#f0fdf4; color:#15803d;"
        >
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002 2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"
                ></path>
            </svg>
        </div>

        <div class="stat-info">
            <h3>المتوفر في الصندوق</h3>

            <strong>
                <?= format_money($pdo, $cashBalance) ?>
            </strong>
        </div>
    </div>

    <!-- المصاريف -->
    <div class="stat-card">
        <div
            class="stat-icon"
            style="background:#fff1f2; color:#e11d48;"
        >
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"
                ></path>
            </svg>
        </div>

        <div class="stat-info">
            <h3>مصاريف اليوم</h3>

            <strong>
                <?= format_money(
                    $pdo,
                    $stats['today_expenses']
                ) ?>
            </strong>
        </div>
    </div>

    <!-- تنبيه المخزون -->
    <?php if ($lowStockCount > 0): ?>
        <div
            class="stat-card"
            style="
                border-color:#fca5a5;
                background:#fff5f5;
            "
        >
            <div
                class="stat-icon"
                style="
                    background:#fee2e2;
                    color:#dc2626;
                "
            >
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                    ></path>
                </svg>
            </div>

            <div class="stat-info">
                <h3>تنبيهات المخزون</h3>

                <strong style="color:#dc2626;">
                    <?= e($lowStockCount) ?> صنف
                </strong>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if ($lowStockCount > 0): ?>
    <div
        class="dash-card"
        style="border-top:4px solid #ef4444;"
    >
        <div class="dash-card-header">
            <div>
                <h3>تنبيهات المخزون المنخفض</h3>

                <p
                    style="
                        margin:4px 0 0;
                        color:var(--dash-text-sub);
                        font-size:12px;
                    "
                >
                    المنتجات التي أصبحت كميتها أقل من 10 قطع في المستودع.
                </p>
            </div>

            <a
                class="btn btn-warning"
                href="products.php?low_stock=1"
                style="font-size:12px; padding:6px 14px;"
            >
                عرض كافة المنتجات
            </a>
        </div>

        <div style="overflow-x:auto;">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th style="width:5%;">#</th>
                        <th>اسم المنتج</th>
                        <th>الكود (SKU)</th>
                        <th>الصنف</th>
                        <th>الكمية المتبقية</th>
                        <th>الحالة</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach (
                        $lowStockProducts as $index => $product
                    ): ?>
                        <tr>
                            <td>
                                <?= e($index + 1) ?>
                            </td>

                            <td>
                                <strong>
                                    <?= e($product['name']) ?>
                                </strong>
                            </td>

                            <td>
                                <code>
                                    <?= e($product['sku']) ?>
                                </code>
                            </td>

                            <td>
                                <?= e(
                                    $product['category']
                                    ?: 'بدون تصنيف'
                                ) ?>
                            </td>

                            <td>
                                <strong style="color:#dc2626;">
                                    <?= e($product['quantity']) ?>
                                </strong>
                            </td>

                            <td>
                                <span class="badge-danger">
                                    موشك على النفاذ
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<!-- آخر 3 فواتير بيع -->
<div class="dash-card">
    <div class="dash-card-header">
        <div>
            <h3>آخر فواتير البيع</h3>

            <p
                style="
                    margin:4px 0 0;
                    color:var(--dash-text-sub);
                    font-size:12px;
                "
            >
                تظهر آخر ثلاث فواتير بيع مسجلة.
            </p>
        </div>

        <button
            type="button"
            class="btn btn-primary show-more-btn"
            data-open-dialog="salesInvoicesDialog"
        >
            إظهار المزيد
        </button>
    </div>

    <div style="overflow-x:auto;">
        <table class="modern-table">
            <thead>
                <tr>
                    <th>رقم الفاتورة</th>
                    <th>الزبون</th>
                    <th>الإجمالي</th>
                    <th>التاريخ والوقت</th>
                </tr>
            </thead>

            <tbody>
                <?php if (empty($recentInvoices)): ?>
                    <tr>
                        <td
                            colspan="4"
                            style="
                                text-align:center;
                                padding:24px;
                                color:var(--dash-text-sub);
                            "
                        >
                            لا توجد فواتير بيع مسجلة حتى الآن.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentInvoices as $inv): ?>
                        <tr>
                            <td>
                                <strong>
                                    <?= e($inv['invoice_number']) ?>
                                </strong>
                            </td>

                            <td>
                                <?= e(
                                    $inv['customer_name']
                                    ?? 'نقدي'
                                ) ?>
                            </td>

                            <td>
                                <span class="badge-success">
                                    <?= format_money(
                                        $pdo,
                                        $inv['total_amount']
                                    ) ?>
                                </span>
                            </td>

                            <td
                                style="
                                    color:var(--dash-text-sub);
                                "
                            >
                                <?= e($inv['created_at']) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- آخر 3 فواتير شراء -->
<div class="dash-card">
    <div class="dash-card-header">
        <div>
            <h3>آخر فواتير الشراء</h3>

            <p
                style="
                    margin:4px 0 0;
                    color:var(--dash-text-sub);
                    font-size:12px;
                "
            >
                تظهر آخر ثلاث فواتير شراء مسجلة.
            </p>
        </div>

        <button
            type="button"
            class="btn btn-primary show-more-btn"
            data-open-dialog="purchaseInvoicesDialog"
        >
            إظهار المزيد
        </button>
    </div>

    <div style="overflow-x:auto;">
        <table class="modern-table">
            <thead>
                <tr>
                    <th>رقم الفاتورة</th>
                    <th>المورد</th>
                    <th>الإجمالي</th>
                    <th>المدفوع</th>
                    <th>صافي الفاتورة</th>
                    <th>التاريخ والوقت</th>
                </tr>
            </thead>

            <tbody>
                <?php if (empty($recentPurchaseInvoices)): ?>
                    <tr>
                        <td
                            colspan="6"
                            style="
                                text-align:center;
                                padding:24px;
                                color:var(--dash-text-sub);
                            "
                        >
                            لا توجد فواتير شراء مسجلة حتى الآن.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach (
                        $recentPurchaseInvoices as $purchase
                    ): ?>
                        <?php
                            $purchaseTotal = (float)(
                                $purchase['total_amount']
                            );

                            $purchasePaid = (float)(
                                $purchase['paid_amount']
                            );

                            $netInvoiceAmount = round(
                                $purchaseTotal - $purchasePaid,
                                2
                            );
                        ?>

                        <tr>
                            <td>
                                <strong>
                                    <?= e(
                                        $purchase['purchase_number']
                                    ) ?>
                                </strong>
                            </td>

                            <td>
                                <?= e(
                                    $purchase['supplier_name']
                                    ?? 'مورد محذوف'
                                ) ?>
                            </td>

                            <td>
                                <span class="badge-success">
                                    <?= format_money(
                                        $pdo,
                                        $purchaseTotal
                                    ) ?>
                                </span>
                            </td>

                            <td>
                                <span
                                    style="
                                        font-weight:700;
                                        color:#dc2626;
                                    "
                                >
                                    <?= format_money(
                                        $pdo,
                                        $purchasePaid
                                    ) ?>
                                </span>
                            </td>

                            <td>
                                <?php if ($netInvoiceAmount > 0): ?>
                                    <span class="badge-danger">
                                        للمورد:
                                        <?= format_money(
                                            $pdo,
                                            $netInvoiceAmount
                                        ) ?>
                                    </span>
                                <?php elseif ($netInvoiceAmount < 0): ?>
                                    <span class="badge-success">
                                        لنا عند المورد:
                                        <?= format_money(
                                            $pdo,
                                            abs($netInvoiceAmount)
                                        ) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="badge-neutral">
                                        تمت التسوية
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td
                                style="
                                    color:var(--dash-text-sub);
                                "
                            >
                                <?= e(
                                    $purchase['created_at']
                                ) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة سجل فواتير البيع الكامل -->
<dialog
    class="invoices-dialog"
    id="salesInvoicesDialog"
    aria-labelledby="salesInvoicesDialogTitle"
>
    <div class="dialog-header">
        <h2 id="salesInvoicesDialogTitle">
            سجل فواتير البيع الكامل
        </h2>

        <button
            type="button"
            class="dialog-close-btn"
            data-close-dialog="salesInvoicesDialog"
            aria-label="إغلاق نافذة فواتير البيع"
        >
            ×
        </button>
    </div>

    <div class="dialog-body">
        <div class="dialog-tools">
            <span class="dialog-count">
                عدد فواتير البيع:
                <?= e(count($allInvoices)) ?>
            </span>

            <input
                type="search"
                class="dialog-search"
                data-table-search="salesInvoicesTable"
                placeholder="ابحث برقم الفاتورة أو الزبون..."
            >
        </div>

        <div class="dialog-table-wrapper">
            <table
                class="modern-table"
                id="salesInvoicesTable"
            >
                <thead>
                    <tr>
                        <th>#</th>
                        <th>رقم الفاتورة</th>
                        <th>الزبون</th>
                        <th>الإجمالي</th>
                        <th>التاريخ والوقت</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (empty($allInvoices)): ?>
                        <tr>
                            <td
                                colspan="5"
                                class="dialog-empty"
                            >
                                لا توجد فواتير بيع مسجلة حتى الآن.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach (
                            $allInvoices as $index => $inv
                        ): ?>
                            <tr>
                                <td>
                                    <?= e($index + 1) ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= e(
                                            $inv['invoice_number']
                                        ) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= e(
                                        $inv['customer_name']
                                        ?? 'نقدي'
                                    ) ?>
                                </td>

                                <td>
                                    <span class="badge-success">
                                        <?= format_money(
                                            $pdo,
                                            $inv['total_amount']
                                        ) ?>
                                    </span>
                                </td>

                                <td
                                    style="
                                        color:var(--dash-text-sub);
                                    "
                                >
                                    <?= e($inv['created_at']) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</dialog>

<!-- نافذة سجل فواتير الشراء الكامل -->
<dialog
    class="invoices-dialog"
    id="purchaseInvoicesDialog"
    aria-labelledby="purchaseInvoicesDialogTitle"
>
    <div class="dialog-header">
        <h2 id="purchaseInvoicesDialogTitle">
            سجل فواتير الشراء الكامل
        </h2>

        <button
            type="button"
            class="dialog-close-btn"
            data-close-dialog="purchaseInvoicesDialog"
            aria-label="إغلاق نافذة فواتير الشراء"
        >
            ×
        </button>
    </div>

    <div class="dialog-body">
        <div class="dialog-tools">
            <span class="dialog-count">
                عدد فواتير الشراء:
                <?= e(count($allPurchaseInvoices)) ?>
            </span>

            <input
                type="search"
                class="dialog-search"
                data-table-search="purchaseInvoicesTable"
                placeholder="ابحث برقم الفاتورة أو المورد..."
            >
        </div>

        <div class="dialog-table-wrapper">
            <table
                class="modern-table"
                id="purchaseInvoicesTable"
            >
                <thead>
                    <tr>
                        <th>#</th>
                        <th>رقم الفاتورة</th>
                        <th>المورد</th>
                        <th>الإجمالي</th>
                        <th>المدفوع</th>
                        <th>صافي الفاتورة</th>
                        <th>التاريخ والوقت</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (empty($allPurchaseInvoices)): ?>
                        <tr>
                            <td
                                colspan="7"
                                class="dialog-empty"
                            >
                                لا توجد فواتير شراء مسجلة حتى الآن.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach (
                            $allPurchaseInvoices as $index => $purchase
                        ): ?>
                            <?php
                                $purchaseTotal = (float)(
                                    $purchase['total_amount']
                                );

                                $purchasePaid = (float)(
                                    $purchase['paid_amount']
                                );

                                $netInvoiceAmount = round(
                                    $purchaseTotal - $purchasePaid,
                                    2
                                );
                            ?>

                            <tr>
                                <td>
                                    <?= e($index + 1) ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= e(
                                            $purchase['purchase_number']
                                        ) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= e(
                                        $purchase['supplier_name']
                                        ?? 'مورد محذوف'
                                    ) ?>
                                </td>

                                <td>
                                    <span class="badge-success">
                                        <?= format_money(
                                            $pdo,
                                            $purchaseTotal
                                        ) ?>
                                    </span>
                                </td>

                                <td>
                                    <span
                                        style="
                                            font-weight:700;
                                            color:#dc2626;
                                        "
                                    >
                                        <?= format_money(
                                            $pdo,
                                            $purchasePaid
                                        ) ?>
                                    </span>
                                </td>

                                <td>
                                    <?php if ($netInvoiceAmount > 0): ?>
                                        <span class="badge-danger">
                                            للمورد:
                                            <?= format_money(
                                                $pdo,
                                                $netInvoiceAmount
                                            ) ?>
                                        </span>
                                    <?php elseif ($netInvoiceAmount < 0): ?>
                                        <span class="badge-success">
                                            لنا عند المورد:
                                            <?= format_money(
                                                $pdo,
                                                abs($netInvoiceAmount)
                                            ) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge-neutral">
                                            تمت التسوية
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td
                                    style="
                                        color:var(--dash-text-sub);
                                    "
                                >
                                    <?= e(
                                        $purchase['created_at']
                                    ) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</dialog>

<script>
(function () {
    const months = [
        'كانون الثاني',
        'شباط',
        'آذار',
        'نيسان',
        'أيار',
        'حزيران',
        'تموز',
        'آب',
        'أيلول',
        'تشرين الأول',
        'تشرين الثاني',
        'كانون الأول'
    ];

    const days = [
        'الأحد',
        'الاثنين',
        'الثلاثاء',
        'الأربعاء',
        'الخميس',
        'الجمعة',
        'السبت'
    ];

    function updateClock() {
        const now = new Date();

        let hours = now.getHours();

        const ampm = hours >= 12 ? 'PM' : 'AM';

        hours = hours % 12;

        hours = hours ? hours : 12;

        const hoursText = String(hours).padStart(2, '0');

        const minutesText = String(
            now.getMinutes()
        ).padStart(2, '0');

        const secondsText = String(
            now.getSeconds()
        ).padStart(2, '0');

        document.getElementById('liveClock').textContent =
            hoursText
            + ':'
            + minutesText
            + ':'
            + secondsText
            + ' '
            + ampm;

        document.getElementById('liveDate').textContent =
            days[now.getDay()]
            + '، '
            + now.getDate()
            + ' '
            + months[now.getMonth()]
            + ' '
            + now.getFullYear();
    }

    function openDialog(dialogId) {
        const dialog = document.getElementById(dialogId);

        if (!dialog) {
            return;
        }

        if (typeof dialog.showModal === 'function') {
            dialog.showModal();
        } else {
            /*
             * احتياط للمتصفحات القديمة.
             */
            dialog.setAttribute('open', 'open');
        }
    }

    function closeDialog(dialogId) {
        const dialog = document.getElementById(dialogId);

        if (!dialog) {
            return;
        }

        if (typeof dialog.close === 'function') {
            dialog.close();
        } else {
            dialog.removeAttribute('open');
        }
    }

    function filterDialogTable(searchInput) {
        const tableId = searchInput.dataset.tableSearch;

        const table = document.getElementById(tableId);

        if (!table) {
            return;
        }

        const keyword = String(searchInput.value || '')
            .trim()
            .toLowerCase();

        const rows = table.querySelectorAll('tbody tr');

        rows.forEach(function (row) {
            const text = String(
                row.textContent || row.innerText || ''
            ).toLowerCase();

            if (
                row.querySelectorAll('td').length <= 1
            ) {
                return;
            }

            row.style.display =
                text.indexOf(keyword) !== -1
                    ? ''
                    : 'none';
        });
    }

    document.querySelectorAll('[data-open-dialog]').forEach(
        function (button) {
            button.addEventListener('click', function () {
                openDialog(
                    button.dataset.openDialog
                );
            });
        }
    );

    document.querySelectorAll('[data-close-dialog]').forEach(
        function (button) {
            button.addEventListener('click', function () {
                closeDialog(
                    button.dataset.closeDialog
                );
            });
        }
    );

    document.querySelectorAll('[data-table-search]').forEach(
        function (input) {
            input.addEventListener('input', function () {
                filterDialogTable(input);
            });
        }
    );

    document.querySelectorAll('dialog.invoices-dialog').forEach(
        function (dialog) {
            dialog.addEventListener('click', function (event) {
                const rect = dialog.getBoundingClientRect();

                const clickedOutside =
                    event.clientX < rect.left
                    || event.clientX > rect.right
                    || event.clientY < rect.top
                    || event.clientY > rect.bottom;

                if (clickedOutside) {
                    dialog.close();
                }
            });
        }
    );

    setInterval(updateClock, 1000);

    updateClock();
})();
</script>

<?php require_once 'includes/footer.php'; ?>