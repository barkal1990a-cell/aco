<?php
require_once 'config/database.php';
require_once 'includes/header.php';

date_default_timezone_set('Asia/Damascus');

/*
|--------------------------------------------------------------------------
| 1. معالجة مدخلات الفلترة (اختيار السنة)
|--------------------------------------------------------------------------
*/
$selectedYear = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

if ($selectedYear < 2000 || $selectedYear > 2100) {
    $selectedYear = (int)date('Y');
}

/*
|--------------------------------------------------------------------------
| 2. جلب البيانات المالية باستخدام Prepared Statements
|--------------------------------------------------------------------------
*/

// أ) إجمالي المبيعات والمقبوضات السنوية
$stmtInvoices = $pdo->prepare("
    SELECT 
        COALESCE(SUM(total_amount), 0) AS total_sales,
        COALESCE(SUM(paid_amount), 0) AS total_paid
    FROM invoices 
    WHERE YEAR(created_at) = ?
");
$stmtInvoices->execute([$selectedYear]);
$invoiceData = $stmtInvoices->fetch(PDO::FETCH_ASSOC);

$sales = (float)$invoiceData['total_sales'];
$paid  = (float)$invoiceData['total_paid'];

// ب) إجمالي المصروفات السنوية
$stmtExpenses = $pdo->prepare("
    SELECT COALESCE(SUM(amount), 0) 
    FROM expenses 
    WHERE YEAR(expense_date) = ?
");
$stmtExpenses->execute([$selectedYear]);
$expenses = (float)$stmtExpenses->fetchColumn();

// جـ) إجمالي تكلفة البضاعة المباعة (COGS)
$stmtCost = $pdo->prepare("
    SELECT COALESCE(SUM(ii.quantity * p.purchase_price), 0)
    FROM invoice_items ii 
    JOIN products p ON p.id = ii.product_id 
    JOIN invoices i ON i.id = ii.invoice_id 
    WHERE YEAR(i.created_at) = ?
");
$stmtCost->execute([$selectedYear]);
$cost = (float)$stmtCost->fetchColumn();

/*
|--------------------------------------------------------------------------
| 3. العمليات الحسابية والمؤشرات المالية
|--------------------------------------------------------------------------
*/
$profit           = $sales - $cost - $expenses;
$netCash          = $paid - $expenses;
$profitMargin     = ($sales > 0) ? ($profit / $sales) * 100 : 0;
$avgMonthlySales  = $sales / 12;
$avgMonthlyProfit = $profit / 12;
?>

<!-- ---------------------------------------------------------
     4. التنسيقات العصرية المدمجة (Embedded Modern CSS)
----------------------------------------------------------- -->
<style>
.report-header {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 1.25rem 1.5rem;
    margin-bottom: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
    flex-wrap: wrap;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
}

.report-title h1 {
    margin: 0;
    font-size: 1.4rem;
    color: #1e293b;
    font-weight: 700;
}
.report-title p {
    margin: 0.25rem 0 0 0;
    color: #64748b;
    font-size: 0.875rem;
}

.filter-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 1rem 1.25rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
}

.filter-form {
    display: flex;
    align-items: center;
    gap: 1rem;
    flex-wrap: wrap;
}

.filter-group {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.filter-group label {
    font-size: 0.875rem;
    font-weight: 600;
    color: #334155;
    white-space: nowrap;
}

.form-select {
    padding: 0.5rem 0.85rem;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 0.875rem;
    color: #1e293b;
    background-color: #ffffff;
    cursor: pointer;
    outline: none;
    transition: all 0.2s ease;
}
.form-select:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 1.25rem;
    margin-bottom: 1.5rem;
}

.stat-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 1.25rem;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
    position: relative;
    overflow: hidden;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.05);
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 4px;
    height: 100%;
}

.stat-card.sales::before { background-color: #2563eb; }
.stat-card.paid::before { background-color: #10b981; }
.stat-card.expenses::before { background-color: #ef4444; }
.stat-card.cost::before { background-color: #f59e0b; }
.stat-card.profit-positive::before { background-color: #059669; }
.stat-card.profit-negative::before { background-color: #dc2626; }
.stat-card.netcash::before { background-color: #06b6d4; }

.stat-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0.75rem;
}

.stat-header h3 {
    margin: 0;
    font-size: 0.875rem;
    font-weight: 600;
    color: #64748b;
}

.stat-icon {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f8fafc;
}
.stat-icon svg {
    width: 20px;
    height: 20px;
}

.stat-value {
    font-size: 1.35rem;
    font-weight: 700;
    color: #0f172a;
    line-height: 1.2;
}

.stat-badge {
    display: inline-block;
    margin-top: 0.5rem;
    padding: 0.2rem 0.55rem;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 600;
}
.badge-info { background: #e0f2fe; color: #0369a1; }
.badge-success { background: #dcfce7; color: #166534; }
.badge-danger { background: #fee2e2; color: #991b1b; }

.btn {
    padding: 0.55rem 1.25rem;
    border-radius: 8px;
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid transparent;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.2s ease;
}
.btn-primary { background-color: #2563eb; color: #ffffff; }
.btn-primary:hover { background-color: #1d4ed8; }
.btn-secondary { background-color: #f1f5f9; color: #334155; border-color: #cbd5e1; }
.btn-secondary:hover { background-color: #e2e8f0; }

@media (max-width: 640px) {
    .report-header {
        flex-direction: column;
        align-items: flex-start;
    }
    .filter-form {
        width: 100%;
        flex-direction: column;
        align-items: stretch;
    }
    .filter-group {
        width: 100%;
        justify-content: space-between;
    }
    .form-select {
        width: 60%;
    }
}
</style>

<!-- ---------------------------------------------------------
     5. واجهة المستخدم (HTML Content)
----------------------------------------------------------- -->

<!-- ترويسة التقرير السنوي -->
<div class="report-header">
    <div class="report-title">
        <h1>التقرير المالي السنوي العام</h1>
        <p>ملخص الحركة المالية الشاملة لعام <strong><?= $selectedYear ?></strong></p>
    </div>
    <a class="btn btn-primary" target="_blank" href="reports_yearly_print.php?year=<?= $selectedYear ?>">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/>
        </svg>
        طباعة التقرير السنوي
    </a>
</div>

<!-- شريط اختيار السنة -->
<div class="filter-card">
    <form method="get" action="reports_yearly.php" class="filter-form">
        <div class="filter-group">
            <label for="year">اختر السنة المالية:</label>
            <select name="year" id="year" class="form-select">
                <?php 
                $currentY = (int)date('Y');
                for ($y = $currentY; $y >= $currentY - 7; $y--): 
                ?>
                    <option value="<?= $y ?>" <?= $y === $selectedYear ? 'selected' : '' ?>>
                        سنة <?= $y ?>
                    </option>
                <?php endfor; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-secondary">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"/>
            </svg>
            عرض البيانات
        </button>
    </form>
</div>

<!-- شبكة المؤشرات السنوية STATS GRID -->
<div class="stats-grid">
    
    <!-- إجمالي المبيعات السنوية -->
    <div class="stat-card sales">
        <div class="stat-header">
            <h3>إجمالي المبيعات</h3>
            <div class="stat-icon" style="color: #2563eb;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
                </svg>
            </div>
        </div>
        <div class="stat-value"><?= format_money($pdo, $sales) ?></div>
        <span class="stat-badge badge-info">
            المتوسط الشهري: <?= format_money($pdo, $avgMonthlySales) ?>
        </span>
    </div>

    <!-- إجمالي المقبوضات -->
    <div class="stat-card paid">
        <div class="stat-header">
            <h3>إجمالي المقبوضات</h3>
            <div class="stat-icon" style="color: #10b981;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
            </div>
        </div>
        <div class="stat-value"><?= format_money($pdo, $paid) ?></div>
        <span class="stat-badge badge-info">
            نسبة التحصيل: <?= $sales > 0 ? number_format(($paid / $sales) * 100, 1) : 0 ?>%
        </span>
    </div>

    <!-- تكلفة البضاعة المباعة -->
    <div class="stat-card cost">
        <div class="stat-header">
            <h3>تكلفة البضاعة المباعة</h3>
            <div class="stat-icon" style="color: #f59e0b;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                </svg>
            </div>
        </div>
        <div class="stat-value"><?= format_money($pdo, $cost) ?></div>
    </div>

    <!-- إجمالي المصروفات السنوية -->
    <div class="stat-card expenses">
        <div class="stat-header">
            <h3>إجمالي المصروفات</h3>
            <div class="stat-icon" style="color: #ef4444;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
        </div>
        <div class="stat-value"><?= format_money($pdo, $expenses) ?></div>
    </div>

    <!-- الربح السنوي الصافي -->
    <div class="stat-card <?= $profit >= 0 ? 'profit-positive' : 'profit-negative' ?>">
        <div class="stat-header">
            <h3>الربح السنوي الصافي</h3>
            <div class="stat-icon" style="color: <?= $profit >= 0 ? '#059669' : '#dc2626' ?>;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V6m0 12v-2m0 0c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
        </div>
        <div class="stat-value" style="color: <?= $profit >= 0 ? '#059669' : '#dc2626' ?>;">
            <?= format_money($pdo, $profit) ?>
        </div>
        <span class="stat-badge <?= $profit >= 0 ? 'badge-success' : 'badge-danger' ?>">
            هامش الربح: <?= number_format($profitMargin, 1) ?>% | (شهرياً: <?= format_money($pdo, $avgMonthlyProfit) ?>)
        </span>
    </div>

    <!-- الصافي النقدي السنوي -->
    <div class="stat-card netcash">
        <div class="stat-header">
            <h3>الصافي النقدي العام (المقبوض - المصاريف)</h3>
            <div class="stat-icon" style="color: #06b6d4;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
        </div>
        <div class="stat-value"><?= format_money($pdo, $netCash) ?></div>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>