<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_login();

$invoiceId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($invoiceId <= 0) {
    die('رقم الفاتورة غير صالح');
}

$stmt = $pdo->prepare("
    SELECT 
        i.*,
        c.name AS customer_name,
        c.phone AS customer_phone,
        c.address AS customer_address
    FROM invoices i
    LEFT JOIN customers c ON c.id = i.customer_id
    WHERE i.id = ?
");

$stmt->execute([$invoiceId]);
$invoice = $stmt->fetch();

if (!$invoice) {
    die('الفاتورة غير موجودة');
}

$itemStmt = $pdo->prepare("
    SELECT *
    FROM invoice_items
    WHERE invoice_id = ?
    ORDER BY id ASC
");

$itemStmt->execute([$invoiceId]);
$items = $itemStmt->fetchAll();

/*
 * نوع البيع:
 * - نقدي عند تسديد كامل الفاتورة.
 * - آجل عند بقاء أي مبلغ على الزبون.
 * لا علاقة لاختيار زبون بنوع البيع بحد ذاته.
 */
$saleType = (float)$invoice['remaining_amount'] > 0 ? 'آجل' : 'نقدي';

$templatePath = __DIR__ . '/templates/invoice_a5_template.html';

if (!file_exists($templatePath)) {
    $templatesDirectory = dirname($templatePath);

    if (!is_dir($templatesDirectory)) {
        mkdir($templatesDirectory, 0777, true);
    }

    $defaultTemplate = <<<'HTML'
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>{{invoice_number}}</title>
<style>
@page { size: A5 portrait; margin: 10mm; }
body{font-family:Tahoma,Arial,sans-serif;margin:0;background:#f3f5f9;color:#222}
.sheet{width:148mm;min-height:210mm;background:#fff;margin:10px auto;padding:10mm;box-shadow:0 0 15px rgba(0,0,0,.08);box-sizing:border-box}
.head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #0d6efd;padding-bottom:10px;margin-bottom:12px}
.brand h1{margin:0 0 6px;font-size:24px}.brand p{margin:0;color:#666;font-size:12px}
.meta{font-size:12px;line-height:1.8}.meta strong{display:inline-block;min-width:88px}
.customer{background:#f8fbff;border:1px solid #dbe7ff;border-radius:12px;padding:10px;margin-bottom:12px}
.customer h3{margin:0 0 8px;font-size:15px}.customer p{margin:4px 0;font-size:13px}
table{width:100%;border-collapse:collapse;font-size:13px}.items th,.items td{border:1px solid #d8e0ec;padding:8px;text-align:right}.items th{background:#eef4ff}
.summary{margin-top:12px;margin-right:auto;width:45%}.summary table td{padding:8px;border:1px solid #d8e0ec}.summary .final td{font-weight:700;background:#f7fbf2}
.notes{margin-top:14px;padding:10px;border:1px dashed #c9d3df;border-radius:10px;font-size:13px;min-height:50px}
.actions{display:flex;gap:10px;justify-content:center;margin:18px 0}.btn{background:#0d6efd;color:#fff;border:none;border-radius:10px;padding:10px 14px;cursor:pointer;text-decoration:none;font-size:14px}.btn.secondary{background:#6c757d}.print-hide{display:block}
@media print{body{background:#fff}.sheet{margin:0;box-shadow:none}.print-hide{display:none}}
</style>
</head>
<body>
<div class="actions print-hide">
    <button class="btn" onclick="window.print()">طباعة الفاتورة</button>
    <a class="btn secondary" href="invoice_history.php">العودة لسجل الفواتير</a>
</div>
<div class="sheet">
    <div class="head">
        <div class="brand">
            <h1>{{company_name}}</h1>
            <p>{{company_tagline}}</p>
        </div>
        <div class="meta">
            <div><strong>رقم الفاتورة:</strong> {{invoice_number}}</div>
            <div><strong>التاريخ:</strong> {{invoice_date}}</div>
            <div><strong>نوع البيع:</strong> {{sale_type}}</div>
        </div>
    </div>

    <div class="customer">
        <h3>بيانات الزبون</h3>
        <p><strong>الاسم:</strong> {{customer_name}}</p>
        <p><strong>الهاتف:</strong> {{customer_phone}}</p>
        <p><strong>العنوان:</strong> {{customer_address}}</p>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th>#</th>
                <th>الصنف</th>
                <th>الكمية</th>
                <th>السعر الفردي</th>
                <th>الإجمالي</th>
            </tr>
        </thead>
        <tbody>
            {{invoice_rows}}
        </tbody>
    </table>

    <div class="summary">
        <table>
            <tr><td>إجمالي الفاتورة</td><td>{{total_amount}}</td></tr>
            <tr><td>المدفوع</td><td>{{paid_amount}}</td></tr>
            <tr class="final"><td>المتبقي</td><td>{{remaining_amount}}</td></tr>
        </table>
    </div>

    <div class="notes">
        <strong>ملاحظات:</strong><br>
        {{notes}}
    </div>
</div>
</body>
</html>
HTML;

    file_put_contents($templatePath, $defaultTemplate);
}

$template = file_get_contents($templatePath);

$rowsHtml = '';
$counter = 1;

foreach ($items as $item) {
    $rowsHtml .= '<tr>'
        . '<td>' . $counter++ . '</td>'
        . '<td>' . e($item['product_name']) . '</td>'
        . '<td>' . e((string)$item['quantity']) . '</td>'
        . '<td>' . format_money($pdo, $item['unit_price']) . '</td>'
        . '<td>' . format_money($pdo, $item['total_price']) . '</td>'
        . '</tr>';
}

$replacements = [
    '{{company_name}}'     => e(app_setting($pdo, 'store_name', 'برنامج المحاسبة')),
    '{{company_tagline}}'  => 'فاتورة مبيعات',
    '{{invoice_number}}'   => e($invoice['invoice_number']),
    '{{invoice_date}}'     => e($invoice['created_at']),
    '{{sale_type}}'        => $saleType,
    '{{customer_name}}'    => e($invoice['customer_name'] ?: 'زبون نقدي'),
    '{{customer_phone}}'   => e($invoice['customer_phone'] ?: '-'),
    '{{customer_address}}' => e($invoice['customer_address'] ?: '-'),
    '{{invoice_rows}}'     => $rowsHtml,
    '{{total_amount}}'     => format_money($pdo, $invoice['total_amount']),
    '{{paid_amount}}'      => format_money($pdo, $invoice['paid_amount']),
    '{{remaining_amount}}' => format_money($pdo, $invoice['remaining_amount']),
    '{{notes}}'             => nl2br(e($invoice['notes'] ?: 'لا توجد ملاحظات')),
];

$output = strtr($template, $replacements);

/* إنشاء مجلد الفواتير المحفوظة إن لم يكن موجودًا */
$generatedInvoicesPath = __DIR__ . '/generated_invoices/';

if (!is_dir($generatedInvoicesPath)) {
    mkdir($generatedInvoicesPath, 0777, true);
}

$saveHtml = $generatedInvoicesPath . $invoice['invoice_number'] . '.html';
file_put_contents($saveHtml, $output);

echo $output;
?>