<?php
require_once 'config/database.php';
require_once 'includes/header.php';

/* جدول مستقل للتصنيفات بدون تصنيف أب */
$pdo->exec("CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* إزالة عمود parent_id إن كان موجودًا من النسخة القديمة */
$parentColumn = $pdo->query("SHOW COLUMNS FROM categories LIKE 'parent_id'");
if ($parentColumn->rowCount() > 0) {
    try {
        $pdo->exec("ALTER TABLE categories DROP FOREIGN KEY fk_category_parent");
    } catch (Throwable $e) {
        /* قد لا يكون المفتاح موجودًا في بعض قواعد البيانات */
    }
    try {
        $pdo->exec("ALTER TABLE categories DROP COLUMN parent_id");
    } catch (Throwable $e) {
        /* تجاهل الخطأ إن كان العمود قد حُذف سابقًا */
    }
}

/* التأكد من وجود category_id في جدول المنتجات */
$categoryColumn = $pdo->query("SHOW COLUMNS FROM products LIKE 'category_id'");
if ($categoryColumn->rowCount() === 0) {
    $pdo->exec("ALTER TABLE products ADD COLUMN category_id INT NULL AFTER category");
}

/* نقل أسماء التصنيفات القديمة إلى جدول التصنيفات بدون مقارنة Collation بين جدولين */
$oldCategories = $pdo->query("SELECT DISTINCT TRIM(category) AS category_name FROM products WHERE category IS NOT NULL AND TRIM(category) <> ''")->fetchAll();
$findCategory = $pdo->prepare("SELECT id FROM categories WHERE name = ? LIMIT 1");
$insertCategory = $pdo->prepare("INSERT INTO categories(name) VALUES(?)");
$updateProductCategory = $pdo->prepare("UPDATE products SET category_id=? WHERE category_id IS NULL AND TRIM(category)=?");

foreach ($oldCategories as $oldCategory) {
    $categoryName = trim($oldCategory['category_name']);
    if ($categoryName === '') continue;

    $findCategory->execute([$categoryName]);
    $categoryId = $findCategory->fetchColumn();
    if (!$categoryId) {
        $insertCategory->execute([$categoryName]);
        $categoryId = $pdo->lastInsertId();
    }
    $updateProductCategory->execute([(int)$categoryId, $categoryName]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_category'])) {
        $name = trim($_POST['category_name'] ?? '');
        if ($name === '') {
            set_flash('error', 'يرجى إدخال اسم التصنيف');
        } else {
            $check = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE name=?");
            $check->execute([$name]);
            if ((int)$check->fetchColumn() > 0) {
                set_flash('error', 'هذا التصنيف موجود مسبقًا');
            } else {
                $pdo->prepare("INSERT INTO categories(name) VALUES(?)")->execute([$name]);
                set_flash('success', 'تمت إضافة التصنيف بنجاح');
            }
        }
        redirect('categories.php');
    }

    if (isset($_POST['update_category'])) {
        $id = (int)$_POST['category_id'];
        $name = trim($_POST['category_name'] ?? '');
        if ($id > 0 && $name !== '') {
            $check = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE name=? AND id<>?");
            $check->execute([$name, $id]);
            if ((int)$check->fetchColumn() > 0) {
                set_flash('error', 'هذا التصنيف موجود مسبقًا');
            } else {
                $pdo->prepare("UPDATE categories SET name=? WHERE id=?")->execute([$name, $id]);
                $pdo->prepare("UPDATE products SET category=? WHERE category_id=?")->execute([$name, $id]);
                set_flash('success', 'تم تعديل التصنيف وتحديث المنتجات المرتبطة به');
            }
        }
        redirect('categories.php');
    }

    if (isset($_POST['delete_category'])) {
        $id = (int)$_POST['category_id'];
        if ($id > 0) {
            $pdo->beginTransaction();
            try {
                $pdo->prepare("UPDATE products SET category_id=NULL, category='' WHERE category_id=?")->execute([$id]);
                $pdo->prepare("DELETE FROM categories WHERE id=?")->execute([$id]);
                $pdo->commit();
                set_flash('warning', 'تم حذف التصنيف وإلغاء ارتباطه بالمنتجات');
            } catch (Throwable $e) {
                $pdo->rollBack();
                set_flash('error', 'تعذر حذف التصنيف: ' . $e->getMessage());
            }
        }
        redirect('categories.php');
    }
}

$editCategory = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editCategory = $stmt->fetch();
}

$categories = $pdo->query("SELECT c.*, COUNT(p.id) AS products_count FROM categories c LEFT JOIN products p ON p.category_id=c.id GROUP BY c.id, c.name, c.created_at ORDER BY c.name ASC")->fetchAll();
?>

<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
        <h1 style="margin:0;">التصنيفات</h1>
        <a class="btn btn-secondary" href="products.php">العودة إلى المستودع</a>
    </div>
</div>

<div class="card">
    <h3><?= $editCategory ? 'تعديل التصنيف' : 'إضافة تصنيف جديد' ?></h3>
    <form method="post" class="form-grid">
        <input type="hidden" name="<?= $editCategory ? 'update_category' : 'add_category' ?>" value="1">
        <?php if ($editCategory): ?>
            <input type="hidden" name="category_id" value="<?= e((string)$editCategory['id']) ?>">
        <?php endif; ?>
        <div class="form-group">
            <label>اسم التصنيف</label>
            <input name="category_name" required value="<?= e($editCategory['name'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>&nbsp;</label>
            <button class="btn btn-primary"><?= $editCategory ? 'حفظ التعديل' : 'إضافة التصنيف' ?></button>
        </div>
    </form>
</div>

<div class="card">
    <h3>كل التصنيفات</h3>
    <table class="table">
        <thead>
            <tr><th>#</th><th>اسم التصنيف</th><th>عدد المنتجات</th><th>تاريخ الإنشاء</th><th>تعديل</th><th>حذف</th></tr>
        </thead>
        <tbody>
            <?php foreach ($categories as $category): ?>
                <tr>
                    <td><?= e((string)$category['id']) ?></td>
                    <td><?= e($category['name']) ?></td>
                    <td><?= e((string)$category['products_count']) ?></td>
                    <td><?= e($category['created_at']) ?></td>
                    <td><a class="btn btn-warning" href="categories.php?edit=<?= e((string)$category['id']) ?>">تعديل</a></td>
                    <td>
                        <form method="post" onsubmit="return confirm('سيتم إلغاء ارتباط التصنيف بكل المنتجات. هل تريد المتابعة؟')">
                            <input type="hidden" name="delete_category" value="1">
                            <input type="hidden" name="category_id" value="<?= e((string)$category['id']) ?>">
                            <button class="btn btn-danger">حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once 'includes/footer.php'; ?>