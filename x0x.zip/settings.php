<?php
require_once 'config/database.php';
require_once 'includes/header.php';

ensure_settings_table($pdo);

/*
|--------------------------------------------------------------------------
| 1. الإعدادات العامة والقيم الافتراضية
|--------------------------------------------------------------------------
*/
$defaultSettings = [
    'store_name'     => 'برنامج المحاسبة',
    'store_phone'    => '',
    'store_address'  => '',
    'store_country'  => 'سوريا',
    'currency'       => 'ل.س',
    'invoice_footer' => 'شكراً لزيارتكم! البضاعة المباعة ترجع وتستبدل خلال 3 أيام.'
];

/*
|--------------------------------------------------------------------------
| 2. معالجة حفظ إعدادات المتجر
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $stmt = $pdo->prepare("
        INSERT INTO settings (
            setting_key,
            setting_value
        ) VALUES (?, ?)
        ON DUPLICATE KEY UPDATE
            setting_value = VALUES(setting_value)
    ");

    foreach ($defaultSettings as $key => $defaultValue) {
        $value = trim($_POST[$key] ?? '');

        /*
         * عدم السماح بفراغ اسم المتجر أو العملة.
         */
        if (
            $value === '' &&
            in_array($key, ['store_name', 'currency'], true)
        ) {
            $value = $defaultValue;
        }

        $stmt->execute([
            $key,
            $value
        ]);
    }

    set_flash('success', 'تم حفظ إعدادات النظام بنجاح');

    redirect('settings.php');
}

/*
|--------------------------------------------------------------------------
| 3. تغيير كلمة مرور المستخدم الحالي
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword     = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    $userId = (int)($_SESSION['user_id'] ?? 0);

    if ($userId <= 0) {
        set_flash('danger', 'تعذر تحديد المستخدم الحالي. يرجى تسجيل الدخول مجددًا.');
        redirect('settings.php');
    }

    if ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') {
        set_flash('danger', 'يرجى تعبئة كافة حقول كلمات المرور المطلوبة.');
        redirect('settings.php');
    }

    if (mb_strlen($newPassword) < 6) {
        set_flash('danger', 'يجب أن تتكون كلمة المرور الجديدة من 6 أحرف على الأقل.');
        redirect('settings.php');
    }

    if ($newPassword !== $confirmPassword) {
        set_flash('danger', 'كلمة المرور الجديدة وتأكيدها غير متطابقين.');
        redirect('settings.php');
    }

    $userStmt = $pdo->prepare("
        SELECT id, username, password
        FROM users
        WHERE id = ?
        LIMIT 1
    ");
    $userStmt->execute([$userId]);
    $currentUser = $userStmt->fetch(PDO::FETCH_ASSOC);

    if (!$currentUser) {
        set_flash('danger', 'المستخدم الحالي غير موجود في قاعدة البيانات.');
        redirect('settings.php');
    }

    $isHashed = password_get_info($currentUser['password'])['algo'] !== 0;

    if ($isHashed) {
        $passwordValid = password_verify($currentPassword, $currentUser['password']);
    } else {
        $passwordValid = hash_equals((string)$currentUser['password'], $currentPassword);
    }

    if (!$passwordValid) {
        set_flash('danger', 'كلمة المرور الحالية غير صحيحة.');
        redirect('settings.php');
    }

    $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

    $updatePasswordStmt = $pdo->prepare("
        UPDATE users
        SET password = ?
        WHERE id = ?
    ");
    $updatePasswordStmt->execute([$newPasswordHash, $userId]);

    set_flash('success', 'تم تغيير كلمة المرور وتحديث أمان الحساب بنجاح.');
    redirect('settings.php');
}

/*
|--------------------------------------------------------------------------
| 4. تفريغ البيانات التشغيلية من قاعدة البيانات
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_database'])) {
    $currentPassword = $_POST['clear_current_password'] ?? '';
    $confirmation    = trim($_POST['clear_confirmation'] ?? '');

    $userId = (int)($_SESSION['user_id'] ?? 0);

    if ($userId <= 0) {
        set_flash('danger', 'تعذر تحديد المستخدم الحالي. يرجى تسجيل الدخول مجددًا.');
        redirect('settings.php');
    }

    if ($currentPassword === '') {
        set_flash('danger', 'يرجى إدخال كلمة المرور لتأكيد عملية تفريغ البيانات.');
        redirect('settings.php');
    }

    if ($confirmation !== 'نعم') {
        set_flash('danger', 'لم يتم تفريغ البيانات. يجب كتابة كلمة "نعم" بشكل صحيح للتأكيد.');
        redirect('settings.php');
    }

    $userStmt = $pdo->prepare("
        SELECT id, password
        FROM users
        WHERE id = ?
        LIMIT 1
    ");
    $userStmt->execute([$userId]);
    $currentUser = $userStmt->fetch(PDO::FETCH_ASSOC);

    if (!$currentUser) {
        set_flash('danger', 'المستخدم الحالي غير موجود في قاعدة البيانات.');
        redirect('settings.php');
    }

    $isHashed = password_get_info($currentUser['password'])['algo'] !== 0;

    if ($isHashed) {
        $passwordValid = password_verify($currentPassword, $currentUser['password']);
    } else {
        $passwordValid = hash_equals((string)$currentUser['password'], $currentPassword);
    }

    if (!$passwordValid) {
        set_flash('danger', 'كلمة المرور غير صحيحة. لم يتم حذف أي بيانات.');
        redirect('settings.php');
    }

    try {
        $tablesToClear = [
            'invoice_items',
            'purchase_invoice_items',
            'employee_advances',
            'employee_salary_months',
            'invoices',
            'purchase_invoices',
            'expenses',
            'cashbox',
            'products',
            'categories',
            'customers',
            'suppliers',
            'employees'
        ];

        $pdo->beginTransaction();

        foreach ($tablesToClear as $table) {
            $checkTableStmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM information_schema.tables
                WHERE table_schema = DATABASE()
                  AND table_name = ?
            ");
            $checkTableStmt->execute([$table]);
            if ((int)$checkTableStmt->fetchColumn() > 0) {
                $pdo->exec("DELETE FROM `$table`");
            }
        }

        unset($_SESSION['cart']);
        unset($_SESSION['purchase_cart']);
        unset($_SESSION['last_saved_invoice_id']);

        $pdo->commit();

        foreach ($tablesToClear as $table) {
            $checkTableStmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM information_schema.tables
                WHERE table_schema = DATABASE()
                  AND table_name = ?
            ");
            $checkTableStmt->execute([$table]);
            if ((int)$checkTableStmt->fetchColumn() > 0) {
                $pdo->exec("ALTER TABLE `$table` AUTO_INCREMENT = 1");
            }
        }

        set_flash('success', 'تم تفريغ البيانات التشغيلية بنجاح. تم الإبقاء على المستخدمين وإعدادات المتجر.');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {$pdo->rollBack();
        }
        set_flash('danger', 'فشل تفريغ البيانات: ' . $e->getMessage());
    }

    redirect('settings.php');
}

/*
|--------------------------------------------------------------------------
| 5. جلب الإعدادات الحالية
|--------------------------------------------------------------------------
*/
$settings = [];
foreach ($defaultSettings as$key => $defaultValue) {$settings[$key] = app_setting($pdo, $key,$defaultValue);
}

// قائمة الدول العربية والعملات المرتبطة بها
$arabCountries = [
    'سوريا'         => 'ل.س',
    'السعودية'      => 'ر.س',
    'الإمارات'      => 'د.إ',
    'مصر'           => 'ج.م',
    'العراق'        => 'د.ع',
    'الأردن'        => 'د.أ',
    'الكويت'        => 'د.ك',
    'قطر'           => 'ر.ق',
    'سلطنة عمان'    => 'ر.ع',
    'البحرين'       => 'د.ب',
    'اليمن'         => 'ر.ي',
    'لبنان'         => 'ل.ل',
    'فلسطين'        => 'شيكل',
    'ليبيا'         => 'د.ل',
    'تونس'          => 'د.ت',
    'الجزائر'       => 'د.ج',
    'المغرب'        => 'د.م',
    'السودان'       => 'ج.س',
    'موريتانيا'     => 'أ.م',
    'الصومال'       => 'ش.ص',
    'جيبوتي'        => 'ف.ج',
    'جزر القمر'     => 'ف.ج.ق'
];
?>

<style>
.settings-hero {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
}

.settings-hero h1 {
    margin: 0 0 0.35rem 0;
    font-size: 1.5rem;
    color: #1e293b;
    font-weight: 700;
}

.settings-hero p {
    margin: 0;
    color: #64748b;
    font-size: 0.925rem;
    line-height: 1.5;
}

.settings-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
    margin-bottom: 1.5rem;
}

.settings-card-title {
    font-size: 1.1rem;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 1.25rem;
    padding-bottom: 0.65rem;
    border-bottom: 2px solid #f1f5f9;
    display: flex;
    align-items: center;
    gap: 0.6rem;
}

.settings-card-title svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
}

.form-grid-2 {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.25rem;
}

.form-group {
    margin-bottom: 1.25rem;
}

.form-group label {
    display: block;
    font-size: 0.875rem;
    font-weight: 600;
    color: #334155;
    margin-bottom: 0.4rem;
}

.input-group {
    position: relative;
    display: flex;
    align-items: center;
}

.form-control {
    width: 100%;
    padding: 0.65rem 0.85rem;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 0.925rem;
    color: #1e293b;
    background-color: #ffffff;
    box-sizing: border-box;
    transition: all 0.2s ease;
}

.form-control:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
}

textarea.form-control {
    resize: vertical;
    min-height: 85px;
}

.toggle-password-btn {
    position: absolute;
    left: 8px;
    background: none;
    border: none;
    cursor: pointer;
    color: #94a3b8;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.form-hint {
    display: block;
    font-size: 0.775rem;
    color: #94a3b8;
    margin-top: 0.35rem;
}

.btn {
    padding: 0.65rem 1.5rem;
    border-radius: 8px;
    font-size: 0.925rem;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid transparent;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.btn-primary { background-color: #2563eb; color: #ffffff; }
.btn-primary:hover { background-color: #1d4ed8; }

.btn-secondary { background-color: #475569; color: #ffffff; }
.btn-secondary:hover { background-color: #334155; }

.btn-warning { background-color: #d97706; color: #ffffff; }
.btn-warning:hover { background-color: #b45309; }

.btn-danger-custom { background-color: #dc2626; color: #ffffff; }
.btn-danger-custom:hover { background-color: #b91c1c; }

.quick-actions-bar {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
    margin-top: 1.5rem;
    padding-top: 1.25rem;
    border-top: 2px solid #f1f5f9;
}

/* Modals Styling */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(15, 23, 42, 0.6);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.25s ease;
    padding: 1rem;
}

.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}

.modal-container {
    background: #ffffff;
    border-radius: 12px;
    width: 100%;
    max-width: 520px;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    transform: translateY(-20px);
    transition: all 0.25s ease;
    overflow: hidden;
}

.modal-overlay.active .modal-container {
    transform: translateY(0);
}

.modal-header {
    padding: 1.25rem 1.5rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #e2e8f0;
}

.modal-header h3 {
    margin: 0;
    font-size: 1.15rem;
    color: #1e293b;
    font-weight: 700;
}

.modal-close-btn {
    background: none;
    border: none;
    font-size: 1.5rem;
    color: #94a3b8;
    cursor: pointer;
    line-height: 1;
    padding: 0;
}

.modal-close-btn:hover { color: #1e293b; }

.modal-body {
    padding: 1.5rem;
}

.modal-footer {
    padding: 1rem 1.5rem;
    background: #f8fafc;
    border-top: 1px solid #e2e8f0;
    display: flex;
    justify-content: flex-end;
    gap: 0.75rem;
}

.danger-alert {
    background: #fef2f2;
    border: 1px solid #fecaca;
    color: #991b1b;
    border-radius: 8px;
    padding: 0.9rem 1rem;
    margin-bottom: 1.25rem;
    font-size: 0.85rem;
    line-height: 1.6;
}

@media (max-width: 650px) {
    .quick-actions-bar {
        flex-direction: column;
    }
    .quick-actions-bar .btn {
        width: 100%;
    }
}
</style>

<div class="settings-hero">
    <h1>إعدادات النظام والمنشأة</h1>
    <p>
        قم بتعديل بيانات متجرك والخيارات المالية، والتحكم بأمان حسابك وإدارة بيانات النظام بسهولة.
    </p>
</div>

<!-- نموذج الإعدادات العامة -->
<form method="post">
    <input type="hidden" name="save_settings" value="1">

    <div class="settings-card">
        <div class="settings-card-title">
            <svg fill="none" stroke="#2563eb" viewBox="0 0 24 24" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5m0 0h4m-4 0v-4m0 0h4m-4 0V9m0 0h4m-4 0V5"/>
            </svg>
            البيانات العامة للمتجر والعملة
        </div>

        <div class="form-grid-2">
            <div class="form-group">
                <label for="store_name">
                    اسم المتجر / النشاط التجاري <span style="color:#ef4444;">*</span>
                </label>
                <input
                    type="text"
                    id="store_name"
                    name="store_name"
                    class="form-control"
                    value="<?= e($settings['store_name']) ?>"
                    required
                >
                <span class="form-hint">يظهر في ترويسة النظام وأعلى الفواتير المطبوعة.</span>
            </div>

            <div class="form-group">
                <label for="store_phone">رقم الهاتف / التواصل</label>
                <input
                    type="tel"
                    id="store_phone"
                    name="store_phone"
                    class="form-control"
                    value="<?= e($settings['store_phone']) ?>"
                    placeholder="مثال: 0912345678"
                >
                <span class="form-hint">يتم طباعته في ترويسة الفواتير لتسهيل التواصل.</span>
            </div>
        </div>

        <div class="form-group">
            <label for="store_address">عنوان المتجر</label>
            <input
                type="text"
                id="store_address"
                name="store_address"
                class="form-control"
                value="<?= e($settings['store_address']) ?>"
                placeholder="مثال: دمشق - شارع الحمراء"
            >
        </div>

        <div class="form-grid-2">
            <!-- قائمة اختيار البلد -->
            <div class="form-group">
                <label for="store_country">الدولة / البلد</label>
                <select id="store_country" name="store_country" class="form-control" onchange="updateCurrencyOptions()">
                    <?php foreach ($arabCountries as $country =>$curr): ?>
                        <option value="<?= $country ?>" <?= ($settings['store_country'] ===$country) ? 'selected' : '' ?>>
                            <?= $country ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <span class="form-hint">اختر الدولة لتعيين العملة المحلية تلقائياً.</span>
            </div>

            <!-- قائمة اختيار العملة -->
            <div class="form-group">
                <label for="currency">العملة الأساسية <span style="color:#ef4444;">*</span></label>
                <select id="currency" name="currency" class="form-control" required>
                    <!-- يتم تعبئة الخيارات ديناميكياً بواسطة JavaScript -->
                </select>
                <span class="form-hint">الرمز الذي يظهر بجانب كافة المبالغ المالية.</span>
            </div>
        </div>

        <div class="form-group">
            <label for="invoice_footer">ملاحظة أسفل الفاتورة</label>
            <textarea
                id="invoice_footer"
                name="invoice_footer"
                class="form-control"
            ><?= e($settings['invoice_footer']) ?></textarea>
            <span class="form-hint">نص ترحيبي أو شروط الإرجاع والاستبدال المطبوعة في تذييل الفاتورة.</span>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center;" class="quick-actions-bar">
            <button type="submit" class="btn btn-primary">
                حفظ الإعدادات العامة
            </button>

            <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
                <button type="button" class="btn btn-warning" onclick="openModal('passwordModal')">
                    🔑 تغيير كلمة المرور
                </button>
                <button type="button" class="btn btn-danger-custom" onclick="openModal('clearDbModal')">
                    🗑️ تفريغ بيانات المتجر
                </button>
            </div>
        </div>
    </div>
</form>

<!-- Modal: تغيير كلمة المرور -->
<div class="modal-overlay" id="passwordModal">
    <div class="modal-container">
        <div class="modal-header">
            <h3>تغيير كلمة المرور</h3>
            <button type="button" class="modal-close-btn" onclick="closeModal('passwordModal')">&times;</button>
        </div>
        <form method="post">
            <input type="hidden" name="change_password" value="1">
            <div class="modal-body">
                <div class="form-group">
                    <label for="current_password">كلمة المرور الحالية <span style="color:#ef4444;">*</span></label>
                    <div class="input-group">
                        <input type="password" id="current_password" name="current_password" class="form-control" required autocomplete="current-password">
                        <button type="button" class="toggle-password-btn" onclick="togglePasswordVisibility('current_password', this)">👁️</button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="new_password">كلمة المرور الجديدة <span style="color:#ef4444;">*</span></label>
                    <div class="input-group">
                        <input type="password" id="new_password" name="new_password" class="form-control" minlength="6" required autocomplete="new-password">
                        <button type="button" class="toggle-password-btn" onclick="togglePasswordVisibility('new_password', this)">👁️</button>
                    </div>
                    <span class="form-hint">يجب أن تتكون من 6 أحرف على الأقل.</span>
                </div>

                <div class="form-group">
                    <label for="confirm_password">تأكيد كلمة المرور الجديدة <span style="color:#ef4444;">*</span></label>
                    <div class="input-group">
                        <input type="password" id="confirm_password" name="confirm_password" class="form-control" minlength="6" required autocomplete="new-password">
                        <button type="button" class="toggle-password-btn" onclick="togglePasswordVisibility('confirm_password', this)">👁️</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('passwordModal')">إلغاء</button>
                <button type="submit" class="btn btn-warning">حفظ كلمة المرور</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: تفريغ بيانات المتجر -->
<div class="modal-overlay" id="clearDbModal">
    <div class="modal-container">
        <div class="modal-header" style="border-bottom-color: #fecaca;">
            <h3 style="color: #991b1b;">تفريغ بيانات المتجر التشغيلية</h3>
            <button type="button" class="modal-close-btn" onclick="closeModal('clearDbModal')">&times;</button>
        </div>
        <form method="post" onsubmit="return confirm('تحذير نهائي: سيتم حذف جميع البيانات التشغيلية نهائياً. هل تريد المتابعة؟');">
            <input type="hidden" name="clear_database" value="1">
            <div class="modal-body">
                <div class="danger-alert">
                    <strong>تنبيه هام جداً:</strong>
                    سيتم حذف كامل المبيعات، الفواتير، المشتريات، المنتجات، الزبائن، الموردين، والمصروفات نهائياً.
                    <br>
                    <strong>لن يتم حذف:</strong> حسابات المستخدمين وإعدادات المتجر الأساسية.
                </div>

                <div class="form-group">
                    <label for="clear_current_password">كلمة مرور المستخدم الحالي <span style="color:#ef4444;">*</span></label>
                    <div class="input-group">
                        <input type="password" id="clear_current_password" name="clear_current_password" class="form-control" required autocomplete="current-password">
                        <button type="button" class="toggle-password-btn" onclick="togglePasswordVisibility('clear_current_password', this)">👁️</button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="clear_confirmation">
                        اكتب كلمة <strong style="color:#dc2626;">نعم</strong> لتأكيد الحذف <span style="color:#ef4444;">*</span>
                    </label>
                    <input type="text" id="clear_confirmation" name="clear_confirmation" class="form-control" placeholder="اكتب: نعم" required autocomplete="off">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('clearDbModal')">إلغاء</button>
                <button type="submit" class="btn btn-danger-custom">تأكيد التفريغ النهائي</button>
            </div>
        </form>
    </div>
</div>

<script>
// خريطة الدول والعملات
const countryCurrencies = <?= json_encode($arabCountries, JSON_UNESCAPED_UNICODE) ?>;
const currentSavedCurrency = <?= json_encode($settings['currency'], JSON_UNESCAPED_UNICODE) ?>;

function updateCurrencyOptions() {
    const countrySelect = document.getElementById('store_country');
    const currencySelect = document.getElementById('currency');
    const selectedCountry = countrySelect.value;
    const defaultLocalCurr = countryCurrencies[selectedCountry] || 'ل.س';

    currencySelect.innerHTML = '';

    // خيار العملة المحلية للدولة
    const localOption = document.createElement('option');
    localOption.value = defaultLocalCurr;
    localOption.textContent = `${defaultLocalCurr} (${selectedCountry})`;
    currencySelect.appendChild(localOption);

    // خيار الدولار الأمريكي
    const usdOption = document.createElement('option');
    usdOption.value = '$';
    usdOption.textContent = '$ (دولار أمريكي)';
    currencySelect.appendChild(usdOption);

    // تحديد العملة المحفوظة سابقاً إن وجدت
    if (currentSavedCurrency === '$') {
        currencySelect.value = '$';
    } else if (currentSavedCurrency === defaultLocalCurr) {
        currencySelect.value = defaultLocalCurr;
    } else {
        // إذا كانت العملة المحفوظة مخصصة
        const customOption = document.createElement('option');
        customOption.value = currentSavedCurrency;
        customOption.textContent = currentSavedCurrency;
        currencySelect.appendChild(customOption);
        currencySelect.value = currentSavedCurrency;
    }
}

// تشغيل تحديث القائمة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', updateCurrencyOptions);

// التحكم بالنواد المنبثقة (Modals)
function openModal(id) {
    document.getElementById(id).classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

// إغلاق النافذة المنبثقة عند النقر خارجها
window.onclick = function(event) {
    if (event.target.classList.contains('modal-overlay')) {
        event.target.classList.remove('active');
    }
};

// إظهار/إخفاء كلمة المرور
function togglePasswordVisibility(inputId, button) {
    const input = document.getElementById(inputId);
    if (!input) return;

    if (input.type === 'password') {
        input.type = 'text';
        button.style.opacity = '0.5';
    } else {
        input.type = 'password';
        button.style.opacity = '1';
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>