<?php
require_once 'config/database.php';
require_once 'includes/header.php';

date_default_timezone_set('Asia/Damascus');

// ---------------------------------------------------------
// 1. تحديد التاريخ وتجهيز الاستعلامات الآمنة
// ---------------------------------------------------------
$selectedDate = isset($_GET['date']) && !empty($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// إجمالي المبيعات
$stmtSales = $pdo->prepare("SELECT COALESCE(SUM(total_amount), 0) FROM invoices WHERE DATE(created_at) = ?");
$stmtSales->execute([$selectedDate]);
$sales = (float)$stmtSales->fetchColumn();

// إجمالي المقبوضات الفعلية
$stmtPaid = $pdo->prepare("SELECT COALESCE(SUM(paid_amount), 0) FROM invoices WHERE DATE(created_at) = ?");
$stmtPaid->execute([$selectedDate]);
$paid = (float)$stmtPaid->fetchColumn();

// إجمالي المصروفات
$stmtExp = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE expense_date = ?");
$stmtExp->execute([$selectedDate]);
$expenses = (float)$stmtExp->fetchColumn();

// تكلفة البضاعة المباعة (COGS)
$stmtCost = $pdo->prepare("
    SELECT COALESCE(SUM(ii.quantity * p.purchase_price), 0) 
    FROM invoice_items ii 
    INNER JOIN products p ON p.id = ii.product_id 
    INNER JOIN invoices i ON i.id = ii.invoice_id 
    WHERE DATE(i.created_at) = ?
");
$stmtCost->execute([$selectedDate]);
$cost = (float)$stmtCost->fetchColumn();

// الحسابات المالية
$profit  = $sales - $cost - $expenses;
$netCash = $paid - $expenses;
?>

<!-- ---------------------------------------------------------
     2. التصميم المدمج (Embedded CSS Styles)
----------------------------------------------------------- -->
<style>
.reports-header {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 1.25rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}
.reports-header h1 {
    margin: 0;
    font-size: 1.4rem;
    color: #2d3748;
    font-weight: 700;
}

.filter-form {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    flex-wrap: wrap;
}
.filter-form input[type="date"] {
    padding: 0.5rem 0.75rem;
    border: 1px solid #cbd5e0;
    border-radius: 6px;
    font-size: 0.9rem;
    outline: none;
    background-color: #ffffff;
}
.filter-form input[type="date"]:focus {
    border-color: #3182ce;
    box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.15);
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 1.25rem;
    margin-bottom: 1.5rem;
}
.stat-card {
    background: #ffffff;
    padding: 1.25rem;
    border-radius: 10px;
    border: 1px solid #eef2f5;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.03);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(0,0,0,0.05);
}

.stat-label {
    display: block;
    font-size: 0.85rem;
    color: #718096;
    font-weight: 600;
    margin-bottom: 0.5rem;
}
.stat-value {
    font-size: 1.5rem;
    font-weight: 700;
}

.success-text { color: #10b981; }
.danger-text { color: #ef4444; }
.warning-text { color: #f59e0b; }
.info-text { color: #3b82f6; }
.dark-text { color: #1f2937; }

.flex-between {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 1rem;
}

.btn {
    padding: 0.55rem 1rem;
    border-radius: 6px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid transparent;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.4rem;
    transition: all 0.2s ease-in-out;
}
.btn-primary { background-color: #3182ce; color: #ffffff; }
.btn-primary:hover { background-color: #2b6cb0; }
.btn-outline-secondary { border-color: #cbd5e0; color: #4a5568; background: #ffffff; }
.btn-outline-secondary:hover { background-color: #edf2f7; }

@media (max-width: 640px) {
    .flex-between { flex-direction: column; align-items: stretch; }
    .filter-form { width: 100%; justify-content: space-between; }
}
</style>

<!-- ---------------------------------------------------------
     3. واجهة المستخدم (HTML Markup)
----------------------------------------------------------- -->

<!-- شريط العنوان والفلتر والتصدير -->
<div class="reports-header flex-between">
    <div>
        <h1>التقرير اليومي</h1>
        <small style="color: #718096;">عرض نتائج اليوم: <strong><?= e($selectedDate) ?></strong></small>
    </div>

    <div class="flex-between" style="gap: 0.75rem;">
        <!-- نموذج اختيار التاريخ -->
        <form method="get" class="filter-form">
            <input type="date" name="date" value="<?= e($selectedDate) ?>" onchange="this.form.submit()">
            <button type="submit" class="btn btn-outline-secondary">عرض</button>
        </form>

        <!-- زر الطباعة -->
        <a class="btn btn-primary" target="_blank" href="reports_daily_print.php?date=<?= urlencode($selectedDate) ?>">
            طباعة التقرير
        </a>
    </div>
</div>

<!-- شبكة المؤشرات الماليّة -->
<div class="stats-grid">
    <!-- إجمالي المبيعات -->
    <div class="stat-card">
        <span class="stat-label">إجمالي المبيعات</span>
        <span class="stat-value info-text"><?= format_money($pdo, $sales) ?></span>
    </div>

    <!-- المقبوضات الفعلية -->
    <div class="stat-card">
        <span class="stat-label">المقبوضات اليومية (نقداً)</span>
        <span class="stat-value success-text"><?= format_money($pdo, $paid) ?></span>
    </div>

    <!-- تكلفة البضاعة المباعة -->
    <div class="stat-card">
        <span class="stat-label">تكلفة البضاعة المباعة</span>
        <span class="stat-value warning-text"><?= format_money($pdo, $cost) ?></span>
    </div>

    <!-- المصروفات اليومية -->
    <div class="stat-card">
        <span class="stat-label">المصروفات اليومية</span>
        <span class="stat-value danger-text"><?= format_money($pdo, $expenses) ?></span>
    </div>

    <!-- الربح اليومي الصافي -->
    <div class="stat-card" style="border-right: 4px solid <?= $profit >= 0 ? '#10b981' : '#ef4444' ?>;">
        <span class="stat-label">صافي الربح اليومي (المحاسبي)</span>
        <span class="stat-value <?= $profit >= 0 ? 'success-text' : 'danger-text' ?>">
            <?= format_money($pdo, $profit) ?>
        </span>
    </div>

    <!-- الصافي النقدي في الصندوق -->
    <div class="stat-card" style="border-right: 4px solid <?= $netCash >= 0 ? '#3b82f6' : '#ef4444' ?>;">
        <span class="stat-label">الصافي النقدي المباشر (الصندوق)</span>
        <span class="stat-value <?= $netCash >= 0 ? 'dark-text' : 'danger-text' ?>">
            <?= format_money($pdo, $netCash) ?>
        </span>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>