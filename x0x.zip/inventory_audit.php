<?php
require_once 'config/database.php';
require_once 'includes/header.php';

date_default_timezone_set('Asia/Damascus');

// استعلام المنتجات مع ربط جدول التصنيفات
$sql = "SELECT p.*, c.name AS category_name 
        FROM products p 
        LEFT JOIN categories c ON c.id = p.category_id 
        ORDER BY c.name ASC, p.name ASC";
$products = $pdo->query($sql)->fetchAll();

// حساب الإجماليات الإحصائية
$totalCost = 0;
$totalSale = 0;
$totalItemsCount = 0;
$totalQuantitySum = 0;

foreach ($products as $product) {
    $qty = (int)$product['quantity'];
    $purchasePrice = (float)$product['purchase_price'];
    $salePrice = (float)$product['sale_price'];

    $totalCost += ($purchasePrice * $qty);
    $totalSale += ($salePrice * $qty);
    $totalItemsCount++;
    $totalQuantitySum += $qty;
}

$expectedProfit = $totalSale - $totalCost;
$profitMarginPercentage = $totalCost > 0 ? (($expectedProfit / $totalCost) * 100) : 0;

$reportDate = date('Y-m-d');
$reportDay = ['Sunday'=>'الأحد','Monday'=>'الاثنين','Tuesday'=>'الثلاثاء','Wednesday'=>'الأربعاء','Thursday'=>'الخميس','Friday'=>'الجمعة','Saturday'=>'السبت'][date('l')] ?? date('l');
$reportTime = date('H:i:s');
?>

<style>
/* Modern Inventory Audit Custom Styles */
:root {
    --audit-primary: #2563eb;
    --audit-success: #10b981;
    --audit-warning: #f59e0b;
    --audit-danger: #ef4444;
    --audit-border: #e2e8f0;
}

.audit-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.audit-title {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    margin: 0 0 4px 0;
}

.audit-meta-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: #f1f5f9;
    color: #475569;
    padding: 6px 12px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    border: 1px solid var(--audit-border);
}

/* KPI Summary Cards */
.audit-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.audit-kpi-card {
    background: #ffffff;
    border: 1px solid var(--audit-border);
    border-radius: 12px;
    padding: 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}

.audit-kpi-card small {
    font-size: 12px;
    color: #64748b;
    font-weight: 600;
    display: block;
    margin-bottom: 6px;
}

.audit-kpi-card strong {
    font-size: 20px;
    font-weight: 800;
    display: block;
}

.audit-kpi-subtext {
    font-size: 11px;
    color: #94a3b8;
    margin-top: 4px;
    font-weight: 500;
}

/* Table Design */
.audit-card {
    background: #ffffff;
    border: 1px solid var(--audit-border);
    border-radius: 14px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

.table-responsive {
    overflow-x: auto;
}

.audit-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
}

.audit-table th {
    background: #f8fafc;
    color: #475569;
    font-size: 12px;
    font-weight: 700;
    padding: 12px 10px;
    border-bottom: 2px solid var(--audit-border);
    text-align: right;
    white-space: nowrap;
}

.audit-table td {
    padding: 12px 10px;
    border-bottom: 1px solid var(--audit-border);
    font-size: 13px;
    color: #1e293b;
    vertical-align: middle;
}

.audit-table tbody tr:hover {
    background-color: #f8fafc;
}

.audit-table tfoot tr th {
    background: #f1f5f9;
    color: #0f172a;
    font-size: 13px;
    font-weight: 800;
    border-top: 2px solid #cbd5e1;
    padding: 14px 10px;
}

/* Badges */
.stock-badge {
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    display: inline-block;
}
.badge-zero { background: #fee2e2; color: #b91c1c; }
.badge-low { background: #fef3c7; color: #b45309; }
.badge-ok { background: #f1f5f9; color: #334155; }

/* Print Optimizations */
@media print {
    body { background: #fff !important; }
    .btn, header, nav, .sidebar { display: none !important; }
    .audit-card { border: none !important; box-shadow: none !important; padding: 0 !important; }
    .audit-table th, .audit-table td { padding: 8px 6px !important; font-size: 11px !important; }
}
</style>

<!-- الرأس وأدوات التقرير -->
<div class="audit-header">
    <div>
        <h1 class="audit-title">📋 تقرير جرد المستودع الشامل</h1>
        <div class="audit-meta-badge">
            <span>📅 التاريخ: <strong><?= e($reportDate) ?></strong></span>
            <span>•</span>
            <span>اليوم: <strong><?= e($reportDay) ?></strong></span>
            <span>•</span>
            <span>🕒 الوقت: <strong><?= e($reportTime) ?></strong></span>
        </div>
    </div>
    <div style="display:flex; gap:8px;">
        <button onclick="window.print()" class="btn btn-secondary" style="font-weight:600;">
            🖨️ طباعة سريعة
        </button>
        <a class="btn btn-primary" target="_blank" href="inventory_audit_print.php" style="font-weight:700;">
            📄 حفظ كـ PDF / طباعة رسمية
        </a>
    </div>
</div>

<!-- بطاقات الإحصائيات ورأس المال -->
<div class="audit-kpi-grid">
    <div class="audit-kpi-card" style="border-right: 4px solid var(--audit-primary);">
        <small>رأس مال البضاعة بالمخزن (التكلفة)</small>
        <strong style="color:#1e3a8a;"><?= format_money($pdo, $totalCost) ?></strong>
        <div class="audit-kpi-subtext">محسوب بناءً على أسعار الشراء الحالية</div>
    </div>

    <div class="audit-kpi-card" style="border-right: 4px solid var(--audit-success);">
        <small>القيمة الإجمالية المتوقعة للمبيع</small>
        <strong style="color:#15803d;"><?= format_money($pdo, $totalSale) ?></strong>
        <div class="audit-kpi-subtext">إجمالي الإيراد عند بيع كافة الكميات</div>
    </div>

    <div class="audit-kpi-card" style="border-right: 4px solid <?= $expectedProfit >= 0 ? '#10b981' : '#ef4444' ?>;">
        <small>الربح الإجمالي المتوقع</small>
        <strong style="color:<?= $expectedProfit >= 0 ? '#047857' : '#b91c1c' ?>;"><?= format_money($pdo, $expectedProfit) ?></strong>
        <div class="audit-kpi-subtext">هامش ربح إجمالي تقريبي: <strong><?= number_format($profitMarginPercentage, 1) ?>%</strong></div>
    </div>

    <div class="audit-kpi-card" style="border-right: 4px solid #8b5cf6;">
        <small>إحصائيات الأصناف والكميات</small>
        <strong style="color:#6d28d9;"><?= number_format($totalItemsCount) ?> صنف</strong>
        <div class="audit-kpi-subtext">إجمالي القطع المخزنة: <strong><?= number_format($totalQuantitySum) ?> قطعة</strong></div>
    </div>
</div>

<!-- جدول الجرد التفصيلي -->
<div class="audit-card">
    <div class="table-responsive">
        <table class="audit-table">
            <thead>
                <tr>
                    <th style="width: 40px;">#</th>
                    <th>الكود (SKU)</th>
                    <th>اسم المنتج</th>
                    <th>التصنيف</th>
                    <th style="text-align:center;">الكمية</th>
                    <th>سعر الشراء</th>
                    <th>سعر البيع</th>
                    <th>إجمالي التكلفة</th>
                    <th>إجمالي المبيع</th>
                    <th>الربح المتوقع</th>
                    <th style="text-align:center;">الهامش</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($products)): ?>
                <tr>
                    <td colspan="11" style="text-align:center; padding:30px; color:#94a3b8;">لا توجد منتجات مسجلة في المستودع حالياً.</td>
                </tr>
            <?php endif; ?>

            <?php foreach ($products as $index => $product):
                $qty = (int)$product['quantity'];
                $purchasePrice = (float)$product['purchase_price'];
                $salePrice = (float)$product['sale_price'];

                $costTotal = $purchasePrice * $qty;
                $saleTotal = $salePrice * $qty;
                $profit = $saleTotal - $costTotal;
                $itemMargin = $costTotal > 0 ? (($profit / $costTotal) * 100) : 0;

                $isOut = $qty <= 0;
                $isLow = $qty > 0 && $qty < 10;
            ?>
                <tr style="<?= $isOut ? 'background:#fef2f2;' : ($isLow ? 'background:#fffbebf5;' : '') ?>">
                    <td style="color:#64748b; font-weight:600;"><?= $index + 1 ?></td>
                    <td style="font-family:monospace; color:#64748b; font-size:12px;"><?= e($product['sku'] ?: '—') ?></td>
                    <td style="font-weight:700; color:#0f172a;"><?= e($product['name']) ?></td>
                    <td style="color:#64748b;"><?= e($product['category_name'] ?: ($product['category'] ?: 'عام')) ?></td>
                    <td style="text-align:center;">
                        <span class="stock-badge <?= $isOut ? 'badge-zero' : ($isLow ? 'badge-low' : 'badge-ok') ?>">
                            <?= number_format($qty) ?>
                        </span>
                    </td>
                    <td style="color:#475569;"><?= format_money($pdo, $purchasePrice) ?></td>
                    <td style="color:#2563eb; font-weight:600;"><?= format_money($pdo, $salePrice) ?></td>
                    <td style="font-weight:600; color:#334155;"><?= format_money($pdo, $costTotal) ?></td>
                    <td style="font-weight:600; color:#15803d;"><?= format_money($pdo, $saleTotal) ?></td>
                    <td style="font-weight:700;" class="<?= $profit >= 0 ? 'success-text' : 'danger-text' ?>">
                        <?= format_money($pdo, $profit) ?>
                    </td>
                    <td style="text-align:center; font-size:11px; font-weight:700; color:<?= $itemMargin >= 0 ? '#059669' : '#dc2626' ?>;">
                        <?= number_format($itemMargin, 1) ?>%
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="4" style="text-align:right;">الإجماليات الكلية للجرد:</th>
                    <th style="text-align:center; color:#1e293b;"><?= number_format($totalQuantitySum) ?></th>
                    <th colspan="2"></th>
                    <th><?= format_money($pdo, $totalCost) ?></th>
                    <th><?= format_money($pdo, $totalSale) ?></th>
                    <th style="color:<?= $expectedProfit >= 0 ? '#15803d' : '#b91c1c' ?>;"><?= format_money($pdo, $expectedProfit) ?></th>
                    <th style="text-align:center; color:#2563eb;"><?= number_format($profitMarginPercentage, 1) ?>%</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>