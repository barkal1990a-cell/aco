# برنامج محاسبة PHP محلي

نظام محاسبة ومخزون وفواتير عربي يعمل على سيرفر محلي (XAMPP/WAMP/LAMP).

## المتطلبات
- PHP 8.1+
- MySQL / MariaDB
- Apache مع mod_rewrite

## التثبيت
1. انسخ المجلد إلى htdocs أو www.
2. أنشئ قاعدة بيانات باسم `accounting_system`.
3. استورد الملف `database/accounting_system.sql`.
4. عدّل بيانات الاتصال في `config/database.php`.
5. افتح `http://localhost/accounting-app/`.

## بيانات دخول افتراضية
- اسم المستخدم: admin
- كلمة المرور: 123456
