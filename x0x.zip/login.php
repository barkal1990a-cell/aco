<?php
require_once 'config/database.php'; require_once 'includes/functions.php';
if (is_logged_in()) redirect('index.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) { $_SESSION['user_id']=$user['id']; $_SESSION['username']=$user['username']; redirect('index.php'); }
    set_flash('error','بيانات الدخول غير صحيحة'); redirect('login.php');
}
$flash = get_flash();
?><!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>تسجيل الدخول</title><link rel="stylesheet" href="assets/style.css"></head><body><div style="max-width:420px;margin:80px auto" class="card"><h2>تسجيل الدخول</h2><?php if($flash): ?><div class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?><form method="post" class="form-grid"><div class="form-group"><label>اسم المستخدم</label><input name="username" required></div><div class="form-group"><label>كلمة المرور</label><input type="password" name="password" required></div><button class="btn btn-primary" type="submit">دخول</button></form></div></body></html>