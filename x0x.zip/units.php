<?php
require_once 'config/database.php';
require_once 'includes/header.php';

/*
|--------------------------------------------------------------------------
| إنشاء جدول الوحدات
|--------------------------------------------------------------------------
*/
$pdo->exec("
    CREATE TABLE IF NOT EXISTS units (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        symbol VARCHAR(30) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_unit_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

/*
|--------------------------------------------------------------------------
| التأكد من وجود unit_id في جدول المنتجات
|--------------------------------------------------------------------------
*/
$unitColumn = $pdo->query("
    SHOW COLUMNS FROM products LIKE 'unit_id'
");

if ($unitColumn->rowCount() === 0) {
    $pdo->exec("
        ALTER TABLE products
        ADD COLUMN unit_id INT NULL
        AFTER category_id
    ");
}

/*
|--------------------------------------------------------------------------
| إضافة / تعديل / حذف وحدة
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['add_unit'])) {
        $name = trim($_POST['unit_name'] ?? '');
        $symbol = trim($_POST['unit_symbol'] ?? '');

        if ($name === '') {
            set_flash('error', 'يرجى إدخال اسم الوحدة.');
        } else {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO units (
                        name,
                        symbol
                    ) VALUES (?, ?)
                ");

                $stmt->execute([
                    $name,
                    $symbol !== '' ? $symbol : null
                ]);

                set_flash('success', 'تمت إضافة الوحدة بنجاح.');
            } catch (Throwable $e) {
                set_flash(
                    'error',
                    'تعذر إضافة الوحدة. قد يكون اسم الوحدة موجودًا مسبقًا.'
                );
            }
        }

        redirect('units.php');
    }

    if (isset($_POST['update_unit'])) {
        $unitId = (int)($_POST['unit_id'] ?? 0);
        $name = trim($_POST['unit_name'] ?? '');
        $symbol = trim($_POST['unit_symbol'] ?? '');

        if ($unitId <= 0 || $name === '') {
            set_flash('error', 'بيانات الوحدة غير مكتملة.');
        } else {
            try {
                $stmt = $pdo->prepare("
                    UPDATE units
                    SET
                        name = ?,
                        symbol = ?
                    WHERE id = ?
                ");

                $stmt->execute([
                    $name,
                    $symbol !== '' ? $symbol : null,
                    $unitId
                ]);

                set_flash('success', 'تم تعديل الوحدة بنجاح.');
            } catch (Throwable $e) {
                set_flash(
                    'error',
                    'تعذر تعديل الوحدة. قد يكون اسمها مستخدمًا مسبقًا.'
                );
            }
        }

        redirect('units.php');
    }

    if (isset($_POST['delete_unit'])) {
        $unitId = (int)($_POST['unit_id'] ?? 0);

        if ($unitId > 0) {
            try {
                $pdo->beginTransaction();

                /*
                 * لا يتم حذف المنتجات عند حذف الوحدة.
                 * فقط يتم إلغاء ارتباط الوحدة بها.
                 */
                $pdo->prepare("
                    UPDATE products
                    SET unit_id = NULL
                    WHERE unit_id = ?
                ")->execute([$unitId]);

                $pdo->prepare("
                    DELETE FROM units
                    WHERE id = ?
                ")->execute([$unitId]);

                $pdo->commit();

                set_flash(
                    'warning',
                    'تم حذف الوحدة وإلغاء ارتباطها بالمنتجات.'
                );
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                set_flash(
                    'error',
                    'تعذر حذف الوحدة: ' . $e->getMessage()
                );
            }
        }

        redirect('units.php');
    }
}

/*
|--------------------------------------------------------------------------
| جلب وحدة للتعديل
|--------------------------------------------------------------------------
*/
$editUnit = null;

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM units
        WHERE id = ?
    ");

    $stmt->execute([(int)$_GET['edit']]);

    $editUnit = $stmt->fetch(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| جلب الوحدات مع عدد المنتجات المرتبطة بها
|--------------------------------------------------------------------------
*/
$units = $pdo->query("
    SELECT
        u.*,
        COUNT(p.id) AS products_count
    FROM units u
    LEFT JOIN products p ON p.unit_id = u.id
    GROUP BY
        u.id,
        u.name,
        u.symbol,
        u.created_at
    ORDER BY u.name ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="card">
    <div
        style="
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:12px;
            flex-wrap:wrap;
        "
    >
        <div>
            <h1 style="margin:0;">إدارة الوحدات</h1>

            <p style="margin:6px 0 0; color:#6b7280;">
                أضف وحدات القياس مثل قطعة، كيلو غرام، غرام، لتر،
                علبة، كرتونة أو أي وحدة تستخدمها في المستودع.
            </p>
        </div>

        <a class="btn btn-secondary" href="products.php">
            العودة إلى المستودع
        </a>
    </div>
</div>

<div class="card">
    <h3><?= $editUnit ? 'تعديل وحدة قياس' : 'إضافة وحدة قياس جديدة' ?></h3>

    <form method="post" class="form-grid">
        <input
            type="hidden"
            name="<?= $editUnit ? 'update_unit' : 'add_unit' ?>"
            value="1"
        >

        <?php if ($editUnit): ?>
            <input
                type="hidden"
                name="unit_id"
                value="<?= e((string)$editUnit['id']) ?>"
            >
        <?php endif; ?>

        <div class="form-group">
            <label>اسم الوحدة</label>

            <input
                type="text"
                name="unit_name"
                required
                placeholder="مثال: كيلو غرام"
                value="<?= e($editUnit['name'] ?? '') ?>"
            >
        </div>

        <div class="form-group">
            <label>رمز الوحدة</label>

            <input
                type="text"
                name="unit_symbol"
                placeholder="مثال: كغ / قطعة / لتر / علبة"
                value="<?= e($editUnit['symbol'] ?? '') ?>"
            >
        </div>

        <div class="form-group">
            <label>&nbsp;</label>

            <button class="btn btn-primary">
                <?= $editUnit ? 'حفظ تعديل الوحدة' : 'إضافة الوحدة' ?>
            </button>
        </div>
    </form>
</div>

<div class="card">
    <h3>الوحدات المسجلة</h3>

    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>اسم الوحدة</th>
                <th>الرمز</th>
                <th>عدد المنتجات</th>
                <th>تاريخ الإضافة</th>
                <th>تعديل</th>
                <th>حذف</th>
            </tr>
        </thead>

        <tbody>
            <?php if (empty($units)): ?>
                <tr>
                    <td colspan="7" style="text-align:center;">
                        لا توجد وحدات مسجلة حتى الآن.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($units as $unit): ?>
                    <tr>
                        <td><?= e((string)$unit['id']) ?></td>
                        <td><?= e($unit['name']) ?></td>
                        <td><?= e($unit['symbol'] ?: '—') ?></td>
                        <td><?= e((string)$unit['products_count']) ?></td>
                        <td><?= e($unit['created_at']) ?></td>

                        <td>
                            <a
                                class="btn btn-warning"
                                href="units.php?edit=<?= e((string)$unit['id']) ?>"
                            >
                                تعديل
                            </a>
                        </td>

                        <td>
                            <form
                                method="post"
                                onsubmit="return confirm('سيتم إلغاء ارتباط هذه الوحدة بالمنتجات. هل تريد المتابعة؟')"
                            >
                                <input
                                    type="hidden"
                                    name="delete_unit"
                                    value="1"
                                >

                                <input
                                    type="hidden"
                                    name="unit_id"
                                    value="<?= e((string)$unit['id']) ?>"
                                >

                                <button class="btn btn-danger">
                                    حذف
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'includes/footer.php'; ?>