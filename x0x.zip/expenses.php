<?php
require_once 'config/database.php';
require_once 'includes/header.php';

/*
|--------------------------------------------------------------------------
| إعداد الشهر والسنة المعروضة
|--------------------------------------------------------------------------
|
| افتراضيًا تعرض الصفحة مصروفات الشهر الحالي.
| يمكن اختيار أي شهر وسنة من حقول الفلترة.
|
*/
$selectedMonth = isset($_GET['month'])
    ? (int)$_GET['month']
    : (int)date('n');

$selectedYear = isset($_GET['year'])
    ? (int)$_GET['year']
    : (int)date('Y');

if ($selectedMonth < 1 || $selectedMonth > 12) {
    $selectedMonth = (int)date('n');
}

if ($selectedYear < 2000 || $selectedYear > 2100) {
    $selectedYear = (int)date('Y');
}

$arabicMonths = [
    1  => 'كانون الثاني',
    2  => 'شباط',
    3  => 'آذار',
    4  => 'نيسان',
    5  => 'أيار',
    6  => 'حزيران',
    7  => 'تموز',
    8  => 'آب',
    9  => 'أيلول',
    10 => 'تشرين الأول',
    11 => 'تشرين الثاني',
    12 => 'كانون الأول',
];

$selectedMonthName = $arabicMonths[$selectedMonth];

/*
|--------------------------------------------------------------------------
| معالجة الطلبات: إضافة / تعديل / حذف المصروفات
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        /*
         * إضافة مصروف جديد
         */
        if (isset($_POST['add_expense'])) {
            $title = trim($_POST['title'] ?? '');
            $amount = (float)($_POST['amount'] ?? 0);
            $expenseDate = $_POST['expense_date'] ?? date('Y-m-d');
            $notes = trim($_POST['notes'] ?? '');

            if ($title === '' || $amount <= 0) {
                throw new Exception(
                    'يرجى إدخال عنوان صحيح ومبلغ أكبر من الصفر.'
                );
            }

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                INSERT INTO expenses (
                    title,
                    amount,
                    expense_date,
                    notes
                ) VALUES (?, ?, ?, ?)
            ");

            $stmt->execute([
                $title,
                $amount,
                $expenseDate,
                $notes
            ]);

            $expenseId = $pdo->lastInsertId();

            $stmtBox = $pdo->prepare("
                INSERT INTO cashbox (
                    type,
                    reference_id,
                    amount,
                    description
                ) VALUES ('out', ?, ?, ?)
            ");

            $stmtBox->execute([
                $expenseId,
                $amount,
                'صرف مصروف: ' . $title
            ]);

            $pdo->commit();

            set_flash(
                'success',
                'تمت إضافة المصروف وخصمه من الصندوق بنجاح.'
            );
        }

        /*
         * تعديل مصروف موجود
         */
        if (isset($_POST['update_expense'])) {
            $expenseId = (int)($_POST['expense_id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $amount = (float)($_POST['amount'] ?? 0);
            $expenseDate = $_POST['expense_date'] ?? date('Y-m-d');
            $notes = trim($_POST['notes'] ?? '');

            if ($expenseId <= 0 || $title === '' || $amount <= 0) {
                throw new Exception(
                    'بيانات التعديل غير مكتملة أو غير صحيحة.'
                );
            }

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                UPDATE expenses
                SET
                    title = ?,
                    amount = ?,
                    expense_date = ?,
                    notes = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $title,
                $amount,
                $expenseDate,
                $notes,
                $expenseId
            ]);

            /*
             * تحديث حركة الصندوق الخاصة بهذا المصروف.
             */
            $stmtBox = $pdo->prepare("
                UPDATE cashbox
                SET
                    amount = ?,
                    description = ?
                WHERE reference_id = ?
                  AND type = 'out'
                  AND description LIKE 'صرف مصروف:%'
            ");

            $stmtBox->execute([
                $amount,
                'صرف مصروف: ' . $title,
                $expenseId
            ]);

            $pdo->commit();

            set_flash(
                'success',
                'تم تعديل المصروف وتحديث قيد الصندوق بنجاح.'
            );
        }

        /*
         * حذف مصروف وإلغاء حركة الصندوق التابعة له
         */
        if (isset($_POST['delete_expense'])) {
            $expenseId = (int)($_POST['expense_id'] ?? 0);

            if ($expenseId > 0) {
                $pdo->beginTransaction();

                /*
                 * حذف حركة الصندوق المرتبطة بالمصروف فقط.
                 * شرط description مهم حتى لا يحذف حركة أخرى
                 * تحمل reference_id مماثلًا بالصدفة.
                 */
                $stmtBox = $pdo->prepare("
                    DELETE FROM cashbox
                    WHERE reference_id = ?
                      AND type = 'out'
                      AND description LIKE 'صرف مصروف:%'
                ");

                $stmtBox->execute([$expenseId]);

                $stmtExpense = $pdo->prepare("
                    DELETE FROM expenses
                    WHERE id = ?
                ");

                $stmtExpense->execute([$expenseId]);

                $pdo->commit();

                set_flash(
                    'warning',
                    'تم حذف المصروف وإلغاء قيده من الصندوق.'
                );
            }
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        set_flash('danger', 'خطأ: ' . $e->getMessage());
    }

    /*
     * بعد الحفظ، نعود إلى شهر المصروف الذي تم اختياره في النموذج،
     * أو إلى الشهر الحالي عند عدم وجود قيمة.
     */
    $redirectMonth = isset($_POST['view_month'])
        ? (int)$_POST['view_month']
        : $selectedMonth;

    $redirectYear = isset($_POST['view_year'])
        ? (int)$_POST['view_year']
        : $selectedYear;

    redirect(
        'expenses.php?month=' . $redirectMonth .
        '&year=' . $redirectYear
    );
}

/*
|--------------------------------------------------------------------------
| جلب المصروف المطلوب تعديله
|--------------------------------------------------------------------------
*/

$editExpense = null;

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM expenses
        WHERE id = ?
    ");

    $stmt->execute([(int)$_GET['edit']]);

    $editExpense = $stmt->fetch(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| جلب مصروفات الشهر والسنة المحددين
|--------------------------------------------------------------------------
*/

$expenseStmt = $pdo->prepare("
    SELECT *
    FROM expenses
    WHERE YEAR(expense_date) = ?
      AND MONTH(expense_date) = ?
    ORDER BY expense_date DESC, id DESC
");

$expenseStmt->execute([
    $selectedYear,
    $selectedMonth
]);

$rows = $expenseStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| الإحصائيات الشهرية
|--------------------------------------------------------------------------
*/

$totalExpensesCount = count($rows);
$totalExpensesAmount = 0;

foreach ($rows as $row) {
    $totalExpensesAmount += (float)$row['amount'];
}

$averageExpense = $totalExpensesCount > 0
    ? $totalExpensesAmount / $totalExpensesCount
    : 0;

/*
|--------------------------------------------------------------------------
| السنوات المتاحة للعرض
|--------------------------------------------------------------------------
|
| نجلب السنوات الموجودة في المصروفات، ونضيف السنة الحالية دائمًا.
|
*/
$yearsFromDatabase = $pdo->query("
    SELECT DISTINCT YEAR(expense_date) AS expense_year
    FROM expenses
    ORDER BY expense_year DESC
")->fetchAll(PDO::FETCH_COLUMN);

$availableYears = array_map('intval', $yearsFromDatabase);

if (!in_array((int)date('Y'), $availableYears, true)) {
    $availableYears[] = (int)date('Y');
}

if (!in_array($selectedYear, $availableYears, true)) {
    $availableYears[] = $selectedYear;
}

rsort($availableYears);
?>

<style>
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.stat-card {
    background: #ffffff;
    padding: 1.25rem;
    border-radius: 10px;
    border: 1px solid #eef2f5;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

.stat-label {
    display: block;
    font-size: 0.85rem;
    color: #6c757d;
    margin-bottom: 0.35rem;
}

.stat-value {
    font-size: 1.4rem;
    font-weight: 700;
    color: #2d3748;
}

.danger-text {
    color: #e53e3e;
}

.card {
    background: #ffffff;
    border-radius: 10px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    margin-bottom: 1.5rem;
    overflow: hidden;
}

.card-header {
    padding: 1rem 1.25rem;
    border-bottom: 1px solid #e2e8f0;
    background-color: #f8fafc;
}

.card-body {
    padding: 1.25rem;
}

.card-title {
    margin: 0;
    font-size: 1.15rem;
    color: #2d3748;
    font-weight: 700;
}

.flex-between {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    align-items: end;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 0.35rem;
}

.form-group label {
    font-size: 0.875rem;
    font-weight: 600;
    color: #4a5568;
}

.form-group input,
.form-group select,
.form-control-sm {
    padding: 0.5rem 0.75rem;
    border: 1px solid #cbd5e0;
    border-radius: 6px;
    font-size: 0.9rem;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
    width: 100%;
    box-sizing: border-box;
    background-color: #ffffff;
}

.form-group input:focus,
.form-group select:focus,
.form-control-sm:focus {
    border-color: #3182ce;
    box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.15);
}

.btn {
    padding: 0.55rem 1rem;
    border-radius: 6px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid transparent;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease-in-out;
}

.btn-sm {
    padding: 0.3rem 0.65rem;
    font-size: 0.8rem;
}

.btn-primary {
    background-color: #3182ce;
    color: #ffffff;
}

.btn-primary:hover {
    background-color: #2b6cb0;
}

.btn-warning {
    background-color: #dd6b20;
    color: #ffffff;
}

.btn-warning:hover {
    background-color: #c05621;
}

.btn-outline-warning {
    border-color: #dd6b20;
    color: #dd6b20;
    background: transparent;
}

.btn-outline-warning:hover {
    background-color: #dd6b20;
    color: #ffffff;
}

.btn-outline-danger {
    border-color: #e53e3e;
    color: #e53e3e;
    background: transparent;
}

.btn-outline-danger:hover {
    background-color: #e53e3e;
    color: #ffffff;
}

.btn-outline-secondary {
    border-color: #a0aec0;
    color: #4a5568;
    background: transparent;
}

.btn-outline-secondary:hover {
    background-color: #edf2f7;
}

.btn-outline-primary {
    border-color: #3182ce;
    color: #3182ce;
    background: transparent;
}

.btn-outline-primary:hover {
    background-color: #3182ce;
    color: #ffffff;
}

.table-responsive {
    overflow-x: auto;
}

.table {
    width: 100%;
    border-collapse: collapse;
    text-align: right;
}

.table th,
.table td {
    padding: 0.85rem 1rem;
    border-bottom: 1px solid #e2e8f0;
    font-size: 0.9rem;
}

.table th {
    background-color: #f7fafc;
    color: #4a5568;
    font-weight: 600;
}

.table-hover tbody tr:hover {
    background-color: #f8fafc;
}

.badge-id {
    background: #edf2f7;
    color: #4a5568;
    padding: 0.2rem 0.5rem;
    border-radius: 6px;
    font-size: 0.8rem;
    font-weight: 600;
}

.badge-month {
    background-color: #dbeafe;
    color: #1d4ed8;
    padding: 0.25rem 0.65rem;
    border-radius: 999px;
    font-size: 0.82rem;
    font-weight: 700;
}

.action-buttons {
    display: flex;
    gap: 0.35rem;
    justify-content: center;
}

.empty-state {
    padding: 2.5rem;
    color: #a0aec0;
    text-align: center;
    font-size: 0.95rem;
}

.text-danger {
    color: #e53e3e;
}

.text-muted {
    color: #718096;
}

.font-weight-bold {
    font-weight: 600;
}

.text-center {
    text-align: center;
}

.d-inline {
    display: inline;
}

.month-filter {
    display: flex;
    align-items: end;
    gap: 0.65rem;
    flex-wrap: wrap;
}

.month-filter .filter-field {
    min-width: 150px;
}

@media (max-width: 700px) {
    .month-filter {
        width: 100%;
    }

    .month-filter .filter-field {
        flex: 1 1 140px;
    }
}
</style>

<div class="card">
    <div class="card-header flex-between">
        <div>
            <h2 class="card-title">
                تقرير صرفيات شهر
                <span class="badge-month">
                    <?= e($selectedMonthName) ?>
                    <?= e((string)$selectedYear) ?>
                </span>
            </h2>
        </div>

        <form method="get" class="month-filter">
            <div class="filter-field form-group">
                <label for="month">الشهر</label>

                <select
                    id="month"
                    name="month"
                    onchange="this.form.submit()"
                >
                    <?php foreach ($arabicMonths as $monthNumber => $monthName): ?>
                        <option
                            value="<?= e((string)$monthNumber) ?>"
                            <?= $selectedMonth === $monthNumber ? 'selected' : '' ?>
                        >
                            <?= e($monthName) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="filter-field form-group">
                <label for="year">السنة</label>

                <select
                    id="year"
                    name="year"
                    onchange="this.form.submit()"
                >
                    <?php foreach ($availableYears as $year): ?>
                        <option
                            value="<?= e((string)$year) ?>"
                            <?= $selectedYear === (int)$year ? 'selected' : '' ?>
                        >
                            <?= e((string)$year) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>&nbsp;</label>

                <button
                    type="submit"
                    class="btn btn-outline-primary"
                >
                    عرض الشهر
                </button>
            </div>
        </form>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <span class="stat-label">
            إجمالي مصروفات
            <?= e($selectedMonthName) ?>
        </span>

        <span class="stat-value danger-text">
            <?= format_money($pdo, $totalExpensesAmount) ?>
        </span>
    </div>

    <div class="stat-card">
        <span class="stat-label">عدد العمليات</span>

        <span class="stat-value">
            <?= number_format($totalExpensesCount) ?>
        </span>
    </div>

    <div class="stat-card">
        <span class="stat-label">متوسط المصروف</span>

        <span class="stat-value">
            <?= format_money($pdo, $averageExpense) ?>
        </span>
    </div>
</div>

<div class="card">
    <div class="card-header flex-between">
        <h2 class="card-title">
            <?= $editExpense ? 'تعديل مصروف' : 'إضافة مصروف جديد' ?>
        </h2>

        <?php if ($editExpense): ?>
            <a
                href="expenses.php?month=<?= e((string)$selectedMonth) ?>&year=<?= e((string)$selectedYear) ?>"
                class="btn btn-outline-secondary btn-sm"
            >
                إلغاء التعديل
            </a>
        <?php endif; ?>
    </div>

    <div class="card-body">
        <form method="post" class="form-grid">
            <input
                type="hidden"
                name="<?= $editExpense ? 'update_expense' : 'add_expense' ?>"
                value="1"
            >

            <input
                type="hidden"
                name="view_month"
                value="<?= e((string)$selectedMonth) ?>"
            >

            <input
                type="hidden"
                name="view_year"
                value="<?= e((string)$selectedYear) ?>"
            >

            <?php if ($editExpense): ?>
                <input
                    type="hidden"
                    name="expense_id"
                    value="<?= e((string)$editExpense['id']) ?>"
                >
            <?php endif; ?>

            <div class="form-group">
                <label for="title">
                    عنوان المصروف
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    id="title"
                    name="title"
                    required
                    placeholder="مثال: إيجار المحل، فواتير..."
                    value="<?= e($editExpense['title'] ?? '') ?>"
                >
            </div>

            <div class="form-group">
                <label for="amount">
                    المبلغ
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="number"
                    id="amount"
                    step="0.01"
                    min="0.01"
                    name="amount"
                    required
                    placeholder="0.00"
                    value="<?= e($editExpense['amount'] ?? '') ?>"
                >
            </div>

            <div class="form-group">
                <label for="expense_date">
                    التاريخ
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="date"
                    id="expense_date"
                    name="expense_date"
                    value="<?= e($editExpense['expense_date'] ?? date('Y-m-d')) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="notes">ملاحظات إضافية</label>

                <input
                    type="text"
                    id="notes"
                    name="notes"
                    placeholder="أي تفاصيل أخرى..."
                    value="<?= e($editExpense['notes'] ?? '') ?>"
                >
            </div>

            <div class="form-group form-actions">
                <label>&nbsp;</label>

                <button
                    type="submit"
                    class="btn <?= $editExpense ? 'btn-warning' : 'btn-primary' ?>"
                >
                    <?= $editExpense ? 'تحديث البيانات' : 'حفظ المصروف' ?>
                </button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header flex-between">
        <h2 class="card-title">
            سجل مصروفات
            <?= e($selectedMonthName) ?>
            <?= e((string)$selectedYear) ?>
        </h2>

        <input
            type="text"
            id="tableSearch"
            class="form-control-sm"
            style="max-width:200px;"
            placeholder="تصفية السجلات..."
            onkeyup="filterExpenses()"
        >
    </div>

    <div class="table-responsive">
        <table
            class="table table-hover"
            id="expensesTable"
        >
            <thead>
                <tr>
                    <th style="width:60px;">#</th>
                    <th>العنوان</th>
                    <th>المبلغ</th>
                    <th>التاريخ</th>
                    <th>ملاحظات</th>
                    <th
                        style="width:140px;"
                        class="text-center"
                    >
                        الإجراءات
                    </th>
                </tr>
            </thead>

            <tbody>
                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="6" class="empty-state">
                            لا توجد مصروفات مسجلة في شهر
                            <?= e($selectedMonthName) ?>
                            <?= e((string)$selectedYear) ?>.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <td>
                                <span class="badge-id">
                                    #<?= e((string)$row['id']) ?>
                                </span>
                            </td>

                            <td class="font-weight-bold">
                                <?= e($row['title']) ?>
                            </td>

                            <td class="text-danger font-weight-bold">
                                <?= format_money($pdo, $row['amount']) ?>
                            </td>

                            <td>
                                <?= e($row['expense_date']) ?>
                            </td>

                            <td class="text-muted">
                                <?= e($row['notes']) ?: '—' ?>
                            </td>

                            <td class="text-center">
                                <div class="action-buttons">
                                    <a
                                        class="btn btn-sm btn-outline-warning"
                                        href="expenses.php?edit=<?= e((string)$row['id']) ?>&month=<?= e((string)$selectedMonth) ?>&year=<?= e((string)$selectedYear) ?>"
                                        title="تعديل"
                                    >
                                        تعديل
                                    </a>

                                    <form
                                        method="post"
                                        class="d-inline"
                                        onsubmit="return confirm('هل أنت متأكد من حذف هذا المصروف؟ سيتم إلغاء قيده من الصندوق أيضاً.')"
                                    >
                                        <input
                                            type="hidden"
                                            name="delete_expense"
                                            value="1"
                                        >

                                        <input
                                            type="hidden"
                                            name="expense_id"
                                            value="<?= e((string)$row['id']) ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="view_month"
                                            value="<?= e((string)$selectedMonth) ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="view_year"
                                            value="<?= e((string)$selectedYear) ?>"
                                        >

                                        <button
                                            class="btn btn-sm btn-outline-danger"
                                            title="حذف"
                                        >
                                            حذف
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function filterExpenses() {
    const input = document.getElementById('tableSearch');
    const filter = input.value.toLowerCase();
    const table = document.getElementById('expensesTable');
    const rows = table.getElementsByTagName('tr');

    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];

        if (row.getElementsByTagName('td').length > 0) {
            const text = row.textContent || row.innerText;

            row.style.display = text.toLowerCase().indexOf(filter) > -1
                ? ''
                : 'none';
        }
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>