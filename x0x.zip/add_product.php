<?php
require_once 'config/database.php';
require_once 'includes/header.php';

/*
|--------------------------------------------------------------------------
| إنشاء جدول التصنيفات عند الحاجة
|--------------------------------------------------------------------------
*/
$pdo->exec("
    CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

/*
|--------------------------------------------------------------------------
| إنشاء جدول الوحدات عند الحاجة
|--------------------------------------------------------------------------
*/
$pdo->exec("
    CREATE TABLE IF NOT EXISTS units (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        symbol VARCHAR(30) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_unit_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

/*
|--------------------------------------------------------------------------
| التأكد من أعمدة التصنيف والوحدة ونوع البيانات لأسعار الشراء والبيع
|--------------------------------------------------------------------------
*/
$categoryColumn = $pdo->query("SHOW COLUMNS FROM products LIKE 'category_id'");
if ($categoryColumn->rowCount() === 0) {
    $pdo->exec("ALTER TABLE products ADD COLUMN category_id INT NULL AFTER category");
}

$unitColumn = $pdo->query("SHOW COLUMNS FROM products LIKE 'unit_id'");
if ($unitColumn->rowCount() === 0) {
    $pdo->exec("ALTER TABLE products ADD COLUMN unit_id INT NULL AFTER category_id");
}

// تعديل دقة عمودي سعر الشراء وسعر البيع ليستوعبا حتى 6 خانات عشرية
try {
    $pdo->exec("ALTER TABLE products MODIFY COLUMN purchase_price DECIMAL(18, 6) NOT NULL DEFAULT 0.000000");
    $pdo->exec("ALTER TABLE products MODIFY COLUMN sale_price DECIMAL(18, 6) NOT NULL DEFAULT 0.000000");
} catch (Throwable $e) {
    // يتجاهل الخطأ في حال كانت الأعمدة معدلة مسبقاً بنفس التنسيق
}

/*
|--------------------------------------------------------------------------
| حفظ المنتجات الجديدة (يدعم منتج واحد أو منتجات متعددة)
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $names = $_POST['name'] ?? [];
    $skus = $_POST['sku'] ?? [];
    $categoryIds = $_POST['category_id'] ?? [];
    $unitIds = $_POST['unit_id'] ?? [];
    $purchasePrices = $_POST['purchase_price'] ?? [];
    $salePrices = $_POST['sale_price'] ?? [];
    $quantities = $_POST['quantity'] ?? [];

    $count = count($names);
    $addedCount = 0;

    if ($count > 0) {
        try {
            $pdo->beginTransaction();

            $stmtCategory = $pdo->prepare("SELECT name FROM categories WHERE id = ?");
            $stmtInsert = $pdo->prepare("
                INSERT INTO products (
                    name, sku, category, category_id, unit_id, purchase_price, sale_price, quantity
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            for ($i = 0; $i < $count; $i++) {
                $name = trim($names[$i] ?? '');
                if ($name === '') continue; // تخطي المدخلات الفارغة

                $sku = trim($skus[$i] ?? '');
                $categoryId = !empty($categoryIds[$i]) ? (int)$categoryIds[$i] : null;
                $unitId = !empty($unitIds[$i]) ? (int)$unitIds[$i] : null;
                $purchasePrice = max(0, (float)($purchasePrices[$i] ?? 0));
                $salePrice = max(0, (float)($salePrices[$i] ?? 0));
                $quantity = max(0, (float)($quantities[$i] ?? 0));

                $categoryName = '';
                if ($categoryId) {
                    $stmtCategory->execute([$categoryId]);
                    $categoryName = (string)$stmtCategory->fetchColumn();
                }

                $stmtInsert->execute([
                    $name,
                    $sku,
                    $categoryName,
                    $categoryId,
                    $unitId,
                    $purchasePrice,
                    $salePrice,
                    $quantity
                ]);

                $addedCount++;
            }

            $pdo->commit();

            if ($addedCount > 0) {
                set_flash('success', "تمت إضافة {$addedCount} من المنتجات بنجاح إلى المستودع.");
                redirect('products.php');
            } else {
                set_flash('error', 'يرجى إدخال اسم منتج واحد على الأقل.');
                redirect('add_product.php');
            }
        } catch (Throwable $e) {
            $pdo->rollBack();
            set_flash('error', 'تعذر إضافة المنتجات: ' . $e->getMessage());
            redirect('add_product.php');
        }
    }
}

/*
|--------------------------------------------------------------------------
| جلب التصنيفات والوحدات
|--------------------------------------------------------------------------
*/
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$units = $pdo->query("SELECT * FROM units ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- مكتبة أيقونات Font Awesome للمظهر العصري -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    .product-row {
        background: #f9fafb;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        position: relative;
        transition: all 0.3s ease;
    }
    .product-row:hover {
        border-color: #3b82f6;
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.08);
    }
    .product-row-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #e5e7eb;
    }
    .product-row-title {
        font-weight: 600;
        color: #1f2937;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .btn-remove-row {
        background-color: #fee2e2;
        color: #dc2626;
        border: none;
        padding: 6px 12px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 0.875rem;
        transition: background 0.2s;
    }
    .btn-remove-row:hover {
        background-color: #fca5a5;
    }
    .form-group label {
        display: block;
        margin-bottom: 6px;
        font-weight: 500;
        color: #374151;
    }
    .input-icon-wrapper {
        position: relative;
    }
    .input-icon-wrapper i {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: #9ca3af;
    }
    .input-icon-wrapper input, .input-icon-wrapper select {
        padding-right: 36px;
        width: 100%;
    }
    .actions-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        margin-top: 20px;
        flex-wrap: wrap;
    }
</style>

<div class="card" style="margin-bottom: 20px;">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
        <div>
            <h1 style="margin:0; display:flex; align-items:center; gap:10px;">
                <i class="fa-solid fa-boxes-stacked" style="color: #2563eb;"></i> إضافة منتجات جديدة
            </h1>
            <p style="margin:6px 0 0; color:#6b7280;">
                أضف منتجًا أو عدة منتجات دفعة واحدة مع تحديد كافة تفاصيل الشراء والبيع والكميات.
            </p>
        </div>
        <a class="btn btn-secondary" href="products.php" style="display:inline-flex; align-items:center; gap:8px;">
            <i class="fa-solid fa-arrow-right"></i> العودة إلى المستودع
        </a>
    </div>
</div>

<form method="post" id="productsForm">
    <input type="hidden" name="add_product" value="1">

    <div id="productsContainer">
        <!-- قالب حقول المنتج الأول -->
        <div class="product-row">
            <div class="product-row-header">
                <span class="product-row-title">
                    <i class="fa-solid fa-box" style="color: #3b82f6;"></i> بيانات المنتج <span class="row-number">1</span>
                </span>
                <button type="button" class="btn-remove-row" onclick="removeProductRow(this)" style="display:none;">
                    <i class="fa-solid fa-trash-can"></i> حذف المنتج
                </button>
            </div>

            <div class="form-grid">
                <div class="form-group">
                    <label><i class="fa-solid fa-tag"></i> اسم المنتج <span style="color:#dc2626;">*</span></label>
                    <div class="input-icon-wrapper">
                        <i class="fa-solid fa-font"></i>
                        <input type="text" name="name[]" required placeholder="مثال: رز بسمتي 1 كغ">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fa-solid fa-barcode"></i> كود المنتج (SKU)</label>
                    <div class="input-icon-wrapper">
                        <i class="fa-solid fa-barcode"></i>
                        <input type="text" name="sku[]" placeholder="مثال: P-001">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fa-solid fa-layer-group"></i> التصنيف</label>
                    <div class="input-icon-wrapper">
                        <i class="fa-solid fa-list"></i>
                        <select name="category_id[]">
                            <option value="">بدون تصنيف</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= e((string)$category['id']) ?>">
                                    <?= e($category['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <small style="color:#6b7280; margin-top:4px; display:block;">
                        <a href="categories.php" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> إدارة التصنيفات</a>
                    </small>
                </div>

                <div class="form-group">
                    <label><i class="fa-solid fa-ruler-combined"></i> وحدة القياس</label>
                    <div class="input-icon-wrapper">
                        <i class="fa-solid fa-scale-balanced"></i>
                        <select name="unit_id[]">
                            <option value="">بدون وحدة</option>
                            <?php foreach ($units as $unit): ?>
                                <option value="<?= e((string)$unit['id']) ?>">
                                    <?= e($unit['name']) ?> <?= !empty($unit['symbol']) ? ' (' . e($unit['symbol']) . ')' : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <small style="color:#6b7280; margin-top:4px; display:block;">
                        <a href="units.php" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> إدارة الوحدات</a>
                    </small>
                </div>

                <div class="form-group">
                    <label><i class="fa-solid fa-cart-shopping"></i> سعر الشراء <span style="color:#dc2626;">*</span></label>
                    <div class="input-icon-wrapper">
                        <i class="fa-solid fa-money-bill"></i>
                        <input type="number" step="any" min="0" name="purchase_price[]" required value="0">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fa-solid fa-hand-holding-dollar"></i> سعر البيع <span style="color:#dc2626;">*</span></label>
                    <div class="input-icon-wrapper">
                        <i class="fa-solid fa-dollar-sign"></i>
                        <input type="number" step="any" min="0" name="sale_price[]" required value="0">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fa-solid fa-cubes"></i> الكمية الابتدائية <span style="color:#dc2626;">*</span></label>
                    <div class="input-icon-wrapper">
                        <i class="fa-solid fa-hashtag"></i>
                        <input type="number" step="any" min="0" name="quantity[]" required value="0">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- أزرار الإجراءات -->
    <div class="card actions-bar">
        <button type="button" class="btn btn-secondary" onclick="addProductRow()" style="display:inline-flex; align-items:center; gap:8px;">
            <i class="fa-solid fa-circle-plus" style="color: #2563eb;"></i> إضافة منتج آخر
        </button>

        <button type="submit" class="btn btn-primary" style="display:inline-flex; align-items:center; gap:8px;">
            <i class="fa-solid fa-floppy-disk"></i> حفظ جميع المنتجات
        </button>
    </div>
</form>

<script>
    function updateRowNumbers() {
        const rows = document.querySelectorAll('.product-row');
        rows.forEach((row, index) => {
            row.querySelector('.row-number').textContent = index + 1;
            const removeBtn = row.querySelector('.btn-remove-row');
            if (rows.length > 1) {
                removeBtn.style.display = 'inline-flex';
            } else {
                removeBtn.style.display = 'none';
            }
        });
    }

    function addProductRow() {
        const container = document.getElementById('productsContainer');
        const firstRow = container.querySelector('.product-row');
        const newRow = firstRow.cloneNode(true);

        // إعادة تعيين قيم المدخلات في السطر الجديد
        newRow.querySelectorAll('input').forEach(input => {
            if (input.type === 'number') {
                input.value = '0';
            } else {
                input.value = '';
            }
        });

        newRow.querySelectorAll('select').forEach(select => {
            select.selectedIndex = 0;
        });

        container.appendChild(newRow);
        updateRowNumbers();

        // التمرير السلس إلى المنتجات المضافة
        newRow.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function removeProductRow(button) {
        const rows = document.querySelectorAll('.product-row');
        if (rows.length > 1) {
            const row = button.closest('.product-row');
            row.remove();
            updateRowNumbers();
        }
    }
</script>

<?php require_once 'includes/footer.php'; ?>