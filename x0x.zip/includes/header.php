<?php 
require_once __DIR__ . '/functions.php'; 
require_login(); 
$flash = get_flash(); 
$storeName = app_setting($pdo, "store_name", "برنامج المحاسبة");
$currentPage = current_page();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($storeName) ?></title>
    
    <!-- خط Cairo العصري من Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="assets/style.css">

    <!-- تنسيقات الهيكل والمظهر العصري للشريط الجانبي والتنبيهات -->
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --bg-main: #f8fafc;
            --sidebar-bg: #0f172a;
            --sidebar-hover: #1e293b;
            --sidebar-text: #94a3b8;
            --sidebar-text-active: #ffffff;
            --sidebar-active-bg: #2563eb;
            --text-main: #1e293b;
            --border-color: #e2e8f0;
        }

        body {
            font-family: 'Cairo', sans-serif;
            background-color: var(--bg-main);
            color: var(--text-main);
            margin: 0;
            padding: 0;
        }

        .layout {
            display: flex;
            min-height: 100vh;
        }

        /* الشريط الجانبي */
        .sidebar {
            width: 260px;
            background-color: var(--sidebar-bg);
            color: var(--sidebar-text);
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-brand {
            padding: 1.25rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .sidebar-brand h2 {
            margin: 0;
            font-size: 1.15rem;
            font-weight: 700;
            color: #ffffff;
        }

        .sidebar-menu {
            padding: 1rem 0.75rem;
            flex-grow: 1;
            overflow-y: auto;
        }

        .menu-group-title {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            color: #64748b;
            padding: 0.75rem 0.75rem 0.35rem 0.75rem;
            letter-spacing: 0.5px;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.65rem 0.85rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: 8px;
            font-size: 0.925rem;
            font-weight: 600;
            margin-bottom: 0.2rem;
            transition: all 0.2s ease;
        }

        .sidebar a svg {
            width: 18px;
            height: 18px;
            stroke-width: 2;
            flex-shrink: 0;
        }

        .sidebar a:hover {
            background-color: var(--sidebar-hover);
            color: var(--sidebar-text-active);
        }

        .sidebar a.active {
            background-color: var(--sidebar-active-bg);
            color: var(--sidebar-text-active);
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }

        /* المحتوى الرئيسي */
        .main-wrapper {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
        }

        .top-navbar {
            background: #ffffff;
            border-bottom: 1px solid var(--border-color);
            padding: 0.85rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .menu-toggle-btn {
            display: none;
            background: none;
            border: none;
            cursor: pointer;
            padding: 0.25rem;
            color: var(--text-main);
        }

        .content {
            padding: 1.5rem;
            flex-grow: 1;
        }

        /* تنبيهات النظام */
        .flash {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.85rem 1.25rem;
            border-radius: 10px;
            margin-bottom: 1.25rem;
            font-weight: 600;
            font-size: 0.95rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.03);
        }
        .flash.success { background-color: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
        .flash.error { background-color: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }
        .flash.warning { background-color: #fef3c7; color: #b45309; border: 1px solid #fde68a; }
        .flash.info { background-color: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; }

        .flash-close {
            background: none;
            border: none;
            font-size: 1.2rem;
            cursor: pointer;
            color: inherit;
            opacity: 0.7;
        }
        .flash-close:hover { opacity: 1; }

        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                right: -260px;
                height: 100vh;
            }
            .sidebar.show {
                right: 0;
            }
            .menu-toggle-btn {
                display: block;
            }
        }
    </style>
</head>
<body>

<div class="layout">
    <!-- الشريط الجانبي -->
    <aside class="sidebar" id="appSidebar">
        <div class="sidebar-brand">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--primary);"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            <h2><?= e($storeName) ?></h2>
        </div>

        <nav class="sidebar-menu">
            <!-- قسم الرئيسيات -->
            <a href="index.php" class="<?= $currentPage === 'index.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                لوحة التحكم
            </a>

            <!-- قسم المبيعات والمشتريات -->
            <div class="menu-group-title">الحركات اليومية</div>
            <a href="invoices.php" class="<?= $currentPage === 'invoices.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
                فاتورة جديدة
            </a>
            <a href="invoice_history.php" class="<?= $currentPage === 'invoice_history.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                سجل الفواتير
            </a>
            <a href="purchase_invoices.php" class="<?= $currentPage === 'purchase_invoices.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
                فواتير الشراء
            </a>

            <!-- قسم المستودع والحسابات -->
            <div class="menu-group-title">الإدارة والمالية</div>
            <a href="products.php" class="<?= $currentPage === 'products.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                المستودع
            </a>
            <a href="customers.php" class="<?= $currentPage === 'customers.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                الزبائن
            </a>
            <a href="suppliers.php" class="<?= $currentPage === 'suppliers.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                الموردين
            </a>
            <a href="employees.php" class="<?= $currentPage === 'employees.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 012-2h2a2 2 0 012 2v1m-4 0h4"/></svg>
                الموظفين
            </a>
            <a href="expenses.php" class="<?= $currentPage === 'expenses.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                المصروفات
            </a>
            <a href="cashbox.php" class="<?= $currentPage === 'cashbox.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                الصندوق
            </a>
            <a href="reports.php" class="<?= in_array($currentPage, ['reports.php','reports_daily.php','reports_monthly.php','reports_yearly.php','reports_daily_print.php','reports_monthly_print.php','reports_yearly_print.php']) ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                التقارير
            </a>

            <!-- قسم النظام -->
            <div class="menu-group-title">النظام</div>
            <a href="settings.php" class="<?= $currentPage === 'settings.php' ? 'active' : '' ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                الإعدادات
            </a>
            <a href="logout.php" style="color: #f87171; margin-top: 0.5rem;">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                تسجيل الخروج
            </a>
        </nav>
    </aside>

    <!-- منطقة المحتوى الرئيسية -->
    <div class="main-wrapper">
        <!-- الهيدر العلوي -->
        <header class="top-navbar">
            <button type="button" class="menu-toggle-btn" onclick="document.getElementById('appSidebar').classList.toggle('show')">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
            <div style="font-weight: 700; color: var(--text-main);">
                <?= e($storeName) ?>
            </div>
            <div style="font-size: 0.875rem; color: #64748b;">
                مرحباً، <?= e($_SESSION['user_name'] ?? 'المستخدم') ?>
            </div>
        </header>

        <!-- نص الصفحة الرئيسي -->
        <main class="content">
            <?php if ($flash): ?>
                <div class="flash <?= e($flash['type']) ?>">
                    <span><?= e($flash['message']) ?></span>
                    <button class="flash-close" onclick="this.parentElement.remove()">&times;</button>
                </div>
            <?php endif; ?>