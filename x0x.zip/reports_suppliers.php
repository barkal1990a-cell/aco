<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

$query = "
    SELECT 
        s.id,
        s.name AS supplier_name,
        s.phone,
        COUNT(pi.id) AS total_invoices,
        SUM(pi.total_amount) AS total_amount,
        SUM(pi.paid_amount) AS total_paid,
        (SUM(pi.total_amount) - SUM(pi.paid_amount)) AS remaining_balance
    FROM suppliers s
    LEFT JOIN purchase_invoices pi ON s.id = pi.supplier_id
    GROUP BY s.id
    ORDER BY remaining_balance DESC
";

$stmt = $pdo->prepare($query);
$stmt->execute();
$suppliers = $stmt->fetchAll();
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-truck me-2"></i>تقرير حسابات الموردين والمشتريات</h2>
        <a href="reports.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-right me-1"></i> العودة للتقارير</a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>اسم المورد</th>
                            <th>الهاتف</th>
                            <th>فواتير الشراء</th>
                            <th>إجمالي المشتريات</th>
                            <th>المبلغ المسدد له</th>
                            <th>المتبقي للمورد</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($suppliers as $index => $s): ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td class="fw-bold"><?= htmlspecialchars($s['supplier_name']) ?></td>
                                <td><?= htmlspecialchars($s['phone'] ?? '-') ?></td>
                                <td><?= $s['total_invoices'] ?></td>
                                <td><?= number_format($s['total_amount'] ?: 0, 2) ?></td>
                                <td class="text-success"><?= number_format($s['total_paid'] ?: 0, 2) ?></td>
                                <td>
                                    <?php $balance = $s['remaining_balance'] ?: 0; ?>
                                    <span class="badge <?= $balance > 0 ? 'bg-warning text-dark' : 'bg-secondary' ?> fs-6">
                                        <?= number_format($balance, 2) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>