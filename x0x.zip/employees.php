<?php
require_once 'config/database.php';
require_once 'includes/header.php';

/*
|--------------------------------------------------------------------------
| إنشاء الجداول المطلوبة
|--------------------------------------------------------------------------
*/

/* جدول السلف */
$pdo->exec("
    CREATE TABLE IF NOT EXISTS employee_advances (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        advance_date DATE NOT NULL,
        notes TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_advance_employee_runtime
            FOREIGN KEY (employee_id)
            REFERENCES employees(id)
            ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

/*
 * جدول الحساب الشهري للموظف.
 *
 * carried_advance:
 * قيمة السلفة الزائدة المرحلة من الشهر الماضي.
 *
 * advances_total:
 * مجموع السلف المسجلة خلال الشهر الحالي فقط.
 *
 * net_payable:
 * ما يستحقه الموظف للصرف في الشهر الحالي.
 *
 * carry_forward:
 * السلفة الزائدة بعد خصم راتب الشهر الحالي،
 * ويتم ترحيلها للشهر القادم.
 */
$pdo->exec("
    CREATE TABLE IF NOT EXISTS employee_salary_months (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        salary_year INT NOT NULL,
        salary_month INT NOT NULL,
        base_salary DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        carried_advance DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        advances_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        net_payable DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        carry_forward DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        status ENUM('open','closed') NOT NULL DEFAULT 'open',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ON UPDATE CURRENT_TIMESTAMP,

        UNIQUE KEY unique_employee_salary_month (
            employee_id,
            salary_year,
            salary_month
        ),

        CONSTRAINT fk_salary_month_employee_runtime
            FOREIGN KEY (employee_id)
            REFERENCES employees(id)
            ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

/*
|--------------------------------------------------------------------------
| دوال الراتب الشهري
|--------------------------------------------------------------------------
*/

/*
 * تحديث حساب راتب موظف لشهر محدد.
 *
 * المعادلة:
 *
 * الفرق = الراتب الأساسي
 *         - السلفة المرحلة من الشهر السابق
 *         - سلف الشهر الحالي
 *
 * إذا كان الفرق موجباً:
 *      يكون راتباً مستحقاً للصرف.
 *
 * إذا كان الفرق سالباً:
 *      يكون الراتب المستحق صفر،
 *      وقيمة الفرق تنقل كسلفة للشهر القادم.
 */
function updateEmployeeMonthlySalary(
    PDO $pdo,
    int $employeeId,
    int $year,
    int $month
): void {
    $employeeStmt = $pdo->prepare("
        SELECT salary
        FROM employees
        WHERE id = ?
        LIMIT 1
    ");

    $employeeStmt->execute([$employeeId]);

    $employee = $employeeStmt->fetch(PDO::FETCH_ASSOC);

    if (!$employee) {
        return;
    }

    $baseSalary = (float)$employee['salary'];

    /*
     * تحديد الشهر السابق.
     * مثال:
     * إذا كان الشهر الحالي 1 / 2026،
     * يصبح الشهر السابق 12 / 2025.
     */
    $previousDate = new DateTime(
        sprintf('%04d-%02d-01', $year, $month)
    );

    $previousDate->modify('-1 month');

    $previousYear = (int)$previousDate->format('Y');
    $previousMonth = (int)$previousDate->format('n');

    /*
     * جلب السلفة المرحلة من الشهر السابق.
     */
    $previousStmt = $pdo->prepare("
        SELECT carry_forward
        FROM employee_salary_months
        WHERE employee_id = ?
          AND salary_year = ?
          AND salary_month = ?
        LIMIT 1
    ");

    $previousStmt->execute([
        $employeeId,
        $previousYear,
        $previousMonth
    ]);

    $carriedAdvance = (float)($previousStmt->fetchColumn() ?: 0);

    /*
     * حساب السلف التي أخذها الموظف في هذا الشهر فقط.
     */
    $advanceStmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount), 0)
        FROM employee_advances
        WHERE employee_id = ?
          AND YEAR(advance_date) = ?
          AND MONTH(advance_date) = ?
    ");

    $advanceStmt->execute([
        $employeeId,
        $year,
        $month
    ]);

    $monthAdvances = (float)$advanceStmt->fetchColumn();

    /*
     * احتساب الراتب المستحق والسلفة المرحلة.
     */
    $difference = $baseSalary - $carriedAdvance - $monthAdvances;

    $netPayable = max(0, $difference);

    $carryForward = max(0, -$difference);

    /*
     * حفظ الحساب الشهري أو تحديثه إن كان موجوداً.
     */
    $saveStmt = $pdo->prepare("
        INSERT INTO employee_salary_months (
            employee_id,
            salary_year,
            salary_month,
            base_salary,
            carried_advance,
            advances_total,
            net_payable,
            carry_forward,
            status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open')

        ON DUPLICATE KEY UPDATE
            base_salary = VALUES(base_salary),
            carried_advance = VALUES(carried_advance),
            advances_total = VALUES(advances_total),
            net_payable = VALUES(net_payable),
            carry_forward = VALUES(carry_forward)
    ");

    $saveStmt->execute([
        $employeeId,
        $year,
        $month,
        $baseSalary,
        $carriedAdvance,
        $monthAdvances,
        $netPayable,
        $carryForward
    ]);
}

/*
|--------------------------------------------------------------------------
| معالجة النماذج
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
     * إضافة موظف جديد
     */
    if (isset($_POST['add_employee'])) {
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $jobTitle = trim($_POST['job_title'] ?? '');
        $salary = max(0, (float)($_POST['salary'] ?? 0));

        if ($name === '') {
            set_flash('error', 'يرجى إدخال اسم الموظف على الأقل');
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO employees (
                    name,
                    phone,
                    address,
                    job_title,
                    salary
                ) VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $name,
                $phone,
                $address,
                $jobTitle,
                $salary
            ]);

            set_flash('success', 'تمت إضافة الموظف بنجاح');
        }

        redirect('employees.php');
    }

    /*
     * تعديل بيانات موظف
     */
    if (isset($_POST['update_employee'])) {
        $employeeId = (int)($_POST['employee_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $jobTitle = trim($_POST['job_title'] ?? '');
        $salary = max(0, (float)($_POST['salary'] ?? 0));

        if ($employeeId <= 0 || $name === '') {
            set_flash('error', 'بيانات الموظف غير مكتملة');
        } else {
            $stmt = $pdo->prepare("
                UPDATE employees
                SET
                    name = ?,
                    phone = ?,
                    address = ?,
                    job_title = ?,
                    salary = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $name,
                $phone,
                $address,
                $jobTitle,
                $salary,
                $employeeId
            ]);

            /*
             * إعادة حساب راتب الشهر الحالي بعد تعديل الراتب الأساسي.
             */
            updateEmployeeMonthlySalary(
                $pdo,
                $employeeId,
                (int)date('Y'),
                (int)date('n')
            );

            set_flash('success', 'تم تعديل بيانات الموظف بنجاح');
        }

        redirect('employees.php');
    }

    /*
     * حذف موظف
     */
    if (isset($_POST['delete_employee'])) {
        $employeeId = (int)($_POST['employee_id'] ?? 0);

        if ($employeeId > 0) {
            $pdo->prepare("
                DELETE FROM employees
                WHERE id = ?
            ")->execute([$employeeId]);

            set_flash(
                'warning',
                'تم حذف الموظف مع سجلات السلف والحسابات الشهرية الخاصة به'
            );
        }

        redirect('employees.php');
    }

    /*
     * إضافة سلفة للموظف
     */
    if (isset($_POST['add_advance'])) {
        $employeeId = (int)($_POST['employee_id'] ?? 0);
        $amount = max(0, (float)($_POST['amount'] ?? 0));
        $advanceDate = $_POST['advance_date'] ?? date('Y-m-d');
        $notes = trim($_POST['notes'] ?? '');

        if ($employeeId <= 0 || $amount <= 0) {
            set_flash(
                'error',
                'يرجى تحديد الموظف وإدخال قيمة سلفة صحيحة'
            );

            redirect('employees.php');
        }

        try {
            $pdo->beginTransaction();

            /*
             * حفظ السلفة.
             */
            $advanceStmt = $pdo->prepare("
                INSERT INTO employee_advances (
                    employee_id,
                    amount,
                    advance_date,
                    notes
                ) VALUES (?, ?, ?, ?)
            ");

            $advanceStmt->execute([
                $employeeId,
                $amount,
                $advanceDate,
                $notes
            ]);

            /*
             * جلب اسم الموظف لحركة الصندوق.
             */
            $employeeStmt = $pdo->prepare("
                SELECT name
                FROM employees
                WHERE id = ?
            ");

            $employeeStmt->execute([$employeeId]);

            $employeeName = $employeeStmt->fetchColumn() ?: 'موظف';

            /*
             * تسجيل صرف السلفة من الصندوق.
             */
            $cashStmt = $pdo->prepare("
                INSERT INTO cashbox (
                    type,
                    reference_id,
                    amount,
                    description
                ) VALUES ('out', ?, ?, ?)
            ");

            $cashStmt->execute([
                $employeeId,
                $amount,
                'سلفة للموظف: ' . $employeeName
            ]);

            /*
             * تحديث حساب راتب الشهر الذي سجلت فيه السلفة.
             */
            $dateObject = new DateTime($advanceDate);

            updateEmployeeMonthlySalary(
                $pdo,
                $employeeId,
                (int)$dateObject->format('Y'),
                (int)$dateObject->format('n')
            );

            $pdo->commit();

            set_flash(
                'success',
                'تم تسجيل السلفة وخصم المبلغ من الصندوق وتحديث حساب الشهر'
            );
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            set_flash(
                'error',
                'حدث خطأ أثناء تسجيل السلفة: ' . $e->getMessage()
            );
        }

        redirect('employees.php');
    }

    /*
     * حذف / إلغاء سلفة وإرجاع المال إلى الصندوق.
     */
    if (isset($_POST['delete_advance'])) {
        $advanceId = (int)($_POST['advance_id'] ?? 0);

        if ($advanceId <= 0) {
            redirect('employees.php');
        }

        try {
            $pdo->beginTransaction();

            /*
             * الحصول على بيانات السلفة قبل الحذف.
             */
            $advanceStmt = $pdo->prepare("
                SELECT
                    a.*,
                    e.name AS employee_name
                FROM employee_advances a
                INNER JOIN employees e ON e.id = a.employee_id
                WHERE a.id = ?
            ");

            $advanceStmt->execute([$advanceId]);

            $advanceData = $advanceStmt->fetch(PDO::FETCH_ASSOC);

            if (!$advanceData) {
                $pdo->rollBack();

                set_flash('error', 'السلفة غير موجودة');

                redirect('employees.php');
            }

            /*
             * إعادة مبلغ السلفة إلى الصندوق.
             */
            $cashStmt = $pdo->prepare("
                INSERT INTO cashbox (
                    type,
                    reference_id,
                    amount,
                    description
                ) VALUES ('in', ?, ?, ?)
            ");

            $cashStmt->execute([
                $advanceData['employee_id'],
                $advanceData['amount'],
                'إلغاء سلفة الموظف: ' . $advanceData['employee_name']
            ]);

            /*
             * حذف السلفة.
             */
            $pdo->prepare("
                DELETE FROM employee_advances
                WHERE id = ?
            ")->execute([$advanceId]);

            /*
             * إعادة حساب شهر السلفة بعد حذفها.
             */
            $dateObject = new DateTime($advanceData['advance_date']);

            updateEmployeeMonthlySalary(
                $pdo,
                (int)$advanceData['employee_id'],
                (int)$dateObject->format('Y'),
                (int)$dateObject->format('n')
            );

            $pdo->commit();

            set_flash(
                'warning',
                'تم إلغاء السلفة وإعادة المبلغ للصندوق وتحديث حساب الشهر'
            );
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            set_flash(
                'error',
                'تعذر إلغاء السلفة: ' . $e->getMessage()
            );
        }

        redirect('employees.php');
    }
}

/*
|--------------------------------------------------------------------------
| جلب موظف للتعديل
|--------------------------------------------------------------------------
*/

$editEmployee = null;

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM employees
        WHERE id = ?
    ");

    $stmt->execute([(int)$_GET['edit']]);

    $editEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| إعداد بيانات الشهر الحالي
|--------------------------------------------------------------------------
*/

$currentYear = (int)date('Y');
$currentMonth = (int)date('n');

$arabicMonths = [
    1 => 'كانون الثاني',
    2 => 'شباط',
    3 => 'آذار',
    4 => 'نيسان',
    5 => 'أيار',
    6 => 'حزيران',
    7 => 'تموز',
    8 => 'آب',
    9 => 'أيلول',
    10 => 'تشرين الأول',
    11 => 'تشرين الثاني',
    12 => 'كانون الأول'
];

$currentMonthName = $arabicMonths[$currentMonth];

/*
 * إنشاء / تحديث سجل الشهر الحالي لكل الموظفين.
 */
$employeeRows = $pdo->query("
    SELECT id
    FROM employees
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($employeeRows as $employeeRow) {
    updateEmployeeMonthlySalary(
        $pdo,
        (int)$employeeRow['id'],
        $currentYear,
        $currentMonth
    );
}

/*
|--------------------------------------------------------------------------
| جلب الموظفين مع تفاصيل الشهر الحالي
|--------------------------------------------------------------------------
*/

$employeesStmt = $pdo->prepare("
    SELECT
        e.*,

        COALESCE(sm.carried_advance, 0) AS carried_advance,
        COALESCE(sm.advances_total, 0) AS current_month_advances,
        COALESCE(sm.net_payable, e.salary) AS net_payable,
        COALESCE(sm.carry_forward, 0) AS carry_forward

    FROM employees e

    LEFT JOIN employee_salary_months sm
        ON sm.employee_id = e.id
        AND sm.salary_year = ?
        AND sm.salary_month = ?

    ORDER BY e.id DESC
");

$employeesStmt->execute([
    $currentYear,
    $currentMonth
]);

$employees = $employeesStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| سجل السلف
|--------------------------------------------------------------------------
*/

$advances = $pdo->query("
    SELECT
        a.*,
        e.name AS employee_name
    FROM employee_advances a
    INNER JOIN employees e ON e.id = a.employee_id
    ORDER BY a.advance_date DESC, a.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| الإحصائيات
|--------------------------------------------------------------------------
*/

$totalEmployeesCount = count($employees);

$sumSalaries = 0;
$sumCarriedAdvances = 0;
$sumCurrentMonthAdvances = 0;
$sumNetPayable = 0;
$sumCarryForward = 0;

foreach ($employees as $employee) {
    $sumSalaries += (float)$employee['salary'];
    $sumCarriedAdvances += (float)$employee['carried_advance'];
    $sumCurrentMonthAdvances += (float)$employee['current_month_advances'];
    $sumNetPayable += (float)$employee['net_payable'];
    $sumCarryForward += (float)$employee['carry_forward'];
}
?>

<style>
    .emp-wrapper {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }

    .stat-card {
        background: #ffffff;
        padding: 1.25rem;
        border-radius: 12px;
        border: 1px solid #e5e7eb;
        box-shadow: 0 2px 4px rgba(0,0,0,0.02);
    }

    .stat-card .title {
        font-size: 0.85rem;
        color: #6b7280;
        font-weight: 600;
        margin-bottom: 0.25rem;
    }

    .stat-card .value {
        font-size: 1.35rem;
        font-weight: 700;
        color: #111827;
    }

    .card-custom {
        background: #ffffff;
        border-radius: 12px;
        border: 1px solid #e5e7eb;
        padding: 1.5rem;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.03);
    }

    .card-title {
        font-size: 1.15rem;
        font-weight: 700;
        color: #1f2937;
        margin-bottom: 1.25rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 0.5rem;
    }

    .form-grid-responsive {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 1rem;
        align-items: end;
    }

    .form-group label {
        display: block;
        font-size: 0.85rem;
        font-weight: 600;
        color: #374151;
        margin-bottom: 0.35rem;
    }

    .form-control-custom {
        width: 100%;
        padding: 0.6rem 0.8rem;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        font-size: 0.95rem;
        outline: none;
        transition: all 0.2s;
    }

    .form-control-custom:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37,99,235,0.1);
    }

    .contact-actions {
        display: flex;
        gap: 0.35rem;
        align-items: center;
        flex-wrap: wrap;
    }

    .contact-btn {
        padding: 0.2rem 0.45rem;
        border-radius: 6px;
        font-size: 0.78rem;
        text-decoration: none;
        font-weight: 600;
    }

    .btn-whatsapp {
        background-color: #dcfce7;
        color: #15803d;
        border: 1px solid #bbf7d0;
    }

    .btn-call {
        background-color: #f1f5f9;
        color: #334155;
        border: 1px solid #e2e8f0;
    }

    .badge-adv-zero {
        background-color: #f3f4f6;
        color: #4b5563;
        padding: 0.2rem 0.5rem;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
        white-space: nowrap;
    }

    .badge-adv-has {
        background-color: #fee2e2;
        color: #991b1b;
        padding: 0.2rem 0.5rem;
        border-radius: 6px;
        font-weight: 700;
        font-size: 0.85rem;
        white-space: nowrap;
    }

    .badge-net-pay {
        background-color: #d1fae5;
        color: #065f46;
        padding: 0.2rem 0.5rem;
        border-radius: 6px;
        font-weight: 700;
        font-size: 0.85rem;
        white-space: nowrap;
    }

    .badge-month {
        background-color: #dbeafe;
        color: #1d4ed8;
        padding: 0.25rem 0.65rem;
        border-radius: 999px;
        font-size: 0.82rem;
        font-weight: 700;
    }
</style>

<div class="emp-wrapper">

    <div
        class="card-custom"
        style="padding: 1rem 1.5rem; background: linear-gradient(to left, #0f172a, #1e293b); color: #fff;"
    >
        <h2
            style="margin:0; font-size:1.4rem; font-weight:700;"
        >
            شؤون الموظفين والسلف المالية
        </h2>

        <p
            style="margin:0.25rem 0 0 0; color:#94a3b8; font-size:0.88rem;"
        >
            إدارة الرواتب والسلف للشهر الحالي مع ترحيل السلف الزائدة للشهر القادم.
        </p>
    </div>

    <div class="card-custom" style="padding:1rem 1.5rem;">
        <div class="card-title" style="margin-bottom:0;">
            <span>
                الشهر المالي الحالي:
                <span class="badge-month">
                    <?= e($currentMonthName) ?> <?= e((string)$currentYear) ?>
                </span>
            </span>

            <span style="font-size:0.85rem; color:#6b7280;">
                السلفة الزائدة عن الراتب تنتقل تلقائيًا إلى الشهر التالي.
            </span>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="title">عدد الموظفين</div>
            <div class="value">
                <?= e((string)$totalEmployeesCount) ?>
                <span
                    style="font-size:0.85rem; color:#6b7280; font-weight:normal;"
                >
                    موظف
                </span>
            </div>
        </div>

        <div class="stat-card">
            <div class="title">إجمالي كتلة الرواتب</div>
            <div class="value">
                <?= format_money($pdo, $sumSalaries) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="title">سلف مرحلة من الشهر السابق</div>
            <div class="value" style="color:#dc2626;">
                <?= format_money($pdo, $sumCarriedAdvances) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="title">سلف الشهر الحالي</div>
            <div class="value" style="color:#dc2626;">
                <?= format_money($pdo, $sumCurrentMonthAdvances) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="title">صافي الرواتب المستحقة</div>
            <div class="value" style="color:#059669;">
                <?= format_money($pdo, $sumNetPayable) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="title">سلف مرحلة للشهر القادم</div>
            <div class="value" style="color:#b91c1c;">
                <?= format_money($pdo, $sumCarryForward) ?>
            </div>
        </div>
    </div>

    <div
        class="card-custom"
        style="<?= $editEmployee ? 'border-top:4px solid #f59e0b;' : 'border-top:4px solid #2563eb;' ?>"
    >
        <div class="card-title">
            <span>
                <?= $editEmployee
                    ? 'تعديل بيانات الموظف: (' . e($editEmployee['name']) . ')'
                    : 'إضافة موظف جديد'
                ?>
            </span>

            <?php if ($editEmployee): ?>
                <a
                    href="employees.php"
                    class="btn btn-outline-secondary btn-sm"
                    style="font-size:0.85rem; text-decoration:none;"
                >
                    ✕ إلغاء التعديل
                </a>
            <?php endif; ?>
        </div>

        <form method="post" class="form-grid-responsive">
            <input
                type="hidden"
                name="<?= $editEmployee ? 'update_employee' : 'add_employee' ?>"
                value="1"
            >

            <?php if ($editEmployee): ?>
                <input
                    type="hidden"
                    name="employee_id"
                    value="<?= e((string)$editEmployee['id']) ?>"
                >
            <?php endif; ?>

            <div class="form-group">
                <label>
                    اسم الموظف الكامل
                    <span style="color:#ef4444;">*</span>
                </label>

                <input
                    name="name"
                    class="form-control-custom"
                    placeholder="مثال: أحمد محمود"
                    required
                    value="<?= e($editEmployee['name'] ?? '') ?>"
                >
            </div>

            <div class="form-group">
                <label>رقم الهاتف</label>

                <input
                    name="phone"
                    class="form-control-custom"
                    placeholder="09xxxxxxxx"
                    value="<?= e($editEmployee['phone'] ?? '') ?>"
                >
            </div>

            <div class="form-group">
                <label>العنوان</label>

                <input
                    name="address"
                    class="form-control-custom"
                    placeholder="مثال: دمشق - الميدان"
                    value="<?= e($editEmployee['address'] ?? '') ?>"
                >
            </div>

            <div class="form-group">
                <label>المسمى الوظيفي</label>

                <input
                    name="job_title"
                    class="form-control-custom"
                    placeholder="مثال: محاسب / أمين مستودع"
                    value="<?= e($editEmployee['job_title'] ?? '') ?>"
                >
            </div>

            <div class="form-group">
                <label>الراتب الشهري الأساسي</label>

                <input
                    type="number"
                    step="0.01"
                    min="0"
                    name="salary"
                    class="form-control-custom"
                    placeholder="0.00"
                    value="<?= e($editEmployee['salary'] ?? '') ?>"
                >
            </div>

            <div
                class="form-group"
                style="grid-column:1/-1; display:flex; justify-content:flex-end; margin-top:0.5rem;"
            >
                <button
                    type="submit"
                    class="btn <?= $editEmployee ? 'btn-warning' : 'btn-primary' ?>"
                    style="padding:0.6rem 1.75rem; font-weight:600;"
                >
                    <?= $editEmployee ? 'حفظ التعديلات' : '+ إضافة الموظف' ?>
                </button>
            </div>
        </form>
    </div>

    <div class="card-custom" style="border-top:4px solid #10b981;">
        <div class="card-title" style="color:#065f46;">
            <span>💸 تسليم سلفة مالية لموظف</span>
        </div>

        <form method="post" class="form-grid-responsive">
            <input type="hidden" name="add_advance" value="1">

            <div class="form-group">
                <label>
                    اختر الموظف
                    <span style="color:#ef4444;">*</span>
                </label>

                <select
                    name="employee_id"
                    class="form-control-custom"
                    required
                >
                    <option value="">-- اختر موظفاً --</option>

                    <?php foreach ($employees as $employee): ?>
                        <option value="<?= e((string)$employee['id']) ?>">
                            <?= e($employee['name']) ?>
                            — الراتب:
                            <?= format_money($pdo, $employee['salary']) ?>
                            — المستحق الحالي:
                            <?= format_money($pdo, $employee['net_payable']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>
                    مبلغ السلفة
                    <span style="color:#ef4444;">*</span>
                </label>

                <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    name="amount"
                    class="form-control-custom"
                    placeholder="0.00"
                    required
                >
            </div>

            <div class="form-group">
                <label>تاريخ السلفة</label>

                <input
                    type="date"
                    name="advance_date"
                    class="form-control-custom"
                    value="<?= date('Y-m-d') ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>ملاحظات / سبب السلفة</label>

                <input
                    name="notes"
                    class="form-control-custom"
                    placeholder="مثال: سلفة على راتب الشهر"
                >
            </div>

            <div
                class="form-group"
                style="grid-column:1/-1; display:flex; justify-content:flex-end; margin-top:0.5rem;"
            >
                <button
                    type="submit"
                    class="btn btn-success"
                    style="padding:0.6rem 1.75rem; font-weight:600;"
                >
                    ✓ تسجيل وخصم من الصندوق
                </button>
            </div>
        </form>
    </div>

    <div class="card-custom">
        <div class="card-title">
            <span>
                سجل الموظفين ورواتب
                <?= e($currentMonthName) ?>
                <?= e((string)$currentYear) ?>
            </span>

            <div style="width:260px;">
                <input
                    type="text"
                    id="empSearchInput"
                    onkeyup="filterEmployees()"
                    class="form-control-custom"
                    placeholder="🔍 بحث باسم، وظيفة أو هاتف..."
                    style="font-size:0.85rem; padding:0.4rem 0.75rem;"
                >
            </div>
        </div>

        <div style="overflow-x:auto;">
            <table
                class="table"
                id="empTable"
                style="width:100%; border-collapse:collapse;"
            >
                <thead>
                    <tr
                        style="background-color:#f8fafc; border-bottom:2px solid #e2e8f0; text-align:right;"
                    >
                        <th style="padding:0.75rem;">#</th>
                        <th style="padding:0.75rem;">اسم الموظف</th>
                        <th style="padding:0.75rem;">الهاتف</th>
                        <th style="padding:0.75rem;">الوظيفة والعنوان</th>
                        <th style="padding:0.75rem;">الراتب الأساسي</th>
                        <th style="padding:0.75rem;">سلفة مرحلة</th>
                        <th style="padding:0.75rem;">سلف هذا الشهر</th>
                        <th style="padding:0.75rem;">المستحق للشهر</th>
                        <th style="padding:0.75rem;">مرحّل للشهر القادم</th>
                        <th style="padding:0.75rem; text-align:center;">إجراءات</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (empty($employees)): ?>
                        <tr>
                            <td
                                colspan="10"
                                style="text-align:center; padding:2rem; color:#9ca3af;"
                            >
                                لا يوجد موظفون مسجلون حتى الآن.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($employees as $employee): ?>
                            <?php
                            $salaryValue = (float)$employee['salary'];
                            $carriedAdvance = (float)$employee['carried_advance'];
                            $currentMonthAdvances = (float)$employee['current_month_advances'];
                            $netPayable = (float)$employee['net_payable'];
                            $carryForward = (float)$employee['carry_forward'];
                            ?>

                            <tr
                                class="emp-row"
                                style="border-bottom:1px solid #f1f5f9;"
                            >
                                <td
                                    style="padding:0.75rem; color:#6b7280;"
                                >
                                    <?= e((string)$employee['id']) ?>
                                </td>

                                <td
                                    style="padding:0.75rem; font-weight:700; color:#1e293b;"
                                    class="search-name"
                                >
                                    <?= e($employee['name']) ?>
                                </td>

                                <td
                                    style="padding:0.75rem;"
                                    class="search-phone"
                                >
                                    <?php if (!empty($employee['phone'])): ?>
                                        <?php
                                        $cleanPhone = preg_replace(
                                            '/[^0-9+]/',
                                            '',
                                            $employee['phone']
                                        );
                                        ?>

                                        <div class="contact-actions">
                                            <span><?= e($employee['phone']) ?></span>

                                            <a
                                                href="https://wa.me/<?= e($cleanPhone) ?>"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                class="contact-btn btn-whatsapp"
                                            >
                                                واتساب
                                            </a>

                                            <a
                                                href="tel:<?= e($cleanPhone) ?>"
                                                class="contact-btn btn-call"
                                            >
                                                اتصال
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <span
                                            style="color:#9ca3af; font-size:0.85rem;"
                                        >
                                            غ/م
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td
                                    style="padding:0.75rem; color:#4b5563;"
                                    class="search-job"
                                >
                                    <strong>
                                        <?= !empty($employee['job_title'])
                                            ? e($employee['job_title'])
                                            : '-'
                                        ?>
                                    </strong>

                                    <br>

                                    <small style="color:#9ca3af;">
                                        <?= !empty($employee['address'])
                                            ? e($employee['address'])
                                            : ''
                                        ?>
                                    </small>
                                </td>

                                <td
                                    style="padding:0.75rem; font-weight:600; color:#111827;"
                                >
                                    <?= format_money($pdo, $salaryValue) ?>
                                </td>

                                <td style="padding:0.75rem;">
                                    <?php if ($carriedAdvance > 0): ?>
                                        <span class="badge-adv-has">
                                            <?= format_money($pdo, $carriedAdvance) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge-adv-zero">
                                            0.00
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td style="padding:0.75rem;">
                                    <?php if ($currentMonthAdvances > 0): ?>
                                        <span class="badge-adv-has">
                                            <?= format_money($pdo, $currentMonthAdvances) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge-adv-zero">
                                            0.00
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td style="padding:0.75rem;">
                                    <span class="badge-net-pay">
                                        <?= format_money($pdo, $netPayable) ?>
                                    </span>
                                </td>

                                <td style="padding:0.75rem;">
                                    <?php if ($carryForward > 0): ?>
                                        <span class="badge-adv-has">
                                            <?= format_money($pdo, $carryForward) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge-adv-zero">
                                            0.00
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td
                                    style="padding:0.75rem; text-align:center;"
                                >
                                    <div
                                        style="display:flex; gap:0.4rem; justify-content:center;"
                                    >
                                        <a
                                            class="btn btn-warning btn-sm"
                                            href="employees.php?edit=<?= e((string)$employee['id']) ?>"
                                            style="padding:0.25rem 0.6rem; font-size:0.8rem; text-decoration:none;"
                                        >
                                            تعديل
                                        </a>

                                        <form
                                            method="post"
                                            style="display:inline;"
                                            onsubmit="return confirm('هل أنت متأكد من حذف الموظف: <?= e($employee['name']) ?>؟ سيتم حذف سجلات سلفه وحساباته الشهرية أيضاً.')"
                                        >
                                            <input
                                                type="hidden"
                                                name="delete_employee"
                                                value="1"
                                            >

                                            <input
                                                type="hidden"
                                                name="employee_id"
                                                value="<?= e((string)$employee['id']) ?>"
                                            >

                                            <button
                                                class="btn btn-danger btn-sm"
                                                style="padding:0.25rem 0.6rem; font-size:0.8rem;"
                                            >
                                                حذف
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-title">
            <span>📋 سجل السلف المدفوعة مؤخراً</span>
        </div>

        <div style="overflow-x:auto;">
            <table
                class="table"
                style="width:100%; border-collapse:collapse;"
            >
                <thead>
                    <tr
                        style="background-color:#f8fafc; border-bottom:2px solid #e2e8f0; text-align:right;"
                    >
                        <th style="padding:0.75rem;">#</th>
                        <th style="padding:0.75rem;">الموظف</th>
                        <th style="padding:0.75rem;">قيمة السلفة</th>
                        <th style="padding:0.75rem;">تاريخ الدفع</th>
                        <th style="padding:0.75rem;">ملاحظات</th>
                        <th style="padding:0.75rem; text-align:center;">إلغاء السلفة</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (empty($advances)): ?>
                        <tr>
                            <td
                                colspan="6"
                                style="text-align:center; padding:2rem; color:#9ca3af;"
                            >
                                لا يوجد سلف مسجلة حالياً.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($advances as $advance): ?>
                            <tr style="border-bottom:1px solid #f1f5f9;">
                                <td
                                    style="padding:0.75rem; color:#6b7280;"
                                >
                                    <?= e((string)$advance['id']) ?>
                                </td>

                                <td
                                    style="padding:0.75rem; font-weight:700; color:#1e293b;"
                                >
                                    <?= e($advance['employee_name']) ?>
                                </td>

                                <td
                                    style="padding:0.75rem; font-weight:700; color:#dc2626;"
                                >
                                    <?= format_money($pdo, $advance['amount']) ?>
                                </td>

                                <td
                                    style="padding:0.75rem; color:#374151;"
                                >
                                    <?= e($advance['advance_date']) ?>
                                </td>

                                <td
                                    style="padding:0.75rem; color:#6b7280; font-size:0.9rem;"
                                >
                                    <?= !empty($advance['notes'])
                                        ? e($advance['notes'])
                                        : '-'
                                    ?>
                                </td>

                                <td
                                    style="padding:0.75rem; text-align:center;"
                                >
                                    <form
                                        method="post"
                                        style="display:inline;"
                                        onsubmit="return confirm('هل تريد إلغاء هذه السلفة وإعادة مبلغها إلى الصندوق؟')"
                                    >
                                        <input
                                            type="hidden"
                                            name="delete_advance"
                                            value="1"
                                        >

                                        <input
                                            type="hidden"
                                            name="advance_id"
                                            value="<?= e((string)$advance['id']) ?>"
                                        >

                                        <button
                                            class="btn btn-outline-danger btn-sm"
                                            style="padding:0.2rem 0.5rem; font-size:0.78rem;"
                                        >
                                            إلغاء وإعادة الصندوق
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
function filterEmployees() {
    const input = document.getElementById('empSearchInput');
    const filter = input.value.toLowerCase().trim();
    const rows = document.getElementsByClassName('emp-row');

    for (let i = 0; i < rows.length; i++) {
        const nameCell = rows[i].querySelector('.search-name');
        const phoneCell = rows[i].querySelector('.search-phone');
        const jobCell = rows[i].querySelector('.search-job');

        const nameText = nameCell
            ? nameCell.textContent.toLowerCase()
            : '';

        const phoneText = phoneCell
            ? phoneCell.textContent.toLowerCase()
            : '';

        const jobText = jobCell
            ? jobCell.textContent.toLowerCase()
            : '';

        if (
            nameText.includes(filter) ||
            phoneText.includes(filter) ||
            jobText.includes(filter)
        ) {
            rows[i].style.display = '';
        } else {
            rows[i].style.display = 'none';
        }
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>