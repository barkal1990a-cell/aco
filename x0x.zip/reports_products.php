<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

// تحديد نطاق التواريخ للتصفية (افتراضياً بداية الشهر الحالي حتى اليوم)
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date   = isset($_GET['end_date'])   ? $_GET['end_date']   : date('Y-m-d');
$search     = isset($_GET['search'])     ? trim($_GET['search']) : '';

// تهيئة المتغيرات بقيم افتراضية لمنع تحذيرات (Undefined Variable)
$grand_total_sales  = 0;
$grand_total_profit = 0;
$grand_total_qty    = 0;
$products_report    = [];

try {
    // حساب الإجمالي والربح عبر ضرب (الكمية × السعر) تجنباً لعدم وجود عمود total
    $sql = "
        SELECT 
            p.id,
            p.id AS code,
            p.name AS product_name,
            COALESCE(p.quantity, 0) AS current_stock,
            COALESCE(SUM(ii.quantity), 0) AS total_qty_sold,
            COALESCE(SUM(ii.quantity * COALESCE(ii.price, 0)), 0) AS total_sales,
            COALESCE(SUM((ii.quantity * COALESCE(ii.price, 0)) - (ii.quantity * COALESCE(p.cost_price, 0))), 0) AS total_profit
        FROM products p
        LEFT JOIN invoice_items ii ON p.id = ii.product_id
        LEFT JOIN invoices i ON ii.invoice_id = i.id AND DATE(i.created_at) BETWEEN :start_date AND :end_date
        WHERE 1=1
    ";

    $params = [
        ':start_date' => $start_date,
        ':end_date'   => $end_date
    ];

    if (!empty($search)) {
        $sql .= " AND (p.name LIKE :search OR p.id LIKE :search)";
        $params[':search'] = "%$search%";
    }

    $sql .= " GROUP BY p.id, p.name, p.quantity ORDER BY total_sales DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $products_report = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // حساب المجاميع العامة للمؤشرات السريعة
    foreach ($products_report as $item) {
        $grand_total_sales  += (float)$item['total_sales'];
        $grand_total_profit += (float)$item['total_profit'];
        $grand_total_qty    += (float)$item['total_qty_sold'];
    }

} catch (PDOException $e) {
    $error_message = "حدث خطأ في قاعدة البيانات: " . $e->getMessage();
}
?>

<div class="container-fluid py-4 px-4">
    <!-- العنونة وأزرار التحكم -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="h3 fw-bold text-dark mb-1">
                <i class="fas fa-cubes me-2" style="color: #6f42c1;"></i>تقرير حركة المنتجات والأكثر مبيعاً
            </h2>
            <p class="text-muted small mb-0">تحليل مبيعات وأرباح الأصناف والمخزون المتبقي في المستودع</p>
        </div>
        <div>
            <button class="btn btn-outline-secondary btn-sm px-3 shadow-sm border" onclick="window.print()">
                <i class="fas fa-print me-1"></i> طباعة التقرير
            </button>
        </div>
    </div>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger shadow-sm rounded-3 mb-4"><?= htmlspecialchars($error_message) ?></div>
    <?php endif; ?>

    <!-- نموذج التصفية والبحث -->
    <div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
        <div class="card-body p-3">
            <form method="GET" action="" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label small fw-semibold text-muted">من تاريخ</label>
                    <input type="date" name="start_date" class="form-control form-control-sm" value="<?= htmlspecialchars($start_date) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-semibold text-muted">إلى تاريخ</label>
                    <input type="date" name="end_date" class="form-control form-control-sm" value="<?= htmlspecialchars($end_date) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold text-muted">بحث باسم المنتج أو رقم الأصناف</label>
                    <input type="text" name="search" class="form-control form-control-sm" placeholder="أدخل اسم المنتج أو الرقم..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm w-100 fw-semibold">
                        <i class="fas fa-filter me-1"></i> تصفية
                    </button>
                    <a href="reports_products.php" class="btn btn-light btn-sm border" title="إعادة ضبط">
                        <i class="fas fa-undo"></i>
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- بطاقات الإحصائيات السريعة -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
                <div class="d-flex align-items-center">
                    <div class="p-3 rounded-3 me-3" style="background-color: #f3ebf9; color: #6f42c1;">
                        <i class="fas fa-boxes-stacked fa-2x"></i>
                    </div>
                    <div>
                        <span class="text-muted small d-block mb-1">إجمالي القطع المباعة</span>
                        <h4 class="fw-bold mb-0 text-dark"><?= number_format($grand_total_qty) ?> قطعة</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
                <div class="d-flex align-items-center">
                    <div class="p-3 rounded-3 bg-primary bg-opacity-10 text-primary me-3">
                        <i class="fas fa-dollar-sign fa-2x"></i>
                    </div>
                    <div>
                        <span class="text-muted small d-block mb-1">إجمالي مبيعات المنتجات</span>
                        <h4 class="fw-bold mb-0 text-dark"><?= number_format($grand_total_sales, 2) ?> $</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
                <div class="d-flex align-items-center">
                    <div class="p-3 rounded-3 bg-success bg-opacity-10 text-success me-3">
                        <i class="fas fa-chart-line fa-2x"></i>
                    </div>
                    <div>
                        <span class="text-muted small d-block mb-1">إجمالي صافي أرباح المنتجات</span>
                        <h4 class="fw-bold mb-0 text-dark"><?= number_format($grand_total_profit, 2) ?> $</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- جدول عرض تقرير المنتجات -->
    <div class="card border-0 shadow-sm rounded-3 bg-white">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="py-3 px-3 text-center" style="width: 50px;">#</th>
                            <th class="py-3">رقم المنتج</th>
                            <th class="py-3">اسم المنتج</th>
                            <th class="py-3 text-center">المخزون الحالي</th>
                            <th class="py-3 text-center">الكمية المباعة</th>
                            <th class="py-3 text-end">إجمالي المبيعات</th>
                            <th class="py-3 text-end px-3">صافي الربح</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($products_report)): ?>
                            <?php foreach ($products_report as $index => $row): ?>
                                <tr>
                                    <td class="text-center text-muted small px-3"><?= $index + 1 ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border font-monospace">
                                            #<?= htmlspecialchars($row['code']) ?>
                                        </span>
                                    </td>
                                    <td class="fw-semibold text-dark"><?= htmlspecialchars($row['product_name']) ?></td>
                                    <td class="text-center">
                                        <span class="badge <?= $row['current_stock'] <= 5 ? 'bg-danger' : 'bg-secondary' ?> bg-opacity-10 text-dark px-2 py-1">
                                            <?= number_format($row['current_stock']) ?>
                                        </span>
                                    </td>
                                    <td class="text-center fw-bold text-primary"><?= number_format($row['total_qty_sold']) ?></td>
                                    <td class="text-end fw-bold text-dark"><?= number_format($row['total_sales'], 2) ?> $</td>
                                    <td class="text-end fw-bold text-success px-3"><?= number_format($row['total_profit'], 2) ?> $</td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">
                                    <i class="fas fa-inbox fa-2x mb-2 d-block text-secondary"></i>
                                    لا توجد بيانات حركة منتجات خلال الفترة المحددة.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>