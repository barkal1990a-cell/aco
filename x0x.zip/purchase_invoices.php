<?php
require_once 'config/database.php';
require_once 'includes/header.php';

// ---------------------------------------------------------------------
// 1. التهيئة التلقائية لبنية قاعدة البيانات (تنفيذ سريع وآمن)
// ---------------------------------------------------------------------
try {
    $columnCheck = $pdo->query("SHOW COLUMNS FROM suppliers LIKE 'balance'");
    if ($columnCheck->rowCount() === 0) {
        $pdo->exec("ALTER TABLE suppliers ADD COLUMN balance DECIMAL(12,2) NOT NULL DEFAULT 0.00");
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS purchase_invoices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        purchase_number VARCHAR(50) NOT NULL UNIQUE,
        supplier_id INT NOT NULL,
        total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        remaining_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        notes TEXT NULL,
        created_by INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_purchase_supplier_runtime FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS purchase_invoice_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        purchase_invoice_id INT NOT NULL,
        product_name VARCHAR(150) NOT NULL,
        quantity INT NOT NULL,
        unit_price DECIMAL(12,2) NOT NULL,
        total_price DECIMAL(12,2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_purchase_item_invoice_runtime FOREIGN KEY (purchase_invoice_id) REFERENCES purchase_invoices(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
} catch (PDOException $e) {
    // تسجيل الخطأ أو المتابعة في حال وجود الصلاحيات
}

// تهيئة سلة المشتريات
if (!isset($_SESSION['purchase_cart']) || !is_array($_SESSION['purchase_cart'])) {
    $_SESSION['purchase_cart'] = [];
}

// ---------------------------------------------------------------------
// 2. معالجة طلبات POST (إضافة، حذف، تفريغ، حفظ الفاتورة)
// ---------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // أ) إضافة صنف أو عدة أصناف إلى السلة
    if (isset($_POST['add_item'])) {
        $productNames = $_POST['product_name'] ?? [];
        $quantities   = $_POST['quantity'] ?? [];
        $unitPrices   = $_POST['unit_price'] ?? [];
        $salePrices   = $_POST['sale_price'] ?? [];

        $addedCount = 0;

        for ($i = 0; $i < count($productNames); $i++) {
            $name      = trim($productNames[$i] ?? '');
            $quantity  = max(1, (int)($quantities[$i] ?? 1));
            $unitPrice = max(0, (float)($unitPrices[$i] ?? 0));
            $salePrice = max($unitPrice, (float)($salePrices[$i] ?? $unitPrice));

            if ($name !== '' && $quantity > 0 && $unitPrice >= 0) {
                $found = false;
                // دمج الكمية إذا كان المنتج موجوداً مسبقاً في السلة
                foreach ($_SESSION['purchase_cart'] as &$cartItem) {
                    if (mb_strtolower($cartItem['product_name']) === mb_strtolower($name)) {
                        $cartItem['quantity'] += $quantity;
                        $cartItem['unit_price'] = $unitPrice; 
                        $cartItem['sale_price'] = $salePrice;
                        $cartItem['total_price'] = $cartItem['quantity'] * $unitPrice;
                        $found = true;
                        break;
                    }
                }
                unset($cartItem);

                if (!$found) {
                    $_SESSION['purchase_cart'][] = [
                        'product_name' => $name,
                        'quantity'     => $quantity,
                        'unit_price'   => $unitPrice,
                        'sale_price'   => $salePrice,
                        'total_price'  => $quantity * $unitPrice,
                    ];
                }
                $addedCount++;
            }
        }

        if ($addedCount > 0) {
            set_flash('success', 'تمت إضافة الأصناف إلى فاتورة الشراء بنجاح');
        } else {
            set_flash('error', 'يرجى إدخال اسم المنتج، الكمية، وسعر الشراء بشكل صحيح');
        }
        redirect('purchase_invoices.php');
    }

    // ب) حذف صنف محدد
    if (isset($_POST['remove_item'])) {
        $index = (int)$_POST['item_index'];
        if (isset($_SESSION['purchase_cart'][$index])) {
            unset($_SESSION['purchase_cart'][$index]);
            $_SESSION['purchase_cart'] = array_values($_SESSION['purchase_cart']);
            set_flash('warning', 'تم حذف الصنف من الفاتورة');
        }
        redirect('purchase_invoices.php');
    }

    // ج) تفريغ السلة بالكامل
    if (isset($_POST['clear_cart'])) {
        $_SESSION['purchase_cart'] = [];
        set_flash('info', 'تم إفراغ سلة فاتورة الشراء');
        redirect('purchase_invoices.php');
    }

    // د) حفظ فاتورة الشراء وإتمام العملية
    if (isset($_POST['save_purchase_invoice'])) {
        $supplierId = (int)($_POST['supplier_id'] ?? 0);
        $paidAmount = max(0, (float)($_POST['paid_amount'] ?? 0));
        $notes      = trim($_POST['notes'] ?? '');

        // حساب الإجمالي الكلي
        $total = 0;
        foreach ($_SESSION['purchase_cart'] as $item) {
            $total += $item['total_price'];
        }

        $remaining = max(0, $total - $paidAmount);
        $extraPaid = max(0, $paidAmount - $total);
        if ($supplierId <= 0) {
            set_flash('error', 'يرجى اختيار المورد قبل حفظ الفاتورة');
            redirect('purchase_invoices.php');
        }

        if (empty($_SESSION['purchase_cart'])) {
            set_flash('error', 'لا يمكن حفظ فاتورة فارغة. أضف بعض الأصناف أولاً');
            redirect('purchase_invoices.php');
        }

        $pdo->beginTransaction();
        try {
            $invNum = purchase_number($pdo);
            $userId = $_SESSION['user_id'] ?? null;

            // 1. تسجيل الفاتورة الرئيسية
            $stmt = $pdo->prepare("INSERT INTO purchase_invoices (purchase_number, supplier_id, total_amount, paid_amount, remaining_amount, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$invNum, $supplierId, $total, $paidAmount, $remaining, $notes, $userId]);
            $purchaseId = $pdo->lastInsertId();

            // 2. تسجيل عناصر الفاتورة وتحديث المخزون
            $itemStmt = $pdo->prepare("INSERT INTO purchase_invoice_items (purchase_invoice_id, product_name, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?)");
            $checkProd = $pdo->prepare("SELECT id, quantity, purchase_price FROM products WHERE name = ? LIMIT 1");
            $updateProd = $pdo->prepare("UPDATE products SET quantity = quantity + ?, purchase_price = ? WHERE id = ?");
            $insertProd = $pdo->prepare("INSERT INTO products (name, sku, category, purchase_price, sale_price, quantity) VALUES (?, '', 'مشتريات', ?, ?, ?)");

            foreach ($_SESSION['purchase_cart'] as $item) {
                $itemStmt->execute([
                    $purchaseId,
                    $item['product_name'],
                    $item['quantity'],
                    $item['unit_price'],
                    $item['total_price']
                ]);

                $checkProd->execute([$item['product_name']]);
                $existing = $checkProd->fetch(PDO::FETCH_ASSOC);

                if ($existing) {
                    $updateProd->execute([$item['quantity'], $item['unit_price'], $existing['id']]);
                } else {
                    $saleP = $item['sale_price'] ?? $item['unit_price'];
                    $insertProd->execute([$item['product_name'], $item['unit_price'], $saleP, $item['quantity']]);
                }
            }

            // 3. خروج النقدية من الصندوق
            if ($paidAmount > 0) {
                $cashStmt = $pdo->prepare("INSERT INTO cashbox (type, reference_id, amount, description) VALUES ('out', ?, ?, ?)");
                $cashStmt->execute([$purchaseId, $paidAmount, "دفعة فاتورة شراء رقم: {$invNum}"]);
            }

            // 4. تحديث دين المورد
            $supStmt = $pdo->prepare("
                UPDATE suppliers
                SET balance = GREATEST(0, balance + ? - ?)
                WHERE id = ?
            ");

            $supStmt->execute([
                $remaining,
                $extraPaid,
                $supplierId
            ]);

            $pdo->commit();

            $_SESSION['purchase_cart'] = [];
            set_flash('success', "تم حفظ فاتورة الشراء رقم ({$invNum}) بنجاح");

        } catch (Throwable $e) {
            $pdo->rollBack();
            set_flash('error', 'حدث خطأ أثناء حفظ الفاتورة: ' . $e->getMessage());
        }

        redirect('purchase_invoices.php');
    }
}

// ---------------------------------------------------------------------
// 3. جلب البيانات للعرض
// ---------------------------------------------------------------------
$suppliers = $pdo->query("SELECT id, name, balance FROM suppliers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$existingProducts = $pdo->query("SELECT name, purchase_price, sale_price FROM products ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

$previousInvoices = $pdo->query("
    SELECT pi.*, s.name as supplier_name 
    FROM purchase_invoices pi 
    LEFT JOIN suppliers s ON pi.supplier_id = s.id 
    ORDER BY pi.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

$cartTotal = 0;
$cartItemsCount = 0;
foreach ($_SESSION['purchase_cart'] as $item) {
    $cartTotal += $item['total_price'];
    $cartItemsCount += $item['quantity'];
}
$currencySymbol = app_setting($pdo, 'currency', 'ل.س');
?>

<!-- التنسيقات العصرية لمصفحة المشتريات -->
<style>
    .purchases-wrapper { display: flex; flex-direction: column; gap: 1.5rem; }
    .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; }
    .stat-card { background: #ffffff; padding: 1.25rem; border-radius: 12px; border: 1px solid #e5e7eb; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
    .stat-card .title { font-size: 0.875rem; color: #6b7280; font-weight: 600; margin-bottom: 0.25rem; }
    .stat-card .value { font-size: 1.5rem; font-weight: 700; color: #111827; }
    .card-custom { background: #ffffff; border-radius: 12px; border: 1px solid #e5e7eb; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.03); }
    .card-title { font-size: 1.15rem; font-weight: 700; color: #1f2937; margin-bottom: 1.25rem; display: flex; align-items: center; justify-content: space-between; }
    .form-grid-4 { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)) 60px; gap: 1rem; align-items: end; }
    .form-group label { display: block; font-size: 0.875rem; font-weight: 600; color: #374151; margin-bottom: 0.35rem; }
    .form-control-custom { width: 100%; padding: 0.625rem 0.85rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.95rem; transition: border-color 0.2s, box-shadow 0.2s; outline: none; }
    .form-control-custom:focus { border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,0.1); }
    .badge-qty { background-color: #e0e7ff; color: #3730a3; padding: 0.25rem 0.6rem; border-radius: 9999px; font-weight: 600; font-size: 0.85rem; }
    
    .product-row-item { background: #f8fafc; padding: 1rem; border-radius: 10px; border: 1px solid #e2e8f0; margin-bottom: 1rem; position: relative; }
    .remove-row-btn { background: #fee2e2; color: #dc2626; border: none; border-radius: 8px; width: 100%; height: 42px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: 0.2s; font-weight: bold; }
    .remove-row-btn:hover { background: #dc2626; color: #fff; }

    /* تنسيقات نافذة الفواتير المنبثقة */
    .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 1050; align-items: center; justify-content: center; backdrop-filter: blur(4px); }
    .modal-overlay.active { display: flex; }
    .modal-container { background: #ffffff; width: 95%; max-width: 1000px; border-radius: 12px; padding: 1.5rem; max-height: 90vh; display: flex; flex-direction: column; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e5e7eb; padding-bottom: 1rem; margin-bottom: 1rem; }
    .modal-body { overflow-y: auto; flex-grow: 1; }
    .close-modal-btn { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280; transition: color 0.2s; }
    .close-modal-btn:hover { color: #ef4444; }
    
    .btn-custom-outline { background: transparent; border: 1px solid rgba(255,255,255,0.4); color: #fff; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; transition: 0.2s; font-size: 0.9rem; display: flex; align-items: center; gap: 0.5rem; }
    .btn-custom-outline:hover { background: rgba(255,255,255,0.1); border-color: #fff; }
</style>

<div class="purchases-wrapper">
    <div class="card-custom" style="padding: 1rem 1.5rem; background: linear-gradient(to left, #1e293b, #0f172a); color: #fff; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h2 style="margin:0; font-size: 1.4rem; font-weight:700;">إدارة فواتير الشراء والتوريد</h2>
            <p style="margin:0.25rem 0 0 0; color: #94a3b8; font-size:0.9rem;">إضافة الأصناف، تحديث مخزون المنتجات، وحساب مستحقات الموردين بسهولة</p>
        </div>
        <button type="button" class="btn-custom-outline" onclick="document.getElementById('previousInvoicesModal').classList.add('active')">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M14 14V4.5L9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2zM9.5 3A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.5v2z"/><path d="M4.5 10a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5zm0-2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5zm0-2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5z"/></svg>
            فواتير الشراء السابقة
        </button>
    </div>

    <!-- بطاقات إحصائية سريعة -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="title">عدد المواد بالسلة</div>
            <div class="value"><?= count($_SESSION['purchase_cart']) ?> <span style="font-size: 0.9rem; font-weight: normal; color: #6b7280;">(إجمالي: <?= $cartItemsCount ?> قطعة)</span></div>
        </div>
        <div class="stat-card">
            <div class="title">إجمالي الفاتورة الحالية</div>
            <div class="value" style="color: #2563eb;"><?= format_money($pdo, $cartTotal) ?></div>
        </div>
        <div class="stat-card">
            <div class="title">رقم الفاتورة المتوقع</div>
            <div class="value" style="color: #059669;"><?= e(purchase_number($pdo)) ?></div>
        </div>
    </div>

    <!-- 1. نموذج إضافة صنف إلى السلة (مع دعم إضافة عدة صفوف ديناميكياً) -->
    <div class="card-custom">
        <div class="card-title">
            <span>إضافة أصناف إلى فاتورة الشراء</span>
            <small style="font-weight: normal; color: #6b7280; font-size: 0.85rem;">يمكنك إدخال منتج واحد أو النقر على "إضافة منتج آخر" لإدخال عدة منتجات معاً</small>
        </div>
        <form method="post">
            <input type="hidden" name="add_item" value="1">
            
            <div id="product_rows_container">
                <!-- الصف الأول الأساسي -->
                <div class="product-row-item">
                    <div class="form-grid-4">
                        <div class="form-group">
                            <label>اسم المنتج</label>
                            <input name="product_name[]" list="products_list" class="form-control-custom product-name-input" placeholder="ابحث أو أدخل المنتج..." required autocomplete="off" onchange="autoFillPrices(this)">
                        </div>

                        <div class="form-group">
                            <label>الكمية المشتراة</label>
                            <input type="number" name="quantity[]" min="1" value="1" class="form-control-custom" required>
                        </div>

                        <div class="form-group">
                            <label>سعر الشراء الفردي (التكلفة)</label>
                            <input type="number" step="0.01" name="unit_price[]" min="0" placeholder="0.00" class="form-control-custom unit-price-input" required>
                        </div>

                        <div class="form-group">
                            <label>سعر البيع المقترح</label>
                            <input type="number" step="0.01" name="sale_price[]" min="0" placeholder="0.00" class="form-control-custom sale-price-input">
                        </div>

                        <div class="form-group" style="display: flex; align-items: flex-end;">
                            <!-- زر الحذف يظهر للصفوف الإضافية فقط -->
                            <button type="button" class="remove-row-btn" style="visibility: hidden;" onclick="removeProductRow(this)">&times;</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- datalist للمنتجات -->
            <datalist id="products_list">
                <?php foreach ($existingProducts as $p): ?>
                    <option value="<?= e($p['name']) ?>" data-purchase="<?= e($p['purchase_price']) ?>" data-sale="<?= e($p['sale_price']) ?>">
                <?php endforeach; ?>
            </datalist>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem; flex-wrap: wrap; gap: 1rem;">
                <!-- زر إضافة منتج آخر -->
                <button type="button" class="btn btn-outline-secondary" onclick="addProductRow()" style="font-weight: 600; display: flex; align-items: center; gap: 0.5rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/></svg>
                    إضافة منتج آخر
                </button>

                <button type="submit" class="btn btn-primary" style="padding: 0.625rem 2rem; font-weight:600;">
                    + إدراج كافة الأصناف للقائمة
                </button>
            </div>
        </form>
    </div>

    <!-- 2. جدول أصناف فاتورة الشراء الحالية -->
    <div class="card-custom">
        <div class="card-title">
            <span>جدول الأصناف المضافة</span>
            <?php if (!empty($_SESSION['purchase_cart'])): ?>
                <form method="post" style="display:inline;" onsubmit="return confirm('هل أنت تأكد من تفريغ كافة الأصناف في السلة؟')">
                    <input type="hidden" name="clear_cart" value="1">
                    <button class="btn btn-outline-danger btn-sm" style="font-size:0.8rem;">تفريغ السلة</button>
                </form>
            <?php endif; ?>
        </div>

        <div style="overflow-x: auto;">
            <table class="table" style="width:100%; border-collapse: collapse;">
                <thead>
                    <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0; text-align: right;">
                        <th style="padding:0.75rem;">#</th>
                        <th style="padding:0.75rem;">اسم المنتج</th>
                        <th style="padding:0.75rem;">الكمية</th>
                        <th style="padding:0.75rem;">سعر الشراء الفردي</th>
                        <th style="padding:0.75rem;">التكلفة الإجمالية</th>
                        <th style="padding:0.75rem; text-align:center;">إجراءات</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($_SESSION['purchase_cart'])): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 2rem; color: #9ca3af;">
                            لا توجد أصناف مضافة في الفاتورة حتى الآن. استخدم النموذج أعلاه لإضافة المواد.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach($_SESSION['purchase_cart'] as $i => $item): ?>
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding:0.75rem;"><?= $i + 1 ?></td>
                            <td style="padding:0.75rem; font-weight:600; color:#1e293b;"><?= e($item['product_name']) ?></td>
                            <td style="padding:0.75rem;"><span class="badge-qty"><?= e($item['quantity']) ?></span></td>
                            <td style="padding:0.75rem;"><?= format_money($pdo, $item['unit_price']) ?></td>
                            <td style="padding:0.75rem; font-weight:700; color:#059669;"><?= format_money($pdo, $item['total_price']) ?></td>
                            <td style="padding:0.75rem; text-align:center;">
                                <form method="post" style="display:inline;" onsubmit="return confirm('حذف هذا الصنف من الفاتورة؟')">
                                    <input type="hidden" name="remove_item" value="1">
                                    <input type="hidden" name="item_index" value="<?= $i ?>">
                                    <button class="btn btn-danger btn-sm" style="padding:0.25rem 0.6rem; font-size:0.8rem;">حذف</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 3. تفاصيل الدفع وإتمام الفاتورة -->
    <div class="card-custom" style="border-top: 4px solid #2563eb;">
        <div class="card-title">إتمام وحفظ فاتورة الشراء</div>
        
        <form method="post">
            <input type="hidden" name="save_purchase_invoice" value="1">
            
            <div class="form-grid-4" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
                <div class="form-group">
                    <label>رقم فاتورة الشراء</label>
                    <input value="<?= e(purchase_number($pdo)) ?>" class="form-control-custom" style="background-color: #f3f4f6; font-weight:bold;" readonly>
                </div>

                <div class="form-group">
                    <label>اختر المورد <span style="color:#ef4444">*</span></label>
                    <select name="supplier_id" class="form-control-custom" required>
                        <option value="">-- اختر المورد --</option>
                        <?php foreach($suppliers as $s): ?>
                            <option value="<?= e($s['id']) ?>">
                                <?= e($s['name']) ?> (الرصيد الحالي: <?= format_money($pdo, $s['balance']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>إجمالي التكلفة الكلي</label>
                    <input id="purchase_total_raw" type="hidden" value="<?= $cartTotal ?>">
                    <input id="purchase_total_display" value="<?= format_money($pdo, $cartTotal) ?>" class="form-control-custom" style="background-color: #f3f4f6; font-weight:bold; color:#1d4ed8;" readonly>
                </div>

                <div class="form-group">
                    <label>المبلغ المدفوع كاش <span style="color:#ef4444">*</span></label>
                    <input type="number" step="0.01" min="0" name="paid_amount" id="purchase_paid" value="0" class="form-control-custom" oninput="calcPurchaseRemaining()" required>
                </div>

                <div class="form-group">
                    <label>المبلغ المتبقي (دين للمورد)</label>
                    <input type="text" id="purchase_remaining_display" value="<?= format_money($pdo, $cartTotal) ?>" class="form-control-custom" style="background-color: #fef2f2; font-weight:bold; color:#dc2626;" readonly>
                </div>
            </div>

            <div class="form-group" style="margin-top: 1rem;">
                <label>ملاحظات أو تفاصيل إضافية</label>
                <textarea name="notes" class="form-control-custom" rows="2" placeholder="أدخل أي ملاحظات تخص الفاتورة أو طريقة الشحن والتسليم..."></textarea>
            </div>

            <div style="margin-top: 1.5rem; text-align: left;">
                <button type="submit" class="btn btn-success" style="padding: 0.75rem 2rem; font-size:1rem; font-weight:bold; cursor:pointer;" <?= empty($_SESSION['purchase_cart']) ? 'disabled' : '' ?>>
                    ✓ حفظ وإعتماد فاتورة الشراء
                </button>
            </div>
        </form>
    </div>
</div>

<!-- نافذة فواتير الشراء السابقة المنبثقة (Modal) -->
<div id="previousInvoicesModal" class="modal-overlay" onclick="closeModalOutside(event)">
    <div class="modal-container">
        <div class="modal-header">
            <h3 style="margin: 0; font-size: 1.25rem; font-weight: 700; color: #1f2937;">سجل فواتير الشراء المنفذة</h3>
            <button type="button" class="close-modal-btn" onclick="document.getElementById('previousInvoicesModal').classList.remove('active')">&times;</button>
        </div>
        <div class="modal-body">
            <div style="overflow-x: auto;">
                <table class="table" style="width:100%; border-collapse: collapse; min-width: 800px;">
                    <thead>
                        <tr style="background-color: #f3f4f6; text-align: right; border-bottom: 2px solid #d1d5db;">
                            <th style="padding: 0.85rem;">رقم الفاتورة</th>
                            <th style="padding: 0.85rem;">المورد</th>
                            <th style="padding: 0.85rem;">الإجمالي</th>
                            <th style="padding: 0.85rem;">المدفوع</th>
                            <th style="padding: 0.85rem;">المتبقي</th>
                            <th style="padding: 0.85rem;">تاريخ الفاتورة</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($previousInvoices)): ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 2rem; color: #6b7280;">لا توجد فواتير شراء سابقة مسجلة في النظام.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($previousInvoices as $inv): ?>
                                <tr style="border-bottom: 1px solid #e5e7eb; transition: background-color 0.2s;">
                                    <td style="padding: 0.85rem; font-weight: bold; color: #374151;"><?= e($inv['purchase_number']) ?></td>
                                    <td style="padding: 0.85rem; font-weight: 600;"><?= e($inv['supplier_name'] ?? 'مورد غير معروف') ?></td>
                                    <td style="padding: 0.85rem; color: #2563eb; font-weight: bold;"><?= format_money($pdo, $inv['total_amount']) ?></td>
                                    <td style="padding: 0.85rem; color: #059669;"><?= format_money($pdo, $inv['paid_amount']) ?></td>
                                    <td style="padding: 0.85rem; color: #dc2626;"><?= format_money($pdo, $inv['remaining_amount']) ?></td>
                                    <td style="padding: 0.85rem; color: #6b7280; font-size: 0.9rem;"><?= date('Y-m-d h:i A', strtotime($inv['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- 4. جافاسكريبت للتفاعل الحي وتعبئة الأسعار تلقائياً وديناميكية الصفوف -->
<script>
// دالة لإضافة صف جديد لإدخال منتج آخر
function addProductRow() {
    const container = document.getElementById('product_rows_container');
    const firstRow = container.querySelector('.product-row-item');
    const newRow = firstRow.cloneNode(true);
    
    // تفريغ القيم في الصف الجديد
    newRow.querySelectorAll('input').forEach(input => {
        input.value = input.name.includes('quantity[]') ? '1' : '';
    });
    
    // إظهار زر الحذف للصفوف المضافة حديثاً
    const removeBtn = newRow.querySelector('.remove-row-btn');
    if (removeBtn) {
        removeBtn.style.visibility = 'visible';
    }
    
    container.appendChild(newRow);
}

// دالة لحذف صف منتج إضافي
function removeProductRow(btn) {
    const row = btn.closest('.product-row-item');
    const container = document.getElementById('product_rows_container');
    if (container.querySelectorAll('.product-row-item').length > 1) {
        row.remove();
    }
}

// التعبئة التلقائية للأسعار بناءً على اسم المنتج المختار من القائمة
function autoFillPrices(element) {
    const row = element.closest('.product-row-item');
    const val = element.value;
    const datalist = document.getElementById('products_list');
    const options = datalist.options;
    
    for (let i = 0; i < options.length; i++) {
        if (options[i].value === val) {
            const purchasePrice = options[i].getAttribute('data-purchase');
            const salePrice = options[i].getAttribute('data-sale');
            
            if (purchasePrice) {
                row.querySelector('.unit-price-input').value = parseFloat(purchasePrice).toFixed(2);
            }
            if (salePrice) {
                row.querySelector('.sale-price-input').value = parseFloat(salePrice).toFixed(2);
            }
            break;
        }
    }
}

function calcPurchaseRemaining() {
    const total = parseFloat(document.getElementById('purchase_total_raw').value || 0);
    let paid = parseFloat(document.getElementById('purchase_paid').value || 0);
    
    if (isNaN(paid) || paid < 0) paid = 0;
    
    const remaining = Math.max(total - paid, 0);
    const currency = ' <?= addslashes($currencySymbol) ?>';
    
    document.getElementById('purchase_remaining_display').value = remaining.toFixed(2) + currency;
}

// إغلاق النافذة المنبثقة عند النقر خارجها
function closeModalOutside(event) {
    const modal = document.getElementById('previousInvoicesModal');
    if (event.target === modal) {
        modal.classList.remove('active');
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>