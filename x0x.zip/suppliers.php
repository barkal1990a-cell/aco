<?php
require_once 'config/database.php';
require_once 'includes/header.php';

// ---------------------------------------------------------------------
// 1. معالجة طلبات POST (إضافة، تعديل، حذف)
// ---------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // أ) إضافة مورد جديد
    if (isset($_POST['add_supplier'])) {
        $name    = trim($_POST['name'] ?? '');
        $phone   = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $notes   = trim($_POST['notes'] ?? '');

        if ($name === '') {
            set_flash('error', 'يرجى إدخال اسم المورد على الأقل');
        } else {
            $stmt = $pdo->prepare("INSERT INTO suppliers (name, phone, address, notes, balance) VALUES (?, ?, ?, ?, 0.00)");
            $stmt->execute([$name, $phone, $address, $notes]);
            set_flash('success', 'تمت إضافة المورد بنجاح');
        }
        redirect('suppliers.php');
    }

    // ب) تعديل بيانات مورد
    if (isset($_POST['update_supplier'])) {
        $id      = (int)($_POST['supplier_id'] ?? 0);
        $name    = trim($_POST['name'] ?? '');
        $phone   = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $notes   = trim($_POST['notes'] ?? '');

        if ($id <= 0 || $name === '') {
            set_flash('error', 'بيانات المورد غير مكتملة');
        } else {
            $stmt = $pdo->prepare("UPDATE suppliers SET name = ?, phone = ?, address = ?, notes = ? WHERE id = ?");
            $stmt->execute([$name, $phone, $address, $notes, $id]);
            set_flash('success', 'تم تعديل بيانات المورد بنجاح');
        }
        redirect('suppliers.php');
    }

    // ج) حذف مورد (مع التحقق من عدم وجود فواتير مرتبطة)
    if (isset($_POST['delete_supplier'])) {
        $supplierId = (int)($_POST['supplier_id'] ?? 0);

        $checkInvoices = $pdo->prepare("SELECT COUNT(*) FROM purchase_invoices WHERE supplier_id = ?");
        $checkInvoices->execute([$supplierId]);

        if ($checkInvoices->fetchColumn() > 0) {
            set_flash('error', 'لا يمكن حذف المورد لوجود فواتير شراء مرتبطة به في النظام');
        } else {
            $pdo->prepare("DELETE FROM suppliers WHERE id = ?")->execute([$supplierId]);
            set_flash('warning', 'تم حذف المورد بنجاح');
        }
        redirect('suppliers.php');
    }
}

// ---------------------------------------------------------------------
// 2. جلب مورد للتعديل (إن وجد)
// ---------------------------------------------------------------------
$editSupplier = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM suppliers WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editSupplier = $stmt->fetch(PDO::FETCH_ASSOC);
}

// ---------------------------------------------------------------------
// 3. جلب قائمة الموردين وحساب الإحصائيات
// ---------------------------------------------------------------------
$rows = $pdo->query("SELECT * FROM suppliers ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

$totalSuppliers   = count($rows);
$totalOwed        = 0; // ديون علينا للموردين (balance > 0)
$totalCredit      = 0; // مبالغ لنا عند الموردين (balance < 0)
$creditorsCount   = 0; // عدد الموردين المستحقين لمبالغ
$debtorsCount     = 0; // عدد الموردين الذين نملك عندهم مبالغ زائدة

foreach ($rows as $s) {
    $bal = (float)($s['balance'] ?? 0);
    if ($bal > 0) {
        $totalOwed += $bal;
        $creditorsCount++;
    } elseif ($bal < 0) {
        $totalCredit += abs($bal);
        $debtorsCount++;
    }
}
?>

<!-- تنسيقات العرض الحديثة -->
<style>
    .suppliers-wrapper { display: flex; flex-direction: column; gap: 1.5rem; }
    .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; }
    .stat-card { background: #ffffff; padding: 1.25rem; border-radius: 12px; border: 1px solid #e5e7eb; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
    .stat-card .title { font-size: 0.875rem; color: #6b7280; font-weight: 600; margin-bottom: 0.25rem; }
    .stat-card .value { font-size: 1.4rem; font-weight: 700; color: #111827; }
    
    .card-custom { background: #ffffff; border-radius: 12px; border: 1px solid #e5e7eb; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.03); }
    .card-title { font-size: 1.15rem; font-weight: 700; color: #1f2937; margin-bottom: 1.25rem; display: flex; align-items: center; justify-content: space-between; }
    
    .form-grid-4 { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; align-items: end; }
    .form-group label { display: block; font-size: 0.875rem; font-weight: 600; color: #374151; margin-bottom: 0.35rem; }
    .form-control-custom { width: 100%; padding: 0.625rem 0.85rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.95rem; transition: border-color 0.2s, box-shadow 0.2s; outline: none; }
    .form-control-custom:focus { border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,0.1); }
    
    .badge-balance-zero { background-color: #f1f5f9; color: #475569; padding: 0.25rem 0.65rem; border-radius: 9999px; font-weight: 700; font-size: 0.85rem; display: inline-block; }
    .badge-balance-owed { background-color: #fef3c7; color: #92400e; padding: 0.25rem 0.65rem; border-radius: 9999px; font-weight: 700; font-size: 0.85rem; display: inline-block; }
    .badge-balance-credit { background-color: #dbeafe; color: #1e40af; padding: 0.25rem 0.65rem; border-radius: 9999px; font-weight: 700; font-size: 0.85rem; display: inline-block; }
    
    .contact-actions { display: flex; gap: 0.35rem; align-items: center; }
    .contact-btn { padding: 0.25rem 0.5rem; border-radius: 6px; font-size: 0.8rem; text-decoration: none; font-weight: 600; display: inline-flex; align-items: center; gap: 0.2rem; }
    .btn-whatsapp { background-color: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
    .btn-whatsapp:hover { background-color: #bbf7d0; }
    .btn-call { background-color: #f1f5f9; color: #334155; border: 1px solid #e2e8f0; }
    .btn-call:hover { background-color: #e2e8f0; }
</style>

<div class="suppliers-wrapper">
    <!-- ترويسة الصفحة -->
    <div class="card-custom" style="padding: 1rem 1.5rem; background: linear-gradient(to left, #0f172a, #1e293b); color: #fff;">
        <h2 style="margin:0; font-size: 1.4rem; font-weight:700;">دليل الموردين والحسابات</h2>
        <p style="margin:0.25rem 0 0 0; color: #94a3b8; font-size:0.9rem;">إدارة بيانات الموردين، متابعة الديون والمستحقات والمدفوعات الزائدة</p>
    </div>

    <!-- البطاقات الإحصائية -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="title">إجمالي الموردين</div>
            <div class="value"><?= $totalSuppliers ?> <span style="font-size:0.85rem; color:#6b7280; font-weight:normal;">مورد</span></div>
        </div>
        <div class="stat-card">
            <div class="title">موردون لهم مبالغ لدينا</div>
            <div class="value" style="color: #d97706;"><?= $creditorsCount ?> <span style="font-size:0.85rem; color:#6b7280; font-weight:normal;">مورد</span></div>
        </div>
        <div class="stat-card">
            <div class="title">إجمالي مستحقات الموردين (ديون عليك)</div>
            <div class="value" style="color: #dc2626;"><?= format_money($pdo, $totalOwed) ?></div>
        </div>
        <div class="stat-card">
            <div class="title">إجمالي مبالغ مدفوعة زيادة (لنا عندهم)</div>
            <div class="value" style="color: #2563eb;"><?= format_money($pdo, $totalCredit) ?></div>
        </div>
    </div>

    <!-- 1. نموذج الإضافة / التعديل -->
    <div class="card-custom" style="<?= $editSupplier ? 'border-top: 4px solid #f59e0b;' : 'border-top: 4px solid #2563eb;' ?>">
        <div class="card-title">
            <span><?= $editSupplier ? 'تعديل بيانات المورد: (' . e($editSupplier['name']) . ')' : 'إضافة مورد جديد' ?></span>
            <?php if ($editSupplier): ?>
                <a href="suppliers.php" class="btn btn-outline-secondary btn-sm" style="font-size:0.85rem; text-decoration:none;">✕ إلغاء التعديل</a>
            <?php endif; ?>
        </div>

        <form method="post" class="form-grid-4">
            <input type="hidden" name="<?= $editSupplier ? 'update_supplier' : 'add_supplier' ?>" value="1">
            <?php if ($editSupplier): ?>
                <input type="hidden" name="supplier_id" value="<?= e($editSupplier['id']) ?>">
            <?php endif; ?>

            <div class="form-group">
                <label>اسم المورد / الشركة <span style="color:#ef4444">*</span></label>
                <input name="name" class="form-control-custom" placeholder="مثال: شركة البركة للتجارة" required value="<?= e($editSupplier['name'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>رقم الهاتف</label>
                <input name="phone" class="form-control-custom" placeholder="09xxxxxxxx" value="<?= e($editSupplier['phone'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>العنوان / المكان</label>
                <input name="address" class="form-control-custom" placeholder="مثال: دمشق - حوش بلاس" value="<?= e($editSupplier['address'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>ملاحظات إضافية</label>
                <input name="notes" class="form-control-custom" placeholder="نوع البضائع أو طريقة الدفع..." value="<?= e($editSupplier['notes'] ?? '') ?>">
            </div>

            <div class="form-group" style="grid-column: 1 / -1; display: flex; justify-content: flex-end; gap: 0.5rem; margin-top: 0.5rem;">
                <button type="submit" class="btn <?= $editSupplier ? 'btn-warning' : 'btn-primary' ?>" style="padding: 0.625rem 1.75rem; font-weight:600;">
                    <?= $editSupplier ? 'حفظ التعديلات' : '+ إضافة المورد' ?>
                </button>
            </div>
        </form>
    </div>

    <!-- 2. جدول الموردين والتصفية -->
    <div class="card-custom">
        <div class="card-title">
            <span>قائمة الموردين المسجلين</span>
            <!-- مربع بحث فوري -->
            <div style="width: 260px;">
                <input type="text" id="supplierSearchInput" onkeyup="filterSuppliers()" class="form-control-custom" placeholder="🔍 بحث عن مورد أو هاتف..." style="font-size:0.85rem; padding: 0.4rem 0.75rem;">
            </div>
        </div>

        <div style="overflow-x: auto;">
            <table class="table" id="suppliersTable" style="width:100%; border-collapse: collapse;">
                <thead>
                    <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0; text-align: right;">
                        <th style="padding:0.75rem;">#</th>
                        <th style="padding:0.75rem;">الاسم</th>
                        <th style="padding:0.75rem;">الهاتف / التواصل</th>
                        <th style="padding:0.75rem;">العنوان</th>
                        <th style="padding:0.75rem;">مستحقات المورد (الذمة)</th>
                        <th style="padding:0.75rem;">ملاحظات</th>
                        <th style="padding:0.75rem; text-align:center;">إجراءات</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 2rem; color: #9ca3af;">
                            لا يوجد موردون مسجلون حتى الآن.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach($rows as $r): ?>
                        <?php $supplierBalance = (float)($r['balance'] ?? 0); ?>
                        <tr class="supplier-row" style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding:0.75rem; color:#6b7280;"><?= e($r['id']) ?></td>
                            <td style="padding:0.75rem; font-weight:700; color:#1e293b;" class="search-name">
                                <?= e($r['name']) ?>
                            </td>
                            <td style="padding:0.75rem;" class="search-phone">
                                <?php if (!empty($r['phone'])): ?>
                                    <?php $cleanPhone = preg_replace('/[^0-9+]/', '', $r['phone']); ?>
                                    <div class="contact-actions">
                                        <span><?= e($r['phone']) ?></span>
                                        <a href="https://wa.me/<?= $cleanPhone ?>" target="_blank" class="contact-btn btn-whatsapp" title="محادثة واتساب">واتساب</a>
                                        <a href="tel:<?= $cleanPhone ?>" class="contact-btn btn-call" title="اتصال">اتصال</a>
                                    </div>
                                <?php else: ?>
                                    <span style="color:#9ca3af; font-size:0.85rem;">غ/م</span>
                                <?php endif; ?>
                            </td>
                            <td style="padding:0.75rem; color:#4b5563;" class="search-address">
                                <?= !empty($r['address']) ? e($r['address']) : '<span style="color:#9ca3af; font-size:0.85rem;">غ/م</span>' ?>
                            </td>
                            <td style="padding:0.75rem;">
                                <?php if ($supplierBalance > 0): ?>
                                    <span class="badge-balance-owed" title="مبلغ مستحق للمورد بدمتك">
                                        له علينا: <?= format_money($pdo, $supplierBalance) ?>
                                    </span>
                                <?php elseif ($supplierBalance < 0): ?>
                                    <span class="badge-balance-credit" title="مدفوعات زائدة لصالحك لدى المورد">
                                        لنا عليه: <?= format_money($pdo, abs($supplierBalance)) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="badge-balance-zero">
                                        خالي الذمة (0.00)
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td style="padding:0.75rem; color:#6b7280; font-size:0.9rem;" class="search-notes">
                                <?= !empty($r['notes']) ? e($r['notes']) : '-' ?>
                            </td>
                            <td style="padding:0.75rem; text-align:center;">
                                <div style="display:flex; gap:0.4rem; justify-content:center;">
                                    <a class="btn btn-warning btn-sm" href="suppliers.php?edit=<?= e($r['id']) ?>" style="padding:0.25rem 0.6rem; font-size:0.8rem; text-decoration:none;">تعديل</a>
                                    
                                    <form method="post" style="display:inline;" onsubmit="return confirm('هل أنت تأكد من حذف المورد: (<?= e($r['name']) ?>)؟')">
                                        <input type="hidden" name="delete_supplier" value="1">
                                        <input type="hidden" name="supplier_id" value="<?= e($r['id']) ?>">
                                        <button class="btn btn-danger btn-sm" style="padding:0.25rem 0.6rem; font-size:0.8rem;">حذف</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- جافاسكريبت للبحث المباشر والتصفية -->
<script>
function filterSuppliers() {
    const input = document.getElementById("supplierSearchInput");
    const filter = input.value.toLowerCase().trim();
    const rows = document.getElementsByClassName("supplier-row");

    for (let i = 0; i < rows.length; i++) {
        const nameCell = rows[i].querySelector(".search-name");
        const phoneCell = rows[i].querySelector(".search-phone");
        const addressCell = rows[i].querySelector(".search-address");
        const notesCell = rows[i].querySelector(".search-notes");

        const nameText = nameCell ? nameCell.textContent.toLowerCase() : "";
        const phoneText = phoneCell ? phoneCell.textContent.toLowerCase() : "";
        const addressText = addressCell ? addressCell.textContent.toLowerCase() : "";
        const notesText = notesCell ? notesCell.textContent.toLowerCase() : "";

        if (nameText.includes(filter) || phoneText.includes(filter) || addressText.includes(filter) || notesText.includes(filter)) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>