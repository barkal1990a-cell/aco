<?php
require_once 'config/database.php';
require_once 'includes/header.php';

// حذف فاتورة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_invoice'])) {
    $invoiceId = (int)$_POST['invoice_id'];
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM invoices WHERE id=?");
        $stmt->execute([$invoiceId]);
        $invoice = $stmt->fetch();

        $itemsStmt = $pdo->prepare("SELECT * FROM invoice_items WHERE invoice_id=?");
        $itemsStmt->execute([$invoiceId]);
        $items = $itemsStmt->fetchAll();

        foreach ($items as $item) {
            if ($item['product_id']) {
                $pdo->prepare("UPDATE products SET quantity = quantity + ? WHERE id=?")
                    ->execute([$item['quantity'], $item['product_id']]);
            }
        }

        if ($invoice && $invoice['customer_id'] && $invoice['remaining_amount'] > 0) {
            $pdo->prepare("UPDATE customers SET balance = GREATEST(balance - ?, 0) WHERE id=?")
                ->execute([$invoice['remaining_amount'], $invoice['customer_id']]);
        }

        $pdo->prepare("DELETE FROM cashbox WHERE reference_id=? AND description='قبض من فاتورة بيع'")
            ->execute([$invoiceId]);
        $pdo->prepare("DELETE FROM invoices WHERE id=?")->execute([$invoiceId]);
        
        $pdo->commit();
        set_flash('warning', 'تم حذف الفاتورة وإرجاع الكميات للمخزن بنجاح');
    } catch (Throwable $e) {
        $pdo->rollBack();
        set_flash('error', 'فشل حذف الفاتورة: ' . $e->getMessage());
    }
    redirect('invoice_history.php');
}

// تعديل فاتورة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_invoice'])) {
    $invoiceId = (int)$_POST['invoice_id'];
    $newCustomerId = !empty($_POST['customer_id']) ? (int)$_POST['customer_id'] : null;
    $newPaid = (float)$_POST['paid_amount'];
    $newNotes = trim($_POST['notes'] ?? '');

    $stmt = $pdo->prepare("SELECT * FROM invoices WHERE id=?");
    $stmt->execute([$invoiceId]);
    $invoice = $stmt->fetch();

    if ($invoice) {
        $total = (float)$invoice['total_amount'];
        $oldRemaining = (float)$invoice['remaining_amount'];
        $oldCustomerId = $invoice['customer_id'] ? (int)$invoice['customer_id'] : null;
        $newRemaining = max($total - $newPaid, 0);

        $pdo->beginTransaction();
        try {
            if ($oldCustomerId && $oldRemaining > 0) {
                $pdo->prepare("UPDATE customers SET balance = GREATEST(balance - ?, 0) WHERE id=?")
                    ->execute([$oldRemaining, $oldCustomerId]);
            }
            if ($newCustomerId && $newRemaining > 0) {
                $pdo->prepare("UPDATE customers SET balance = balance + ? WHERE id=?")
                    ->execute([$newRemaining, $newCustomerId]);
            }

            $pdo->prepare("UPDATE invoices SET customer_id=?, paid_amount=?, remaining_amount=?, notes=? WHERE id=?")
                ->execute([$newCustomerId, $newPaid, $newRemaining, $newNotes, $invoiceId]);

            $pdo->prepare("DELETE FROM cashbox WHERE reference_id=? AND description='قبض من فاتورة بيع'")
                ->execute([$invoiceId]);
            
            if ($newPaid > 0) {
                $pdo->prepare("INSERT INTO cashbox(type, reference_id, amount, description) VALUES('in', ?, ?, ?)")
                    ->execute([$invoiceId, $newPaid, 'قبض من فاتورة بيع']);
            }

            $pdo->commit();
            set_flash('success', 'تم تعديل الفاتورة بنجاح');
        } catch (Throwable $e) {
            $pdo->rollBack();
            set_flash('error', 'فشل تعديل الفاتورة: ' . $e->getMessage());
        }
    }
    redirect('invoice_history.php');
}

$customers = $pdo->query("SELECT * FROM customers ORDER BY name ASC")->fetchAll();

$editInvoice = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM invoices WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editInvoice = $stmt->fetch();
}

// بناء استعلام الفلترة
$conditions = [];
$params = [];
if (!empty($_GET['year'])) { $conditions[] = 'YEAR(invoices.created_at)=?'; $params[] = (int)$_GET['year']; }
if (!empty($_GET['month'])) { $conditions[] = 'MONTH(invoices.created_at)=?'; $params[] = (int)$_GET['month']; }
if (!empty($_GET['date'])) { $conditions[] = 'DATE(invoices.created_at)=?'; $params[] = $_GET['date']; }
if (!empty($_GET['invoice_number'])) { $conditions[] = 'invoices.invoice_number LIKE ?'; $params[] = '%' . trim($_GET['invoice_number']) . '%'; }
if (!empty($_GET['customer_name'])) { $conditions[] = 'customers.name LIKE ?'; $params[] = '%' . trim($_GET['customer_name']) . '%'; }
$where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';

$sql = "SELECT invoices.*, customers.name AS customer_name 
        FROM invoices 
        LEFT JOIN customers ON customers.id=invoices.customer_id 
        $where 
        ORDER BY invoices.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$invoices = $stmt->fetchAll();

// إحصائيات سريعة للنتيجة الحالية
$sumTotal = array_sum(array_column($invoices, 'total_amount'));
$sumPaid = array_sum(array_column($invoices, 'paid_amount'));
$sumRemaining = array_sum(array_column($invoices, 'remaining_amount'));
?>

<style>
/* Modern Invoice History Custom Styles */
:root {
    --history-primary: #2563eb;
    --history-success: #10b981;
    --history-warning: #f59e0b;
    --history-danger: #ef4444;
    --history-border: #e2e8f0;
}

.history-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.history-title {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    margin: 0;
}

/* KPI Summary Cards Grid */
.kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
}

.kpi-card {
    background: #ffffff;
    border: 1px solid var(--history-border);
    border-radius: 12px;
    padding: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
}

.kpi-card small {
    font-size: 12px;
    color: #64748b;
    font-weight: 600;
    display: block;
    margin-bottom: 6px;
}

.kpi-card strong {
    font-size: 18px;
    font-weight: 800;
    color: #0f172a;
}

/* Section Cards */
.history-card {
    background: #ffffff;
    border: 1px solid var(--history-border);
    border-radius: 14px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

.history-card-title {
    font-size: 16px;
    font-weight: 700;
    color: #1e293b;
    margin: 0 0 16px 0;
}

/* Filter Form Grid */
.filter-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 12px;
    align-items: end;
}

.filter-grid input, .filter-grid select {
    width: 100%;
    padding: 9px 12px;
    border: 1px solid var(--history-border);
    border-radius: 8px;
    font-size: 13px;
    outline: none;
    box-sizing: border-box;
}

.filter-grid input:focus, .filter-grid select:focus {
    border-color: var(--history-primary);
}

/* Table Styling */
.table-responsive {
    overflow-x: auto;
}

.history-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
}

.history-table th {
    background: #f8fafc;
    color: #475569;
    font-size: 12px;
    font-weight: 700;
    padding: 12px;
    border-bottom: 2px solid var(--history-border);
    text-align: right;
}

.history-table td {
    padding: 12px;
    border-bottom: 1px solid var(--history-border);
    font-size: 13px;
    color: #1e293b;
    vertical-align: middle;
}

.history-table tbody tr:hover {
    background-color: #f8fafc;
}

/* Badges */
.status-badge {
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    display: inline-block;
}

.badge-paid { background: #dcfce7; color: #15803d; }
.badge-partial { background: #fef3c7; color: #b45309; }
.badge-unpaid { background: #fee2e2; color: #b91c1c; }

/* Action Buttons Group */
.action-btns {
    display: flex;
    gap: 6px;
    align-items: center;
}

.action-btns .btn {
    padding: 5px 10px;
    font-size: 11px;
    border-radius: 6px;
    font-weight: 600;
}
</style>

<div class="history-header">
    <h1 class="history-title">سجل الفواتير والمبيعات</h1>
</div>

<!-- كروت إحصائية ملخصة -->
<div class="kpi-grid">
    <div class="kpi-card" style="border-right: 4px solid var(--history-primary);">
        <small>عدد الفواتير</small>
        <strong><?= count($invoices) ?> فاتورة</strong>
    </div>
    <div class="kpi-card" style="border-right: 4px solid #3b82f6;">
        <small>إجمالي المبيعات</small>
        <strong style="color:#1d4ed8;"><?= format_money($pdo, $sumTotal) ?></strong>
    </div>
    <div class="kpi-card" style="border-right: 4px solid var(--history-success);">
        <small>المقبوضات (النقدي)</small>
        <strong style="color:#15803d;"><?= format_money($pdo, $sumPaid) ?></strong>
    </div>
    <div class="kpi-card" style="border-right: 4px solid var(--history-danger);">
        <small>الديون المتبقية</small>
        <strong style="color:#b91c1c;"><?= format_money($pdo, $sumRemaining) ?></strong>
    </div>
</div>

<!-- استمارة الفلترة والبحث -->
<div class="history-card">
    <h3 class="history-card-title">🔍 خيارات البحث والتصفية</h3>
    <form method="get" class="filter-grid">
        <div class="form-group">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">السنة</label>
            <input type="number" name="year" placeholder="مثال: 2026" value="<?= e($_GET['year'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">الشهر</label>
            <input type="number" min="1" max="12" name="month" placeholder="1 - 12" value="<?= e($_GET['month'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">التاريخ الدقيق</label>
            <input type="date" name="date" value="<?= e($_GET['date'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">رقم الفاتورة</label>
            <input type="text" name="invoice_number" placeholder="بحث برقم الفاتورة..." value="<?= e($_GET['invoice_number'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">اسم الزبون</label>
            <input type="text" name="customer_name" placeholder="بحث باسم الزبون..." value="<?= e($_GET['customer_name'] ?? '') ?>">
        </div>
        <div class="form-group" style="display:flex; gap:6px;">
            <button class="btn btn-primary" style="flex:1; padding:9px;">تطبيق الفلترة</button>
            <?php if(!empty($_GET)): ?>
                <a href="invoice_history.php" class="btn btn-secondary" style="padding:9px;" title="إلغاء الفلاتر">إعادة ضبط</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- نافذة تعديل الفاتورة المحددة -->
<?php if ($editInvoice): ?>
<div class="history-card" style="border:2px solid var(--history-warning); background:#fffdf5;">
    <h3 class="history-card-title" style="color:#b45309;">✏️ تعديل الفاتورة رقم: <?= e($editInvoice['invoice_number']) ?></h3>
    <form method="post" class="filter-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
        <input type="hidden" name="update_invoice" value="1">
        <input type="hidden" name="invoice_id" value="<?= e($editInvoice['id']) ?>">
        
        <div class="form-group">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">الزبون</label>
            <select name="customer_id">
                <option value="">نقدي / بدون زبون</option>
                <?php foreach($customers as $c): ?>
                    <option value="<?= e($c['id']) ?>" <?= ($editInvoice['customer_id']==$c['id'])?'selected':'' ?>><?= e($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">إجمالي الفاتورة</label>
            <input id="edit_total" value="<?= e($editInvoice['total_amount']) ?>" readonly style="background:#f1f5f9; font-weight:700;">
        </div>

        <div class="form-group">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">المبلغ المدفوع</label>
            <input type="number" step="0.01" id="edit_paid" name="paid_amount" value="<?= e($editInvoice['paid_amount']) ?>" oninput="calcEditRemaining()" required style="font-weight:700;">
        </div>

        <div class="form-group">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">المتبقي الحسابي</label>
            <input type="text" id="edit_remaining" value="<?= format_money($pdo, $editInvoice['remaining_amount']) ?>" readonly style="background:#fff1f1; color:#dc2626; font-weight:700;">
        </div>

        <div class="form-group" style="grid-column: 1 / -1;">
            <label style="font-size:12px; font-weight:600; display:block; margin-bottom:4px;">ملاحظات الفاتورة</label>
            <textarea name="notes" rows="2" style="width:100%; border:1px solid var(--history-border); border-radius:8px; padding:8px; box-sizing:border-box;"><?= e($editInvoice['notes']) ?></textarea>
        </div>

        <div class="form-group" style="grid-column: 1 / -1; display:flex; gap:10px; margin-top:5px;">
            <button class="btn btn-success" style="padding:9px 20px; font-weight:700;">حفظ التعديلات</button>
            <a class="btn btn-secondary" href="invoice_history.php">إلغاء التعديل</a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- جدول عرض الفواتير -->
<div class="history-card">
    <div class="table-responsive">
        <table class="history-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>رقم الفاتورة</th>
                    <th>اسم الزبون</th>
                    <th>التاريخ</th>
                    <th>الإجمالي</th>
                    <th>المدفوع</th>
                    <th>المتبقي</th>
                    <th>حالة الدفع</th>
                    <th style="text-align:center;">الإجراءات</th>
                </tr>
            </thead>
            <tbody>
            <?php if(empty($invoices)): ?>
                <tr>
                    <td colspan="9" style="text-align:center; padding:30px; color:#94a3b8;">لا توجد فواتير مطابقة لخيارات البحث.</td>
                </tr>
            <?php endif; ?>

            <?php foreach($invoices as $row): ?>
                <tr>
                    <td><strong>#<?= e($row['id']) ?></strong></td>
                    <td style="font-weight:700; color:#2563eb;"><?= e($row['invoice_number']) ?></td>
                    <td><?= e($row['customer_name'] ?? 'نقدي') ?></td>
                    <td style="color:#64748b; font-size:12px;"><?= date('Y-m-d H:i', strtotime($row['created_at'])) ?></td>
                    <td style="font-weight:700;"><?= format_money($pdo, $row['total_amount']) ?></td>
                    <td style="color:#059669; font-weight:600;"><?= format_money($pdo, $row['paid_amount']) ?></td>
                    <td style="color:<?= $row['remaining_amount'] > 0 ? '#dc2626' : '#64748b' ?>; font-weight:700;">
                        <?= format_money($pdo, $row['remaining_amount']) ?>
                    </td>
                    <td>
                        <?php if($row['remaining_amount'] <= 0): ?>
                            <span class="status-badge badge-paid">مدفوعة بالكامل</span>
                        <?php elseif($row['paid_amount'] > 0): ?>
                            <span class="status-badge badge-partial">دفعة جزئية</span>
                        <?php else: ?>
                            <span class="status-badge badge-unpaid">غير مدفوعة (آجل)</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="action-btns" style="justify-content:center;">
                            <a class="btn btn-primary" target="_blank" href="invoice_print.php?id=<?= e($row['id']) ?>" title="عرض وطباعة">طباعة</a>
                            <a class="btn btn-warning" href="invoice_history.php?edit=<?= e($row['id']) ?>" title="تعديل">تعديل</a>
                            
                            <form method="post" onsubmit="return confirm('هل أنت تأكد من حذف الفاتورة؟ سيتم إعادة كافة الكميات إلى المخزن وتعديل رصيد الزبون.')" style="margin:0;">
                                <input type="hidden" name="delete_invoice" value="1">
                                <input type="hidden" name="invoice_id" value="<?= e($row['id']) ?>">
                                <button class="btn btn-danger" title="حذف">حذف</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
// إعادة حساب المتبقي تلقائياً أثناء التعديل
function calcEditRemaining() {
    const total = parseFloat(document.getElementById('edit_total').value || 0);
    const paid = parseFloat(document.getElementById('edit_paid').value || 0);
    const currency = ' <?= addslashes(app_setting($pdo, 'currency', 'ل.س')) ?>';
    
    const remaining = Math.max(total - paid, 0);
    document.getElementById('edit_remaining').value = remaining.toFixed(2) + currency;
}
</script>

<?php require_once 'includes/footer.php'; ?>