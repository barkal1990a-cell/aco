<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_login();

date_default_timezone_set('Asia/Damascus');
$products = $pdo->query("SELECT * FROM products ORDER BY name ASC")->fetchAll();
$totalCost = 0;
$totalSale = 0;
foreach ($products as $product) {
    $totalCost += ((float)$product['purchase_price'] * (int)$product['quantity']);
    $totalSale += ((float)$product['sale_price'] * (int)$product['quantity']);
}
$expectedProfit = $totalSale - $totalCost;
$reportDate = date('Y-m-d');
$reportDay = ['Sunday'=>'الأحد','Monday'=>'الاثنين','Tuesday'=>'الثلاثاء','Wednesday'=>'الأربعاء','Thursday'=>'الخميس','Friday'=>'الجمعة','Saturday'=>'السبت'][date('l')] ?? date('l');
$reportTime = date('H:i:s');
ob_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e(app_setting($pdo, 'store_name', 'برنامج المحاسبة')) ?> - جرد المستودع</title>
<style>
@page { size: A5 portrait; margin: 8mm; }
body{font-family:Tahoma,Arial,sans-serif;background:#eef3f9;margin:0;color:#222}
.wrapper{width:148mm;min-height:210mm;margin:10px auto;background:#fff;box-shadow:0 0 18px rgba(0,0,0,.08);padding:8mm;box-sizing:border-box}
.header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #0d6efd;padding-bottom:8px;margin-bottom:10px}
.header h1{margin:0;font-size:20px}.meta{font-size:12px;line-height:1.9}.meta strong{display:inline-block;min-width:55px}
table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #d5ddea;padding:6px;text-align:right}th{background:#eef4ff}.totals{margin-top:10px}.totals td{font-weight:700}.profit-pos{color:#198754}.profit-neg{color:#dc3545}.actions{display:flex;justify-content:center;gap:10px;margin:14px 0}.btn{background:#0d6efd;color:#fff;border:none;border-radius:10px;padding:10px 14px;text-decoration:none;cursor:pointer;font-size:14px}.btn.secondary{background:#6c757d}.footer-note{margin-top:10px;font-size:11px;color:#666;text-align:center}@media print{body{background:#fff}.wrapper{margin:0;box-shadow:none}.actions{display:none}}
</style>
</head>
<body>
<div class="actions">
    <button class="btn" onclick="window.print()">طباعة الجرد / حفظ PDF</button>
    <a class="btn secondary" href="inventory_audit.php">العودة إلى الجرد</a>
</div>
<div class="wrapper">
    <div class="header">
        <div>
            <h1><?= e(app_setting($pdo, 'store_name', 'برنامج المحاسبة')) ?></h1>
            <div>تقرير جرد المستودع</div>
        </div>
        <div class="meta">
            <div><strong>التاريخ:</strong> <?= e($reportDate) ?></div>
            <div><strong>اليوم:</strong> <?= e($reportDay) ?></div>
            <div><strong>الوقت:</strong> <?= e($reportTime) ?></div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>المنتج</th>
                <th>الكمية</th>
                <th>التكلفة</th>
                <th>المبيع</th>
                <th>الربح</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($products as $index => $product):
            $costTotal = (float)$product['purchase_price'] * (int)$product['quantity'];
            $saleTotal = (float)$product['sale_price'] * (int)$product['quantity'];
            $profit = $saleTotal - $costTotal;
        ?>
            <tr>
                <td><?= e($index + 1) ?></td>
                <td><?= e($product['name']) ?></td>
                <td><?= e($product['quantity']) ?></td>
                <td><?= format_money($pdo, $costTotal) ?></td>
                <td><?= format_money($pdo, $saleTotal) ?></td>
                <td class="<?= $profit >= 0 ? 'profit-pos' : 'profit-neg' ?>"><?= format_money($pdo, $profit) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <table class="totals">
        <tr><td>إجمالي سعر التكلفة / رأس المال</td><td><?= format_money($pdo, $totalCost) ?></td></tr>
        <tr><td>إجمالي سعر المبيع</td><td><?= format_money($pdo, $totalSale) ?></td></tr>
        <tr><td>الربح المتوقع</td><td><?= format_money($pdo, $expectedProfit) ?></td></tr>
    </table>

    <div class="footer-note">تم إنشاء التقرير من النظام بتاريخ <?= e($reportDate) ?> الساعة <?= e($reportTime) ?></div>
</div>
</body>
</html>
<?php
$html = ob_get_clean();
$filename = 'generated_reports/inventory-audit-' . date('Ymd-His') . '.html';
file_put_contents(__DIR__ . '/' . $filename, $html);
echo $html;
