<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

$query = "
    SELECT 
        c.id,
        c.name AS customer_name,
        c.phone,
        COUNT(i.id) AS total_invoices,
        SUM(i.total_amount) AS total_amount,
        SUM(i.paid_amount) AS total_paid,
        (SUM(i.total_amount) - SUM(i.paid_amount)) AS remaining_debt
    FROM customers c
    LEFT JOIN invoices i ON c.id = i.customer_id
    GROUP BY c.id
    ORDER BY remaining_debt DESC
";

$stmt = $pdo->prepare($query);
$stmt->execute();
$customers = $stmt->fetchAll();
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-users me-2"></i>تقرير كشف ديون وحسابات العملاء</h2>
        <a href="reports.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-right me-1"></i> العودة للتقارير</a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>اسم العميل</th>
                            <th>رقم الهاتف</th>
                            <th>عدد الفواتير</th>
                            <th>إجمالي المسحوبات</th>
                            <th>المبلغ المسدد</th>
                            <th>المتبقي (الدين)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($customers as $index => $c): ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td class="fw-bold"><?= htmlspecialchars($c['customer_name']) ?></td>
                                <td><?= htmlspecialchars($c['phone'] ?? '-') ?></td>
                                <td><?= $c['total_invoices'] ?></td>
                                <td><?= number_format($c['total_amount'] ?: 0, 2) ?></td>
                                <td class="text-success"><?= number_format($c['total_paid'] ?: 0, 2) ?></td>
                                <td>
                                    <?php $debt = $c['remaining_debt'] ?: 0; ?>
                                    <span class="badge <?= $debt > 0 ? 'bg-danger' : 'bg-success' ?> fs-6">
                                        <?= number_format($debt, 2) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>