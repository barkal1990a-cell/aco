<?php
require_once 'config/database.php';
require_once 'includes/header.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (!isset($_SESSION['last_saved_invoice_id'])) {
    $_SESSION['last_saved_invoice_id'] = null;
}

/*
|--------------------------------------------------------------------------
| تفريغ السلة بالكامل
|--------------------------------------------------------------------------
*/
if (isset($_GET['clear_cart'])) {
    $_SESSION['cart'] = [];
    redirect('invoices.php');
}

/*
|--------------------------------------------------------------------------
| التأكد من وجود جدول الوحدات وعمود unit_id
|--------------------------------------------------------------------------
*/
$pdo->exec("
    CREATE TABLE IF NOT EXISTS units (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        symbol VARCHAR(30) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_unit_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$unitColumn = $pdo->query("SHOW COLUMNS FROM products LIKE 'unit_id'");
if ($unitColumn->rowCount() === 0) {
    $pdo->exec("ALTER TABLE products ADD COLUMN unit_id INT NULL AFTER category_id");
}

/*
|--------------------------------------------------------------------------
| تحديد نوع الوحدة (متر مربع / طباعة ورق و A4)
|--------------------------------------------------------------------------
*/
function isSquareMeterUnit(?string $unitName, ?string $unitSymbol): bool
{
    $unitText = mb_strtolower(trim(($unitName ?? '') . ' ' . ($unitSymbol ?? '')));
    $squareMeterUnits = ['متر مربع', 'مترمربع', 'م²', 'م2', 'm²', 'm2', 'sqm', 'square meter'];
    foreach ($squareMeterUnits as $unit) {
        if (mb_strpos($unitText, $unit) !== false) return true;
    }
    return false;
}

function isPaperPrintUnit(?string $unitName, ?string $unitSymbol): bool
{
    $unitText = mb_strtolower(trim(($unitName ?? '') . ' ' . ($unitSymbol ?? '')));
    $paperUnits = ['طباعة ورق', 'ورق', 'a4', 'طباعة'];
    foreach ($paperUnits as $unit) {
        if (mb_strpos($unitText, $unit) !== false) return true;
    }
    return false;
}

/*
|--------------------------------------------------------------------------
| إضافة منتج عادي إلى السلة
|--------------------------------------------------------------------------
*/
if (isset($_GET['add'])) {
    $id = (int)$_GET['add'];

    $stmt = $pdo->prepare("
        SELECT p.*, u.name AS unit_name, u.symbol AS unit_symbol
        FROM products p
        LEFT JOIN units u ON u.id = p.unit_id
        WHERE p.id = ?
    ");
    $stmt->execute([$id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        $isSquareMeter = isSquareMeterUnit($product['unit_name'] ?? '', $product['unit_symbol'] ?? '');
        $isPaperPrint = isPaperPrintUnit($product['unit_name'] ?? '', $product['unit_symbol'] ?? '');

        if (!$isSquareMeter && !$isPaperPrint) {
            if (!isset($_SESSION['cart'][$id])) {
                $_SESSION['cart'][$id] = [
                    'id' => $product['id'],
                    'name' => $product['name'],
                    'price' => (float)$product['sale_price'],
                    'qty' => 1,
                    'stock' => (float)$product['quantity'],
                    'unit_name' => $product['unit_name'] ?? '',
                    'unit_symbol' => $product['unit_symbol'] ?? '',
                    'measurements' => []
                ];
            } elseif ((float)$_SESSION['cart'][$id]['qty'] < (float)$product['quantity']) {
                $_SESSION['cart'][$id]['qty']++;
            }
        }
    }
    redirect('invoices.php');
}

/*
|--------------------------------------------------------------------------
| إضافة منتج طباعة ورق / A4 إلى السلة
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_paper_print_product'])) {
    $productId = (int)($_POST['product_id'] ?? 0);
    $booksJson = $_POST['books_json'] ?? '[]';
    $books = json_decode($booksJson, true);

    if (!is_array($books) || empty($books)) {
        set_flash('error', 'يرجى إدخال تفاصيل كتاب واحد على الأقل.');
        redirect('invoices.php');
    }

    $stmt = $pdo->prepare("
        SELECT p.*, u.name AS unit_name, u.symbol AS unit_symbol
        FROM products p
        LEFT JOIN units u ON u.id = p.unit_id
        WHERE p.id = ?
    ");
    $stmt->execute([$productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        set_flash('error', 'المنتج غير موجود.');
        redirect('invoices.php');
    }

    $totalCalculatedPrice = 0;
    $totalPaperSheets = 0;

    foreach ($books as $book) {
        $pages = max(1, (int)($book['pages'] ?? 1));
        $printType = $book['print_type'] ?? 'single'; // single / double
        $binding = $book['binding'] ?? 'none'; // none / staple / spiral
        $spiralCost = (float)($book['spiral_cost'] ?? 0.5);
        $quantity = max(1, (int)($book['quantity'] ?? 1));

        // حساب عدد الورق المطلوب
        $sheetsPerBook = ($printType === 'double') ? ceil($pages / 2) : $pages;
        $totalPaperSheets += ($sheetsPerBook * $quantity);

        // حساب تكلفة الكتاب الواحد
        $unitPrice = (float)$product['sale_price'];
        $bookCost = ($sheetsPerBook * $unitPrice);
        if ($binding === 'spiral') {
            $bookCost += $spiralCost;
        }

        $totalCalculatedPrice += ($bookCost * $quantity);
    }

    $cartKey = $productId . '_print_' . time();
    $_SESSION['cart'][$cartKey] = [
        'id' => $product['id'],
        'name' => $product['name'] . ' (طباعة ورق/كتب)',
        'price' => $totalCalculatedPrice,
        'qty' => 1,
        'stock' => (float)$product['quantity'],
        'unit_name' => $product['unit_name'] ?? 'A4',
        'unit_symbol' => $product['unit_symbol'] ?? 'ورقة',
        'measurements' => $books
    ];

    set_flash('success', 'تمت إضافة أوراق الطباعة إلى السلة بنجاح.');
    redirect('invoices.php');
}

/*
|--------------------------------------------------------------------------
| إضافة منتج متر مربع إلى السلة من نافذة القياسات
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_square_meter_product'])) {
    $productId = (int)($_POST['product_id'] ?? 0);
    $measurementsJson = $_POST['measurements_json'] ?? '[]';
    $measurements = json_decode($measurementsJson, true);

    if (!is_array($measurements) || empty($measurements)) {
        set_flash('error', 'يرجى إدخال طول وعرض وعدد صحيح لقطعة واحدة على الأقل.');
        redirect('invoices.php');
    }

    $stmt = $pdo->prepare("
        SELECT p.*, u.name AS unit_name, u.symbol AS unit_symbol
        FROM products p
        LEFT JOIN units u ON u.id = p.unit_id
        WHERE p.id = ?
    ");
    $stmt->execute([$productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        set_flash('error', 'المنتج غير موجود.');
        redirect('invoices.php');
    }

    $totalArea = 0;
    $validMeasurements = [];

    foreach ($measurements as $measurement) {
        $length = (float)($measurement['length'] ?? 0);
        $width = (float)($measurement['width'] ?? 0);
        $count = (int)($measurement['count'] ?? 0);

        if ($length > 0 && $width > 0 && $count > 0) {
            $area = $length * $width * $count;
            $totalArea += $area;
            $validMeasurements[] = [
                'length' => $length,
                'width' => $width,
                'count' => $count,
                'area' => $area
            ];
        }
    }

    if ($totalArea <= 0 || empty($validMeasurements)) {
        set_flash('error', 'يرجى إدخال قياسات صحيحة للطول والعرض والعدد.');
        redirect('invoices.php');
    }

    $stock = (float)$product['quantity'];

    if ($stock > 0 && $totalArea > $stock) {
        set_flash('error', 'المساحة المطلوبة أكبر من المخزون المتاح.');
        redirect('invoices.php');
    }

    if (!isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] = [
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => (float)$product['sale_price'],
            'qty' => 0,
            'stock' => $stock,
            'unit_name' => $product['unit_name'] ?? 'متر مربع',
            'unit_symbol' => $product['unit_symbol'] ?? 'م²',
            'measurements' => []
        ];
    }

    $newQuantity = (float)$_SESSION['cart'][$productId]['qty'] + $totalArea;

    if ($stock > 0 && $newQuantity > $stock) {
        set_flash('error', 'إجمالي المساحة المضافة إلى السلة أكبر من المخزون المتاح.');
        redirect('invoices.php');
    }

    $_SESSION['cart'][$productId]['qty'] = $newQuantity;
    $_SESSION['cart'][$productId]['measurements'] = array_merge(
        $_SESSION['cart'][$productId]['measurements'] ?? [],
        $validMeasurements
    );

    set_flash('success', 'تمت إضافة المساحة إلى السلة بنجاح.');
    redirect('invoices.php');
}

/*
|--------------------------------------------------------------------------
| زيادة / إنقاص الكميات
|--------------------------------------------------------------------------
*/
if (isset($_GET['inc'])) {
    $key = $_GET['inc'];
    if (isset($_SESSION['cart'][$key])) {
        $isSquareMeter = isSquareMeterUnit($_SESSION['cart'][$key]['unit_name'] ?? '', $_SESSION['cart'][$key]['unit_symbol'] ?? '');
        $isPaperPrint = isPaperPrintUnit($_SESSION['cart'][$key]['unit_name'] ?? '', $_SESSION['cart'][$key]['unit_symbol'] ?? '');

        if (!$isSquareMeter && !$isPaperPrint && (float)$_SESSION['cart'][$key]['qty'] < (float)$_SESSION['cart'][$key]['stock']) {
            $_SESSION['cart'][$key]['qty']++;
        }
    }
    redirect('invoices.php');
}

if (isset($_GET['dec'])) {
    $key = $_GET['dec'];
    if (isset($_SESSION['cart'][$key])) {
        $isSquareMeter = isSquareMeterUnit($_SESSION['cart'][$key]['unit_name'] ?? '', $_SESSION['cart'][$key]['unit_symbol'] ?? '');
        $isPaperPrint = isPaperPrintUnit($_SESSION['cart'][$key]['unit_name'] ?? '', $_SESSION['cart'][$key]['unit_symbol'] ?? '');

        if (!$isSquareMeter && !$isPaperPrint) {
            if ((float)$_SESSION['cart'][$key]['qty'] > 1) {
                $_SESSION['cart'][$key]['qty']--;
            } else {
                unset($_SESSION['cart'][$key]);
            }
        }
    }
    redirect('invoices.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_qty'])) {
    $key = $_POST['product_id'] ?? '';
    $rawQty = trim($_POST['qty'] ?? '');

    if (isset($_SESSION['cart'][$key])) {
        $isSquareMeter = isSquareMeterUnit($_SESSION['cart'][$key]['unit_name'] ?? '', $_SESSION['cart'][$key]['unit_symbol'] ?? '');
        $isPaperPrint = isPaperPrintUnit($_SESSION['cart'][$key]['unit_name'] ?? '', $_SESSION['cart'][$key]['unit_symbol'] ?? '');

        if (!$isSquareMeter && !$isPaperPrint) {
            if ($rawQty === '') {
                unset($_SESSION['cart'][$key]);
                redirect('invoices.php');
            }
            $qty = (float)$rawQty;
            $stock = (float)$_SESSION['cart'][$key]['stock'];
            if ($qty <= 0) {
                unset($_SESSION['cart'][$key]);
            } else {
                $_SESSION['cart'][$key]['qty'] = min($qty, $stock > 0 ? $stock : $qty);
            }
        }
    }
    redirect('invoices.php');
}

if (isset($_GET['remove'])) {
    $key = $_GET['remove'];
    if (isset($_SESSION['cart'][$key])) {
        unset($_SESSION['cart'][$key]);
    }
    redirect('invoices.php');
}

/*
|--------------------------------------------------------------------------
| حفظ الفاتورة
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_invoice'])) {
    $customerId = !empty($_POST['customer_id']) ? (int)$_POST['customer_id'] : null;
    $totalText = $_POST['invoice_total'] ?? '0';
    $total = (float)preg_replace('/[^0-9.]/', '', $totalText);
    $paid = max(0, (float)($_POST['paid_amount'] ?? 0));
    $remaining = max($total - $paid, 0);

    if (empty($_SESSION['cart'])) {
        set_flash('error', 'السلة فارغة.');
        redirect('invoices.php');
    }

    $pdo->beginTransaction();

    try {
        $stmt = $pdo->prepare("
            INSERT INTO invoices (
                invoice_number, customer_id, total_amount, paid_amount, remaining_amount, notes, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            invoice_number($pdo),
            $customerId,
            $total,
            $paid,
            $remaining,
            trim($_POST['notes'] ?? ''),
            $_SESSION['user_id']
        ]);

        $invoiceId = $pdo->lastInsertId();

        foreach ($_SESSION['cart'] as $item) {
            $lineTotal = (float)$item['price'] * (float)$item['qty'];

            $itemStmt = $pdo->prepare("
                INSERT INTO invoice_items (
                    invoice_id, product_id, product_name, quantity, unit_price, total_price
                ) VALUES (?, ?, ?, ?, ?, ?)
            ");
            $itemStmt->execute([
                $invoiceId, $item['id'], $item['name'], $item['qty'], $item['price'], $lineTotal
            ]);

            $stockStmt = $pdo->prepare("
                UPDATE products
                SET quantity = quantity - ?
                WHERE id = ? AND quantity >= ?
            ");
            $stockStmt->execute([$item['qty'], $item['id'], $item['qty']]);
        }

        if ($paid > 0) {
            $cashStmt = $pdo->prepare("
                INSERT INTO cashbox (type, reference_id, amount, description)
                VALUES ('in', ?, ?, ?)
            ");
            $cashStmt->execute([$invoiceId, $paid, 'قبض من فاتورة بيع']);
        }

        if ($customerId && $remaining > 0) {
            $customerStmt = $pdo->prepare("
                UPDATE customers SET balance = balance + ? WHERE id = ?
            ");
            $customerStmt->execute([$remaining, $customerId]);
        }

        $pdo->commit();
        $_SESSION['cart'] = [];
        $_SESSION['last_saved_invoice_id'] = $invoiceId;
        set_flash('success', 'تم حفظ الفاتورة بنجاح.');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        set_flash('error', 'فشل حفظ الفاتورة: ' . $e->getMessage());
    }

    redirect('invoices.php');
}

/*
|--------------------------------------------------------------------------
| جلب المنتجات والزبائن والتصنيفات
|--------------------------------------------------------------------------
*/
$products = $pdo->query("
    SELECT p.*, u.name AS unit_name, u.symbol AS unit_symbol
    FROM products p
    LEFT JOIN units u ON u.id = p.unit_id
    WHERE p.quantity > 0
    ORDER BY p.name ASC
")->fetchAll(PDO::FETCH_ASSOC);

$customers = $pdo->query("SELECT * FROM customers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += (float)$item['price'] * (float)$item['qty'];
}

if (isset($_GET['close_saved'])) {
    $_SESSION['last_saved_invoice_id'] = null;
    redirect('invoices.php');
}

$lastSavedInvoiceId = $_SESSION['last_saved_invoice_id'] ?? null;
?>

<style>
/* Modern POS Layout Custom Styles */
:root {
    --pos-primary: #2563eb;
    --pos-success: #10b981;
    --pos-danger: #ef4444;
    --pos-border: #e2e8f0;
    --pos-bg: #f8fafc;
}

.pos-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.pos-title {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.invoice-layout {
    display: grid;
    grid-template-columns: 1.3fr 1fr;
    gap: 20px;
    align-items: start;
}

@media (max-width: 992px) {
    .invoice-layout {
        grid-template-columns: 1fr;
    }
}

.pos-card {
    background: #ffffff;
    border: 1px solid var(--pos-border);
    border-radius: 14px;
    padding: 18px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

.pos-card-title {
    font-size: 16px;
    font-weight: 700;
    color: #1e293b;
    margin: 0 0 14px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.search-box {
    margin-bottom: 14px;
    display: flex;
    gap: 10px;
}

.search-box input {
    flex: 2;
    padding: 10px 14px;
    border: 1px solid var(--pos-border);
    border-radius: 10px;
    font-size: 13px;
    outline: none;
    transition: all 0.2s;
    box-sizing: border-box;
}

.search-box select {
    flex: 1;
    padding: 10px;
    border: 1px solid var(--pos-border);
    border-radius: 10px;
    font-size: 13px;
    outline: none;
    background-color: #fff;
    cursor: pointer;
}

.search-box input:focus, .search-box select:focus {
    border-color: var(--pos-primary);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

/* شبكة المنتجات (مربعات بجانب بعضها البعض) */
.product-grid {
    max-height: 520px;
    overflow-y: auto;
    padding: 4px;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 12px;
}

.product-grid-card {
    background: #ffffff;
    border: 1px solid var(--pos-border);
    border-radius: 12px;
    padding: 12px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: all 0.25s ease;
    position: relative;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}

.product-grid-card:hover {
    border-color: var(--pos-primary);
    box-shadow: 0 8px 20px -4px rgba(37, 99, 235, 0.15);
    transform: translateY(-3px);
}

.product-card-body {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    margin-bottom: 10px;
}

.product-icon-wrap {
    width: 38px;
    height: 38px;
    background: #eff6ff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 8px;
}

.product-card-title {
    font-size: 13px;
    font-weight: 700;
    color: #0f172a;
    margin: 0;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

/* تفاصيل تظهر عند وضع الفأرة (Hover Details) */
.product-hover-details {
    background: #f8fafc;
    border: 1px dashed #cbd5e1;
    border-radius: 8px;
    padding: 8px;
    margin-bottom: 10px;
    font-size: 11px;
    display: flex;
    flex-direction: column;
    gap: 4px;
    opacity: 0.8;
    transition: all 0.2s ease;
}

.product-grid-card:hover .product-hover-details {
    opacity: 1;
    background: #eff6ff;
    border-color: #bfdbfe;
}

.hover-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.badge-stock-dynamic {
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 600;
    font-size: 10px;
}

.product-card-footer {
    margin-top: auto;
}

/* سلة المشتريات */
.cart-list {
    max-height: 380px;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 16px;
    min-height: 120px;
}

.cart-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 12px;
    background: #f8fafc;
    border: 1px solid var(--pos-border);
    border-radius: 10px;
}

.cart-item-title {
    font-size: 13px;
    font-weight: 700;
    color: #0f172a;
    margin-bottom: 3px;
}

.cart-item-price {
    font-size: 12px;
    color: #64748b;
}

.qty-control {
    display: inline-flex;
    align-items: center;
    background: #fff;
    border: 1px solid var(--pos-border);
    border-radius: 8px;
    overflow: hidden;
}

.qty-btn {
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f1f5f9;
    color: #0f172a;
    text-decoration: none;
    font-weight: bold;
    font-size: 14px;
    transition: background 0.2s;
}

.qty-btn:hover {
    background: #e2e8f0;
}

.qty-input {
    width: 42px;
    height: 28px;
    border: none;
    text-align: center;
    font-size: 13px;
    font-weight: bold;
    outline: none;
}

.total-box {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 12px;
    padding: 14px 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.total-box strong {
    font-size: 16px;
    color: #1e40af;
}

.btn-quick-pay {
    background: #3b82f6;
    color: white;
    border: none;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    cursor: pointer;
    margin-top: 4px;
}

.btn-quick-pay:hover {
    background: #2563eb;
}

/* منع استجابة النقر على خلفية نافذة إتمام الفاتورة ونوافذ الطباعة */
#checkoutModal, #paperPrintModal {
    pointer-events: none;
}

#checkoutModal .modal-content, #paperPrintModal .modal-content {
    pointer-events: auto;
}

.paper-book-row {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 12px;
    margin-bottom: 12px;
}
</style>

<div class="pos-header">
    <h1 class="pos-title">
        <svg style="width:28px; height:28px; color:var(--pos-primary);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
        الفواتير والبيع المباشر
    </h1>
</div>

<?php if ($lastSavedInvoiceId): ?>
<div class="pos-card" style="border-right: 5px solid #10b981; background: #ecfdf5; margin-bottom: 20px;">
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div style="display:flex; align-items:center; gap:10px;">
            <svg style="width:24px; height:24px; color:#059669;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
            <h3 style="margin:0; font-size:15px; color:#065f46;">تم حفظ الفاتورة بنجاح</h3>
        </div>
        <div style="display:flex; gap:8px;">
            <a class="btn btn-primary" target="_blank" href="invoice_print.php?id=<?= e($lastSavedInvoiceId) ?>" style="font-size:12px; padding:6px 12px;">فتح الفاتورة للطباعة</a>
            <a class="btn btn-secondary" href="invoices.php?close_saved=1" style="font-size:12px; padding:6px 12px;">إغلاق</a>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="invoice-layout">
    <!-- قائمة المنتجات (شبكة مربعات) -->
    <div class="pos-card">
        <div class="pos-card-title">
            <span style="display:flex; align-items:center; gap:6px;">
                <svg style="width:18px; height:18px; color:var(--pos-primary);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                المنتجات في المخزن
            </span>
            <span class="badge" style="background:#f1f5f9; color:#475569; padding:3px 8px; border-radius:6px; font-size:11px; font-weight:600;"><?= count($products) ?> صنف</span>
        </div>

        <!-- حقل البحث مع القائمة المنسدلة للتصنيفات -->
        <div class="search-box">
            <input type="text" id="searchProduct" placeholder="🔍 بحث سريع عن منتج..." onkeyup="filterProducts()">
            <select id="categoryFilter" onchange="filterProducts()">
                <option value="">جميع التصنيفات</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= e((string)$cat['id']) ?>"><?= e($cat['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="product-grid" id="productList">
            <?php foreach($products as $p): ?>
                <?php
                $isSquareMeter = isSquareMeterUnit($p['unit_name'] ?? '', $p['unit_symbol'] ?? '');
                $isPaperPrint = isPaperPrintUnit($p['unit_name'] ?? '', $p['unit_symbol'] ?? '');

                $unitText = '';
                if (!empty($p['unit_name'])) {
                    $unitText = $p['unit_name'];
                    if (!empty($p['unit_symbol'])) {
                        $unitText .= ' (' . $p['unit_symbol'] . ')';
                    }
                }

                $qtyVal = (float)$p['quantity'];
                $isLowStock = $qtyVal < 10;
                $stockStyle = $isLowStock 
                    ? 'background: #fee2e2; color: #dc2626; border: 1px solid #fecaca;' 
                    : 'background: #f1f5f9; color: #475569;';
                ?>
                <div class="product-grid-card" data-name="<?= e(mb_strtolower($p['name'])) ?>" data-category="<?= e((string)($p['category_id'] ?? '')) ?>">
                    <div class="product-card-body">
                        <div class="product-icon-wrap">
                            <svg style="width:20px; height:20px; color:var(--pos-primary);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                        </div>
                        <h4 class="product-card-title"><?= e($p['name']) ?></h4>
                    </div>

                    <!-- تفاصيل السعر والكمية (تظهر عند وضع الفأرة Hover) -->
                    <div class="product-hover-details">
                        <div class="hover-row">
                            <span style="color:#64748b;">السعر:</span>
                            <strong style="color:#059669;"><?= format_money($pdo, $p['sale_price']) ?></strong>
                        </div>
                        <div class="hover-row">
                            <span style="color:#64748b;">المتبقي:</span>
                            <span class="badge-stock-dynamic" style="<?= $stockStyle ?>">
                                <?= e($p['quantity']) ?> <?= e($unitText) ?>
                            </span>
                        </div>
                    </div>

                    <div class="product-card-footer">
                        <?php if ($isSquareMeter): ?>
                            <button
                                type="button"
                                class="btn btn-primary"
                                style="width:100%; font-size:12px; padding:6px; border-radius:8px; display:flex; align-items:center; justify-content:center; gap:4px;"
                                onclick="
                                    openSquareMeterModal(
                                        <?= e((string)$p['id']) ?>,
                                        '<?= e($p['name']) ?>',
                                        <?= e((string)$p['sale_price']) ?>,
                                        <?= e((string)$p['quantity']) ?>,
                                        '<?= e($unitText ?: 'متر مربع') ?>'
                                    )
                                "
                            >
                                <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path></svg>
                                قياسات
                            </button>
                        <?php elseif ($isPaperPrint): ?>
                            <button
                                type="button"
                                class="btn btn-primary"
                                style="width:100%; font-size:12px; padding:6px; border-radius:8px; display:flex; align-items:center; justify-content:center; gap:4px;"
                                onclick="
                                    openPaperPrintModal(
                                        <?= e((string)$p['id']) ?>,
                                        '<?= e($p['name']) ?>',
                                        <?= e((string)$p['sale_price']) ?>,
                                        <?= e((string)$p['quantity']) ?>
                                    )
                                "
                            >
                                <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
                                طباعة ورق
                            </button>
                        <?php else: ?>
                            <a class="btn btn-primary" href="?add=<?= e($p['id']) ?>" style="width:100%; font-size:12px; padding:6px; border-radius:8px; display:flex; align-items:center; justify-content:center; gap:4px; text-decoration:none; color:white;">
                                <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                                إضافة
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- سلة المشتريات -->
    <div class="pos-card">
        <div class="pos-card-title">
            <div style="display:flex; align-items:center; gap:8px;">
                <svg style="width:18px; height:18px; color:var(--pos-primary);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z"></path></svg>
                <span>سلة المشتريات</span>
                <span class="badge" style="background:#f1f5f9; color:#475569; padding:2px 8px; border-radius:6px; font-size:11px;"><?= count($_SESSION['cart']) ?> عنصر</span>
            </div>
            
            <a href="?clear_cart=1" class="btn btn-danger" style="font-size:11px; padding:5px 10px; border-radius:6px; display:inline-flex; align-items:center; gap:4px; text-decoration:none; color:white;" onclick="return confirm('هل أنت متأكد من تفريغ السلة بالكامل؟')">
                <svg style="width:13px; height:13px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                تفريغ السلة
            </a>
        </div>

        <div class="cart-list">
            <?php if(empty($_SESSION['cart'])): ?>
                <div style="text-align:center; padding:30px 10px; color:#94a3b8;">
                    <svg style="width:40px; height:40px; margin-bottom:8px; stroke-width:1.5;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z"></path></svg>
                    <p style="margin:0; font-size:13px;">السلة فارغة، اختر منتجات من القائمة.</p>
                </div>
            <?php endif; ?>

            <?php foreach($_SESSION['cart'] as $cartKey => $item): ?>
                <?php
                $line = (float)$item['price'] * (float)$item['qty'];

                $isSquareMeter = isSquareMeterUnit($item['unit_name'] ?? '', $item['unit_symbol'] ?? '');
                $isPaperPrint = isPaperPrintUnit($item['unit_name'] ?? '', $item['unit_symbol'] ?? '');

                $unitLabel = trim(($item['unit_name'] ?? '') . ' ' . ($item['unit_symbol'] ?? ''));
                ?>
                <div class="cart-item">
                    <div>
                        <div class="cart-item-title"><?= e($item['name']) ?></div>
                        <div class="cart-item-price">
                            <?= format_money($pdo, $item['price']) ?>
                            ×
                            <?= ($isSquareMeter || $isPaperPrint) ? number_format((float)$item['qty'], 2) : e($item['qty']) ?>
                            <?= e($unitLabel) ?>
                            =
                            <strong style="color:#2563eb;"><?= format_money($pdo, $line) ?></strong>
                        </div>

                        <?php if ($isSquareMeter && !empty($item['measurements'])): ?>
                            <div style="font-size:11px; color:#64748b; margin-top:4px;">
                                عدد القياسات: <?= e((string)count($item['measurements'])) ?>
                            </div>
                        <?php elseif ($isPaperPrint && !empty($item['measurements'])): ?>
                            <div style="font-size:11px; color:#64748b; margin-top:4px;">
                                عدد الكتب / المطبوعات: <?= e((string)count($item['measurements'])) ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($isSquareMeter || $isPaperPrint): ?>
                        <div style="display:flex; gap:5px; align-items:center;">
                            <a class="btn btn-danger" style="font-size:11px; padding:5px 8px; text-decoration:none;" href="?remove=<?= e((string)$cartKey) ?>">حذف</a>
                        </div>
                    <?php else: ?>
                        <form method="post" style="margin:0;">
                            <input type="hidden" name="update_qty" value="1">
                            <input type="hidden" name="product_id" value="<?= e($cartKey) ?>">

                            <div class="qty-control">
                                <a class="qty-btn" href="?dec=<?= e($cartKey) ?>">-</a>
                                <input
                                    type="number"
                                    name="qty"
                                    class="qty-input"
                                    min="0"
                                    max="<?= e($item['stock']) ?>"
                                    value="<?= e($item['qty']) ?>"
                                    onblur="this.form.submit()"
                                >
                                <a class="qty-btn" href="?inc=<?= e($cartKey) ?>">+</a>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="total-box">
            <div>
                <small style="color:#1e3a8a; font-weight:600; display:block;">المبلغ الإجمالي</small>
                <strong><?= format_money($pdo, $total) ?></strong>
            </div>
            <button class="btn btn-success" onclick="openModal('checkoutModal')" style="padding:8px 20px; font-weight:700; border-radius:10px;" <?= empty($_SESSION['cart']) ? 'disabled' : '' ?>>حاسب الآن</button>
        </div>
    </div>
</div>

<!-- نافذة إتمام الفاتورة -->
<div class="modal" id="checkoutModal">
    <div class="modal-content" style="border-radius:14px; max-width:500px;">
        <h3 style="margin-top:0; border-bottom:1px solid #e2e8f0; padding-bottom:10px; font-size:18px;">إتمام الفاتورة</h3>

        <form method="post" class="form-grid" style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <input type="hidden" name="save_invoice" value="1">

            <div class="form-group" style="grid-column:span 2;">
                <label style="font-weight:600; font-size:12px;">اختيار الزبون</label>
                <div style="display:flex; gap:6px;">
                    <select name="customer_id" style="flex-grow:1; padding:8px; border-radius:8px; border:1px solid #cbd5e1;">
                        <option value="">نقدي / بدون زبون</option>
                        <?php foreach($customers as $c): ?>
                            <option value="<?= e($c['id']) ?>"><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <a href="customers.php" class="btn btn-warning" style="font-size:11px; padding:6px 10px; white-space:nowrap; text-decoration:none;">+ زبون جديد</a>
                </div>
            </div>

            <div class="form-group">
                <label style="font-weight:600; font-size:12px;">رقم الفاتورة</label>
                <input value="<?= e(invoice_number($pdo)) ?>" readonly style="background:#f1f5f9; font-weight:700;">
            </div>

            <div class="form-group">
                <label style="font-weight:600; font-size:12px;">إجمالي الفاتورة</label>
                <input id="invoice_total" name="invoice_total" value="<?= format_money($pdo,$total) ?>" readonly style="background:#f1f5f9; font-weight:800; color:#2563eb;">
            </div>

            <div class="form-group">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <label style="font-weight:600; font-size:12px;">المبلغ المدفوع</label>
                    <button type="button" class="btn-quick-pay" onclick="setFullPayment()">دفع كامل</button>
                </div>
                <input type="number" step="0.01" id="paid_amount" name="paid_amount" value="0" oninput="calcRemaining()" required style="font-weight:700;">
            </div>

            <div class="form-group">
                <label style="font-weight:600; font-size:12px;">المبلغ المتبقي</label>
                <input type="text" id="remaining_amount" readonly value="<?= format_money($pdo,$total) ?>" style="background:#fff1f1; color:#dc2626; font-weight:800;">
            </div>

            <div class="form-group" style="grid-column:span 2;">
                <label style="font-weight:600; font-size:12px;">ملاحظات</label>
                <textarea name="notes" rows="2" style="width:100%; border-radius:8px; border:1px solid #cbd5e1; padding:8px; box-sizing:border-box;"></textarea>
            </div>

            <div class="form-group" style="grid-column:span 2; display:flex; gap:10px; margin-top:10px;">
                <button class="btn btn-success" type="submit" style="flex:2; padding:10px; font-weight:700;">حفظ وطباعة الفاتورة</button>
                <button class="btn btn-secondary" type="button" onclick="closeModal('checkoutModal')" style="flex:1;">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<!-- نافذة حساب مساحة المتر المربع -->
<div class="modal" id="squareMeterModal">
    <div class="modal-content" style="border-radius:14px; max-width:780px;">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap;">
            <div>
                <h3 style="margin:0; font-size:18px;">حساب مساحة المنتج بالمتر المربع</h3>
                <p id="squareMeterProductInfo" style="margin:6px 0 0; color:#64748b; font-size:12px;"></p>
            </div>
            <button type="button" class="btn btn-secondary" onclick="closeModal('squareMeterModal')" style="font-size:12px; padding:6px 12px;">إغلاق</button>
        </div>

        <form method="post" id="squareMeterForm" style="margin-top:16px;">
            <input type="hidden" name="add_square_meter_product" value="1">
            <input type="hidden" name="product_id" id="squareMeterProductId">
            <input type="hidden" name="measurements_json" id="measurementsJson">

            <div style="overflow-x:auto;">
                <table class="table" style="margin:0;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>الطول بالمتر</th>
                            <th>العرض بالمتر</th>
                            <th>العدد</th>
                            <th>المساحة م²</th>
                            <th>حذف</th>
                        </tr>
                    </thead>
                    <tbody id="squareMeterRows"></tbody>
                </table>
            </div>

            <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-top:14px;">
                <button type="button" class="btn btn-primary" onclick="addSquareMeterRow()" style="font-size:12px; padding:7px 12px;">+ إضافة قطعة أخرى</button>
                <div style="background:#eff6ff; border:1px solid #bfdbfe; padding:10px 14px; border-radius:8px; color:#1d4ed8; font-weight:700; font-size:13px;">
                    المساحة المربعة الإجمالية: <span id="totalSquareMeterArea">0.00</span> م²
                </div>
            </div>

            <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:18px;">
                <button type="button" class="btn btn-secondary" onclick="closeModal('squareMeterModal')">إلغاء</button>
                <button type="button" class="btn btn-success" onclick="confirmSquareMeter()">موافق</button>
            </div>
        </form>
    </div>
</div>

<!-- نافذة حساب طباعة الورق والكتب A4 -->
<div class="modal" id="paperPrintModal">
    <div class="modal-content" style="border-radius:14px; max-width:800px;">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap;">
            <div>
                <h3 style="margin:0; font-size:18px;">حساب طباعة الورق والكتب (A4)</h3>
                <p id="paperPrintProductInfo" style="margin:6px 0 0; color:#64748b; font-size:12px;"></p>
            </div>
            <button type="button" class="btn btn-secondary" onclick="closeModal('paperPrintModal')" style="font-size:12px; padding:6px 12px;">إغلاق</button>
        </div>

        <form method="post" id="paperPrintForm" style="margin-top:16px;">
            <input type="hidden" name="add_paper_print_product" value="1">
            <input type="hidden" name="product_id" id="paperPrintProductId">
            <input type="hidden" name="books_json" id="booksJson">

            <div id="paperBooksContainer"></div>

            <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-top:14px;">
                <button type="button" class="btn btn-primary" onclick="addPaperBookRow()" style="font-size:12px; padding:7px 12px;">+ إضافة كتاب آخر</button>
                <div style="background:#eff6ff; border:1px solid #bfdbfe; padding:10px 14px; border-radius:8px; color:#1d4ed8; font-weight:700; font-size:14px;">
                    المبلغ الإجمالي: <span id="totalPaperPrintPrice">0.00</span> $
                </div>
            </div>

            <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:18px;">
                <button type="button" class="btn btn-secondary" onclick="closeModal('paperPrintModal')">إلغاء</button>
                <button type="button" class="btn btn-success" onclick="confirmPaperPrint()">أضف للفاتورة</button>
            </div>
        </form>
    </div>
</div>

<script>
let squareMeterStock = 0;
let squareMeterRowCount = 0;

let paperPrintUnitPrice = 0;
let paperPrintStock = 0;
let paperBookRowCount = 0;

/* تصفية المنتجات بـ JavaScript وتخزين حالة الفرز والبحث في localStorage */
function filterProducts() {
    const searchQuery = document.getElementById('searchProduct').value.toLowerCase().trim();
    const selectedCategory = document.getElementById('categoryFilter').value;

    localStorage.setItem('pos_selected_category', selectedCategory);
    localStorage.setItem('pos_search_query', searchQuery);

    const items = document.querySelectorAll('#productList .product-grid-card');

    items.forEach(item => {
        const productName = item.getAttribute('data-name') || '';
        const productCategory = item.getAttribute('data-category') || '';

        const matchesSearch = productName.includes(searchQuery);
        const matchesCategory = (selectedCategory === '') || (productCategory === selectedCategory);

        if (matchesSearch && matchesCategory) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// استعادة التصنيف المختار والبحث تلقائياً فور تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    const savedCategory = localStorage.getItem('pos_selected_category');
    const savedSearch = localStorage.getItem('pos_search_query');

    if (savedCategory !== null) {
        document.getElementById('categoryFilter').value = savedCategory;
    }
    if (savedSearch !== null) {
        document.getElementById('searchProduct').value = savedSearch;
    }

    filterProducts();
});

// منع إغلاق النافذة عند النقر خارجها
window.addEventListener('click', function(event) {
    const checkoutModal = document.getElementById('checkoutModal');
    const paperPrintModal = document.getElementById('paperPrintModal');
    if (event.target === checkoutModal || event.target === paperPrintModal) {
        event.stopPropagation();
    }
}, true);

function setFullPayment() {
    const totalText = document.getElementById('invoice_total').value;
    const total = parseFloat(totalText.replace(/[^0-9.]/g, '') || 0);
    document.getElementById('paid_amount').value = total;
    calcRemaining();
}

function calcRemaining() {
    const totalText = document.getElementById('invoice_total').value;
    const total = parseFloat(totalText.replace(/[^0-9.]/g, '') || 0);
    const paid = parseFloat(document.getElementById('paid_amount').value || 0);
    const currency = ' <?= addslashes(app_setting($pdo, 'currency', 'ل.س')) ?>';
    const remaining = Math.max(total - paid, 0);

    document.getElementById('remaining_amount').value = remaining.toFixed(2) + currency;
}

/* ----------------------------------------------------
   دوال نافذة طباعة الورق والكتب A4
---------------------------------------------------- */
function openPaperPrintModal(productId, productName, salePrice, stock) {
    document.getElementById('paperPrintProductId').value = productId;
    paperPrintUnitPrice = parseFloat(salePrice || 0);
    paperPrintStock = parseFloat(stock || 0);

    document.getElementById('paperPrintProductInfo').textContent =
        'المنتج: ' + productName + ' | سعر طباعة الورقة: ' + paperPrintUnitPrice.toFixed(4) + ' $ | المتوفر: ' + paperPrintStock;

    paperBookRowCount = 0;
    document.getElementById('paperBooksContainer').innerHTML = '';
    addPaperBookRow();
    openModal('paperPrintModal');
}

function addPaperBookRow() {
    paperBookRowCount++;
    const container = document.getElementById('paperBooksContainer');
    const div = document.createElement('div');
    div.className = 'paper-book-row';
    div.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
            <strong style="color:#1e293b; font-size:13px;">كتاب / عنصر رقم #${paperBookRowCount}</strong>
            <button type="button" class="btn btn-danger" style="font-size:11px; padding:3px 8px;" onclick="removePaperBookRow(this)">حذف</button>
        </div>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap:10px; align-items:end;">
            <div>
                <label style="font-size:11px; display:block; margin-bottom:4px; font-weight:600;">عدد الصفحات:</label>
                <input type="number" min="1" value="1" class="book-pages" oninput="calculatePaperPrintTotal()" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;">
            </div>
            <div>
                <label style="font-size:11px; display:block; margin-bottom:4px; font-weight:600;">نوع الطباعة:</label>
                <select class="book-print-type" onchange="calculatePaperPrintTotal()" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;">
                    <option value="single">وجه واحد</option>
                    <option value="double">وجهين (تقسيم 2)</option>
                </select>
            </div>
            <div>
                <label style="font-size:11px; display:block; margin-bottom:4px; font-weight:600;">الإنهاء / التجليد:</label>
                <select class="book-binding" onchange="toggleSpiralInput(this); calculatePaperPrintTotal();" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;">
                    <option value="staple">خرز ($0)</option>
                    <option value="spiral">راصور</option>
                </select>
            </div>
            <div class="spiral-cost-wrap" style="display:none;">
                <label style="font-size:11px; display:block; margin-bottom:4px; font-weight:600;">سعر الراصور ($):</label>
                <input type="number" step="0.01" min="0" value="0.50" class="book-spiral-cost" oninput="calculatePaperPrintTotal()" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;">
            </div>
            <div>
                <label style="font-size:11px; display:block; margin-bottom:4px; font-weight:600;">العدد (نسخ):</label>
                <input type="number" min="1" value="1" class="book-quantity" oninput="calculatePaperPrintTotal()" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;">
            </div>
            <div>
                <label style="font-size:11px; display:block; margin-bottom:4px; font-weight:600;">السعر الجزئي ($):</label>
                <input type="text" class="book-subtotal" readonly value="0.00" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; background:#f1f5f9; font-weight:700; color:#2563eb; box-sizing:border-box;">
            </div>
        </div>
    `;
    container.appendChild(div);
    calculatePaperPrintTotal();
}

function toggleSpiralInput(selectElem) {
    const row = selectElem.closest('.paper-book-row');
    const spiralWrap = row.querySelector('.spiral-cost-wrap');
    if (selectElem.value === 'spiral') {
        spiralWrap.style.display = 'block';
    } else {
        spiralWrap.style.display = 'none';
    }
}

function removePaperBookRow(button) {
    const row = button.closest('.paper-book-row');
    if (row) row.remove();
    const rows = document.querySelectorAll('.paper-book-row');
    if (rows.length === 0) addPaperBookRow();
    calculatePaperPrintTotal();
}

function calculatePaperPrintTotal() {
    const rows = document.querySelectorAll('.paper-book-row');
    let grandTotal = 0;

    rows.forEach(row => {
        const pages = maxVal(parseInt(row.querySelector('.book-pages').value || 1, 10), 1);
        const printType = row.querySelector('.book-print-type').value;
        const binding = row.querySelector('.book-binding').value;
        const spiralCost = parseFloat(row.querySelector('.book-spiral-cost').value || 0.5);
        const quantity = maxVal(parseInt(row.querySelector('.book-quantity').value || 1, 10), 1);

        // حساب أوراق المطبوعات
        let paperSheets = pages;
        if (printType === 'double') {
            paperSheets = Math.ceil(pages / 2);
        }

        // حساب تكلفة الكتاب الواحد
        let singleBookPrice = paperSheets * paperPrintUnitPrice;
        if (binding === 'spiral') {
            singleBookPrice += spiralCost;
        }

        const rowTotal = singleBookPrice * quantity;
        row.querySelector('.book-subtotal').value = rowTotal.toFixed(2);
        grandTotal += rowTotal;
    });

    document.getElementById('totalPaperPrintPrice').textContent = grandTotal.toFixed(2);
}

function maxVal(val, min) {
    return isNaN(val) || val < min ? min : val;
}

function confirmPaperPrint() {
    const rows = document.querySelectorAll('.paper-book-row');
    const books = [];

    rows.forEach(row => {
        const pages = maxVal(parseInt(row.querySelector('.book-pages').value || 1, 10), 1);
        const printType = row.querySelector('.book-print-type').value;
        const binding = row.querySelector('.book-binding').value;
        const spiralCost = parseFloat(row.querySelector('.book-spiral-cost').value || 0.5);
        const quantity = maxVal(parseInt(row.querySelector('.book-quantity').value || 1, 10), 1);

        books.push({
            pages: pages,
            print_type: printType,
            binding: binding,
            spiral_cost: spiralCost,
            quantity: quantity
        });
    });

    if (books.length === 0) {
        alert('يرجى إضافة كتاب واحد على الأقل.');
        return;
    }

    document.getElementById('booksJson').value = JSON.stringify(books);
    document.getElementById('paperPrintForm').submit();
}

/* ----------------------------------------------------
   دوال نافذة المتر المربع
---------------------------------------------------- */
function openSquareMeterModal(productId, productName, price, stock, unitName) {
    document.getElementById('squareMeterProductId').value = productId;
    document.getElementById('squareMeterProductInfo').textContent =
        'المنتج: ' + productName + ' | سعر المتر: ' + Number(price || 0).toFixed(2) + ' | المخزون المتاح: ' + Number(stock || 0).toFixed(2) + ' ' + (unitName || 'م²');

    squareMeterStock = parseFloat(stock || 0);
    squareMeterRowCount = 0;
    document.getElementById('squareMeterRows').innerHTML = '';
    addSquareMeterRow();
    updateSquareMeterTotal();
    openModal('squareMeterModal');
}

function addSquareMeterRow() {
    squareMeterRowCount++;
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${squareMeterRowCount}</td>
        <td><input type="number" step="0.01" min="0" class="square-meter-length" placeholder="0.00" oninput="updateSquareMeterTotal()" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;"></td>
        <td><input type="number" step="0.01" min="0" class="square-meter-width" placeholder="0.00" oninput="updateSquareMeterTotal()" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;"></td>
        <td><input type="number" step="1" min="1" value="1" class="square-meter-count" oninput="updateSquareMeterTotal()" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;"></td>
        <td><input type="text" class="square-meter-area" readonly value="0.00" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; background:#f8fafc; box-sizing:border-box;"></td>
        <td><button type="button" class="btn btn-danger" style="font-size:11px; padding:5px 8px;" onclick="removeSquareMeterRow(this)">حذف</button></td>
    `;
    document.getElementById('squareMeterRows').appendChild(row);
    updateSquareMeterTotal();
}

function removeSquareMeterRow(button) {
    const row = button.closest('tr');
    if (row) row.remove();
    const rows = document.querySelectorAll('#squareMeterRows tr');
    if (rows.length === 0) addSquareMeterRow();
    rows.forEach((item, index) => { item.children[0].textContent = index + 1; });
    squareMeterRowCount = rows.length;
    updateSquareMeterTotal();
}

function updateSquareMeterTotal() {
    const rows = document.querySelectorAll('#squareMeterRows tr');
    let totalArea = 0;

    rows.forEach((row) => {
        const length = parseFloat(row.querySelector('.square-meter-length').value || 0);
        const width = parseFloat(row.querySelector('.square-meter-width').value || 0);
        const count = parseInt(row.querySelector('.square-meter-count').value || 0, 10);
        const area = (length > 0 && width > 0 && count > 0) ? length * width * count : 0;

        row.querySelector('.square-meter-area').value = area.toFixed(2);
        totalArea += area;
    });

    document.getElementById('totalSquareMeterArea').textContent = totalArea.toFixed(2);
}

function confirmSquareMeter() {
    const rows = document.querySelectorAll('#squareMeterRows tr');
    const measurements = [];
    let totalArea = 0;

    rows.forEach((row) => {
        const length = parseFloat(row.querySelector('.square-meter-length').value || 0);
        const width = parseFloat(row.querySelector('.square-meter-width').value || 0);
        const count = parseInt(row.querySelector('.square-meter-count').value || 0, 10);

        if (length > 0 && width > 0 && count > 0) {
            const area = length * width * count;
            measurements.push({ length: length, width: width, count: count, area: area });
            totalArea += area;
        }
    });

    if (measurements.length === 0 || totalArea <= 0) {
        alert('يرجى إدخال طول وعرض وعدد صحيح لقطعة واحدة على الأقل.');
        return;
    }

    if (squareMeterStock > 0 && totalArea > squareMeterStock) {
        alert('المساحة المطلوبة أكبر من المخزون المتاح.');
        return;
    }

    document.getElementById('measurementsJson').value = JSON.stringify(measurements);
    document.getElementById('squareMeterForm').submit();
}
</script>

<?php require_once 'includes/footer.php'; ?>