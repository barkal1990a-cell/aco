<?php
// تفعيل التخزين المؤقت للمخرجات لمنع أخطاء headers already sent
if (ob_get_level() === 0) {
    ob_start();
}

// بدء الجلسة إذا لم تكن مفعّلة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * التحقق من تسجيل دخول المستخدم
 */
function is_logged_in(): bool { 
    return isset($_SESSION['user_id']); 
}

/**
 * إعادة التوجيه بشكل آمن حتى لو تم إرسال مخرجات HTML سابقاً
 */
function redirect(string $url): void { 
    if (!headers_sent()) {
        header("Location: " . $url);
        exit();
    } else {
        echo '<script>window.location.href = ' . json_encode($url) . ';</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url=' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"></noscript>';
        exit();
    }
}

/**
 * تعقيم النصوص لحمايتها من هجمات XSS
 */
function e(?string $value): string { 
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); 
}

/**
 * تعيين رسالة تنبيه مؤقتة (Flash Message)
 */
function set_flash(string $type, string $message): void { 
    $_SESSION['flash'] = ['type' => $type, 'message' => $message]; 
}

/**
 * جلب وقراءة رسالة التنبيه المؤقتة
 */
function get_flash(): ?array { 
    if (!isset($_SESSION['flash'])) return null; 
    $f = $_SESSION['flash']; 
    unset($_SESSION['flash']); 
    return $f; 
}

/**
 * إلزامية تسجيل الدخول للصفحات المقفلة
 */
function require_login(): void { 
    if (!is_logged_in()) redirect('login.php'); 
}

/**
 * تنسيق الأرقام والعملات
 */
function format_currency($value): string { 
    return number_format((float)$value, 2); 
}

/**
 * معرفة اسم الصفحة الحالية
 */
function current_page(): string { 
    return basename($_SERVER['PHP_SELF'] ?? ''); 
}

/**
 * توليد رقم فاتورة مبيعات تلقائي
 */
function invoice_number(PDO $pdo): string { 
    $stmt = $pdo->query("SELECT COUNT(*) + 1 AS next_no FROM invoices"); 
    $row = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : null;
    $next = $row['next_no'] ?? 1; 
    return 'INV-' . str_pad((string)$next, 6, '0', STR_PAD_LEFT); 
}

/**
 * توليد رقم فاتورة شراء تلقائي
 */
function purchase_number(PDO $pdo): string { 
    $stmt = $pdo->query("SELECT COUNT(*) + 1 AS next_no FROM purchase_invoices"); 
    $row = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : null;
    $next = $row['next_no'] ?? 1; 
    return 'PUR-' . str_pad((string)$next, 6, '0', STR_PAD_LEFT); 
}

/**
 * التأكد من وجود جدول الإعدادات وإنشائه عند الحاجة
 */
function ensure_settings_table(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY, 
        setting_key VARCHAR(100) NOT NULL UNIQUE, 
        setting_value TEXT NULL
    )");
    
    $defaults = ['store_name' => 'برنامج المحاسبة', 'currency' => 'ل.س'];
    $stmt = $pdo->prepare("INSERT IGNORE INTO settings(setting_key, setting_value) VALUES(?, ?)");
    foreach ($defaults as $key => $value) {
        $stmt->execute([$key, $value]);
    }
}

/**
 * جلب قيمة إعداد معين من الجدول
 */
function app_setting(PDO $pdo, string $key, string $default = ''): string {
    ensure_settings_table($pdo);
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1");
    $stmt->execute([$key]);
    $value = $stmt->fetchColumn();
    return $value !== false ? (string)$value : $default;
}

/**
 * تنسيق المبلغ المالي مع إضافة رمز العملة من الإعدادات
 */
function format_money(PDO $pdo, $value): string {
    return number_format((float)$value, 2) . ' ' . app_setting($pdo, 'currency', 'ل.س');
}