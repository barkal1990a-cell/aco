<?php
require_once 'config/database.php';

/*
|--------------------------------------------------------------------------
| معالجة طلب تصدير Excel (يجب أن يتم قبل أي مخرجات HTML أو استدعاء الهيدر)
|--------------------------------------------------------------------------
*/
if (isset($_GET['export_excel'])) {
    $productsExport = $pdo->query("
        SELECT p.id, p.name, p.sku, c.name AS category_name, u.name AS unit_name, p.purchase_price, p.sale_price, p.quantity
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        LEFT JOIN units u ON u.id = p.unit_id
        ORDER BY p.id DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // تنظيف أي مخازن مؤقتة للطباعة لضمان نظافة ملف الـ CSV
    if (ob_get_level()) {
        ob_end_clean();
    }

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=products_export_' . date('Y-m-d') . '.csv');
    
    $output = fopen('php://output', 'w');
    // إضافة BOM لدعم اللغة العربية بشكل صحيح في Excel
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // كتابة عناوين الأعمدة
    fputcsv($output, ['ID', 'اسم المنتج', 'الكود (SKU)', 'التصنيف', 'الوحدة', 'سعر الشراء', 'سعر البيع', 'الكمية']);
    
    foreach ($productsExport as $row) {
        fputcsv($output, [
            $row['id'],
            $row['name'],
            $row['sku'],
            $row['category_name'] ?: 'بدون تصنيف',
            $row['unit_name'] ?: 'بدون وحدة',
            $row['purchase_price'],
            $row['sale_price'],
            $row['quantity']
        ]);
    }
    fclose($output);
    exit;
}

// الآن نقوم بتضمين الهيدر بعد تجاوز طلبات التصدير
require_once 'includes/header.php';

/*
|--------------------------------------------------------------------------
| تهيئة وبنية قواعد البيانات (Self-Migration)
|--------------------------------------------------------------------------
*/
$pdo->exec("
    CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$pdo->exec("
    CREATE TABLE IF NOT EXISTS units (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        symbol VARCHAR(30) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_unit_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// التأكد من وجود أعمدة التصنيف والوحدة في جدول المنتجات
$categoryColumn = $pdo->query("SHOW COLUMNS FROM products LIKE 'category_id'");
if ($categoryColumn->rowCount() === 0) {
    $pdo->exec("ALTER TABLE products ADD COLUMN category_id INT NULL AFTER category");
}

$unitColumn = $pdo->query("SHOW COLUMNS FROM products LIKE 'unit_id'");
if ($unitColumn->rowCount() === 0) {
    $pdo->exec("ALTER TABLE products ADD COLUMN unit_id INT NULL AFTER category_id");
}

// تنظيف أعمدة سابقة إن وجدت
$parentColumn = $pdo->query("SHOW COLUMNS FROM categories LIKE 'parent_id'");
if ($parentColumn->rowCount() > 0) {
    try { $pdo->exec("ALTER TABLE categories DROP FOREIGN KEY fk_category_parent"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE categories DROP COLUMN parent_id"); } catch (Throwable $e) {}
}

// التأكد من وجود عمود رصيد المورد
$supplierBalanceColumn = $pdo->query("SHOW COLUMNS FROM suppliers LIKE 'balance'");
if ($supplierBalanceColumn->rowCount() === 0) {
    $pdo->exec("ALTER TABLE suppliers ADD COLUMN balance DECIMAL(12,2) NOT NULL DEFAULT 0");
}

// جداول فواتير الشراء
$pdo->exec("
    CREATE TABLE IF NOT EXISTS purchase_invoices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        purchase_number VARCHAR(50) NOT NULL UNIQUE,
        supplier_id INT NOT NULL,
        total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
        paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
        remaining_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
        notes TEXT NULL,
        created_by INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$pdo->exec("
    CREATE TABLE IF NOT EXISTS purchase_invoice_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        purchase_invoice_id INT NOT NULL,
        product_name VARCHAR(150) NOT NULL,
        quantity INT NOT NULL,
        unit_price DECIMAL(12,2) NOT NULL,
        total_price DECIMAL(12,2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// نقل التصنيفات القديمة النصية إلى الجدول المربوط
$oldCategories = $pdo->query("
    SELECT DISTINCT TRIM(category) AS category_name
    FROM products
    WHERE category IS NOT NULL AND TRIM(category) <> ''
")->fetchAll(PDO::FETCH_ASSOC);

if (!empty($oldCategories)) {
    $findCategory = $pdo->prepare("SELECT id FROM categories WHERE name = ? LIMIT 1");
    $insertCategory = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
    $updateProductCategory = $pdo->prepare("UPDATE products SET category_id = ? WHERE category_id IS NULL AND TRIM(category) = ?");

    foreach ($oldCategories as $oldCategory) {
        $categoryName = trim($oldCategory['category_name']);
        if ($categoryName === '') continue;

        $findCategory->execute([$categoryName]);
        $categoryId = $findCategory->fetchColumn();

        if (!$categoryId) {
            $insertCategory->execute([$categoryName]);
            $categoryId = $pdo->lastInsertId();
        }

        $updateProductCategory->execute([(int)$categoryId, $categoryName]);
    }
}

/*
|--------------------------------------------------------------------------
| معالجة POST: استيراد المنتجات من ملف Excel (CSV) - [محدث لدعم التصنيف والوحدة]
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_excel'])) {
    if (isset($_FILES['excel_file']) && $_FILES['excel_file']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['excel_file']['tmp_name'];
        $fileName = $_FILES['excel_file']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if ($fileExtension === 'csv' || $fileExtension === 'txt') {
            if (($handle = fopen($fileTmpPath, 'r')) !== FALSE) {
                // تجاوز السطر الأول (العناوين)
                $header = fgetcsv($handle, 1000, ',');
                
                // تجهيز جمل البحث والإدخال للتصنيفات والوحدات والمنتجات
                $findCategoryStmt = $pdo->prepare("SELECT id FROM categories WHERE name = ? LIMIT 1");
                $insertCategoryStmt = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");

                $findUnitStmt = $pdo->prepare("SELECT id FROM units WHERE name = ? LIMIT 1");
                $insertUnitStmt = $pdo->prepare("INSERT INTO units (name) VALUES (?)");

                $insertProductStmt = $pdo->prepare("
                    INSERT INTO products (name, sku, category, category_id, unit_id, purchase_price, sale_price, quantity) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $importedCount = 0;
                while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                    if (count($data) >= 8) {
                        $name       = trim($data[1]);
                        $sku        = trim($data[2]);
                        $catName    = trim($data[3]);
                        $unitName   = trim($data[4]);
                        $pPrice     = (float)$data[5];
                        $sPrice     = (float)$data[6];
                        $qty        = (int)$data[7];

                        if ($name !== '') {
                            // معالجة التصنيف وربطه تلقائياً
                            $categoryId = null;
                            if ($catName !== '' && $catName !== 'بدون تصنيف') {
                                $findCategoryStmt->execute([$catName]);
                                $categoryId = $findCategoryStmt->fetchColumn();
                                if (!$categoryId) {
                                    $insertCategoryStmt->execute([$catName]);
                                    $categoryId = $pdo->lastInsertId();
                                }
                            }

                            // معالجة الوحدة وربطها تلقائياً
                            $unitId = null;
                            if ($unitName !== '' && $unitName !== 'بدون وحدة') {
                                $findUnitStmt->execute([$unitName]);
                                $unitId = $findUnitStmt->fetchColumn();
                                if (!$unitId) {
                                    $insertUnitStmt->execute([$unitName]);
                                    $unitId = $pdo->lastInsertId();
                                }
                            }

                            try {
                                $insertProductStmt->execute([
                                    $name, 
                                    $sku, 
                                    ($catName !== 'بدون تصنيف' ? $catName : ''), 
                                    $categoryId, 
                                    $unitId, 
                                    $pPrice, 
                                    $sPrice, 
                                    $qty
                                ]);
                                $importedCount++;
                            } catch (Throwable $e) {
                                // تخطي السطر في حال وجود خطأ مفرد
                            }
                        }
                    }
                }
                fclose($handle);
                set_flash('success', "تم استيراد $importedCount منتج بنجاح مع التصنيفات والوحدات.");
            } else {
                set_flash('error', 'تعذر قراءة الملف المرفوع.');
            }
        } else {
            set_flash('error', 'يرجى رفع ملف بصيغة CSV حصراً.');
        }
    } else {
        set_flash('error', 'الرجاء اختيار ملف صالح للاستيراد.');
    }
    redirect('products.php');
}

/*
|--------------------------------------------------------------------------
| معالجة POST: حفظ عملية شراء مباشرة
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_quick_purchase'])) {
    $productId  = (int)($_POST['product_id'] ?? 0);
    $supplierId = (int)($_POST['supplier_id'] ?? 0);
    $quantity   = (int)($_POST['purchase_quantity'] ?? 0);
    $unitPrice  = (float)($_POST['purchase_unit_price'] ?? 0);
    $paidAmount = (float)($_POST['paid_amount'] ?? 0);
    $notes      = trim($_POST['purchase_notes'] ?? '');

    if ($productId <= 0 || $supplierId <= 0 || $quantity <= 0 || $unitPrice < 0) {
        set_flash('error', 'يرجى اختيار المورد وإدخال كمية وسعر شراء صحيحين.');
        redirect('products.php');
    }

    $productStmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $productStmt->execute([$productId]);
    $purchaseProduct = $productStmt->fetch(PDO::FETCH_ASSOC);

    $supplierStmt = $pdo->prepare("SELECT id, name, balance FROM suppliers WHERE id = ?");
    $supplierStmt->execute([$supplierId]);
    $purchaseSupplier = $supplierStmt->fetch(PDO::FETCH_ASSOC);

    if (!$purchaseProduct || !$purchaseSupplier) {
        set_flash('error', 'المنتج أو المورد غير موجود.');
        redirect('products.php');
    }

    $totalAmount     = $quantity * $unitPrice;
    $paidAmount      = max(0, $paidAmount);
    $remainingAmount = max(0, $totalAmount - $paidAmount);
    $extraPaid       = max(0, $paidAmount - $totalAmount);

    $pdo->beginTransaction();
    try {
        $purchaseNumber = function_exists('purchase_number') ? purchase_number($pdo) : 'PUR-' . time();
        $createdBy      = $_SESSION['user_id'] ?? null;

        $invoiceStmt = $pdo->prepare("
            INSERT INTO purchase_invoices (
                purchase_number, supplier_id, total_amount, paid_amount, remaining_amount, notes, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $invoiceStmt->execute([
            $purchaseNumber, $supplierId, $totalAmount, $paidAmount, $remainingAmount, $notes, $createdBy
        ]);
        $purchaseInvoiceId = $pdo->lastInsertId();

        $itemStmt = $pdo->prepare("
            INSERT INTO purchase_invoice_items (
                purchase_invoice_id, product_name, quantity, unit_price, total_price
            ) VALUES (?, ?, ?, ?, ?)
        ");
        $itemStmt->execute([
            $purchaseInvoiceId, $purchaseProduct['name'], $quantity, $unitPrice, $totalAmount
        ]);

        $productUpdate = $pdo->prepare("
            UPDATE products
            SET quantity = quantity + ?, purchase_price = ?
            WHERE id = ?
        ");
        $productUpdate->execute([$quantity, $unitPrice, $productId]);

        if ($paidAmount > 0) {
            $cashStmt = $pdo->prepare("
                INSERT INTO cashbox (type, reference_id, amount, description)
                VALUES ('out', ?, ?, ?)
            ");
            $cashStmt->execute([
                $purchaseInvoiceId,
                $paidAmount,
                'دفع شراء الصنف: ' . $purchaseProduct['name']
            ]);
        }

        $supplierUpdate = $pdo->prepare("
            UPDATE suppliers
            SET balance = GREATEST(0, balance + ? - ?)
            WHERE id = ?
        ");
        $supplierUpdate->execute([$remainingAmount, $extraPaid, $supplierId]);

        $pdo->commit();
        set_flash('success', 'تم حفظ فاتورة الشراء بنجاح. رقم الفاتورة: ' . $purchaseNumber);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        set_flash('error', 'فشل حفظ فاتورة الشراء: ' . $e->getMessage());
    }

    redirect('products.php');
}

/*
|--------------------------------------------------------------------------
| معالجة POST: تعديل وحذف المنتج
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_product'])) {
        $productId   = (int)($_POST['product_id'] ?? 0);
        $categoryId  = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
        $unitId      = !empty($_POST['unit_id']) ? (int)$_POST['unit_id'] : null;
        $categoryName = '';

        if ($categoryId) {
            $categoryStmt = $pdo->prepare("SELECT name FROM categories WHERE id = ?");
            $categoryStmt->execute([$categoryId]);
            $categoryName = (string)$categoryStmt->fetchColumn();
        }

        $stmt = $pdo->prepare("
            UPDATE products
            SET name = ?, sku = ?, category = ?, category_id = ?, unit_id = ?,
                purchase_price = ?, sale_price = ?, quantity = ?
            WHERE id = ?
        ");
        $stmt->execute([
            trim($_POST['name']),
            trim($_POST['sku']),
            $categoryName,
            $categoryId,
            $unitId,
            (float)$_POST['purchase_price'],
            (float)$_POST['sale_price'],
            (int)$_POST['quantity'],
            $productId
        ]);

        set_flash('success', 'تم تعديل بيانات المنتج بنجاح.');
        redirect('products.php');
    }

    if (isset($_POST['delete_product'])) {
        $productId = (int)($_POST['product_id'] ?? 0);
        if ($productId > 0) {
            $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$productId]);
            set_flash('warning', 'تم حذف المنتج من المستودع.');
        }
        redirect('products.php');
    }
}

/*
|--------------------------------------------------------------------------
| جلب القوائم الأساسية
|--------------------------------------------------------------------------
*/
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$units      = $pdo->query("SELECT * FROM units ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$suppliers  = $pdo->query("SELECT id, name, balance FROM suppliers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

$editProduct = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editProduct = $stmt->fetch(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| الفلترة والبحث
|--------------------------------------------------------------------------
*/
$searchQuery      = isset($_GET['search']) ? trim($_GET['search']) : '';
$selectedCategory = isset($_GET['category_filter']) && $_GET['category_filter'] !== '' ? (int)$_GET['category_filter'] : 0;
$selectedUnit     = isset($_GET['unit_filter']) && $_GET['unit_filter'] !== '' ? (int)$_GET['unit_filter'] : 0;
$showLowStock     = isset($_GET['low_stock']) && $_GET['low_stock'] === '1';

$where  = [];
$params = [];

if ($searchQuery !== '') {
    $where[]  = '(p.name LIKE ? OR p.sku LIKE ?)';
    $params[] = '%' . $searchQuery . '%';
    $params[] = '%' . $searchQuery . '%';
}

if ($selectedCategory > 0) {
    $where[]  = 'p.category_id = ?';
    $params[] = $selectedCategory;
}

if ($selectedUnit > 0) {
    $where[]  = 'p.unit_id = ?';
    $params[] = $selectedUnit;
}

if ($showLowStock) {
    $where[] = 'p.quantity < 10';
}

$sql = "
    SELECT
        p.*,
        c.name AS category_name,
        u.name AS unit_name,
        u.symbol AS unit_symbol
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN units u ON u.id = p.unit_id
";

if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}

$sql .= " ORDER BY p.quantity ASC, c.name ASC, p.name ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| إحصائيات المستودع الشاملة
|--------------------------------------------------------------------------
*/
$totalProductsCount = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$lowStockCount      = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE quantity < 10")->fetchColumn();

$totalCostValue = 0;
$totalSaleValue = 0;

foreach ($products as $prod) {
    $qty = (int)$prod['quantity'];
    $totalCostValue += (float)$prod['purchase_price'] * $qty;
    $totalSaleValue += (float)$prod['sale_price'] * $qty;
}
?>

<!-- الهيدر الرئيسي والإجراءات -->
<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
        <div>
            <h1 style="margin:0; font-size:1.6rem;">المستودع وإدارة المنتجات</h1>
            <p style="margin:6px 0 0; color:#6b7280; font-size:0.95rem;">
                التحكم بالمنتجات، فحص الكميات، ومتابعة القيمة المالية والشراء المباشر.
            </p>
        </div>

        <div style="display:flex; gap:8px; flex-wrap:wrap;">
            <a class="btn btn-primary" href="add_product.php">
                <i class="icon">+</i> إضافة منتج جديد
            </a>
            <a class="btn btn-success" href="products.php?export_excel=1">
                📥 تصدير إلى Excel
            </a>
            <button type="button" class="btn btn-warning" onclick="openModal('importExcelModal')">
                📤 استيراد من Excel
            </button>
            <a class="btn btn-secondary" href="categories.php">إدارة التصنيفات</a>
            <a class="btn btn-secondary" href="units.php">إدارة الوحدات</a>
            <a class="btn btn-secondary" href="inventory_audit.php">جرد المستودع</a>
            <a class="btn <?= $lowStockCount > 0 ? 'btn-danger' : 'btn-success' ?>" href="products.php?low_stock=1">
                المنتجات الحرجة: <strong><?= e((string)$lowStockCount) ?></strong>
            </a>
        </div>
    </div>
</div>

<!-- بطاقات الإحصائيات العصرية -->
<div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:16px;">
    <div class="stat">
        <h3>إجمالي عدد المنتجات</h3>
        <strong><?= e((string)$totalProductsCount) ?> صنف</strong>
    </div>

    <div class="stat">
        <h3>قيمة المخزون (بالتكلفة)</h3>
        <strong style="color:#2563eb;"><?= format_money($pdo, $totalCostValue) ?></strong>
    </div>

    <div class="stat">
        <h3>القيمة البيعية المتوقعة</h3>
        <strong style="color:#059669;"><?= format_money($pdo, $totalSaleValue) ?></strong>
    </div>

    <div class="stat">
        <h3>النواقص والمخزون الحرج</h3>
        <strong class="<?= $lowStockCount > 0 ? 'danger-text' : 'success-text' ?>">
            <?= e((string)$lowStockCount) ?> صنف
        </strong>
    </div>
</div>

<!-- نموذج التعديل (في حال الضغط على تعديل) -->
<?php if ($editProduct): ?>
    <div class="card" style="border-right: 4px solid #f59e0b;">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
            <h3 style="margin:0;">تعديل بيانات المنتج: <span style="color:#2563eb;"><?= e($editProduct['name']) ?></span></h3>
            <a class="btn btn-secondary" href="products.php">إلغاء التعديل</a>
        </div>

        <form method="post" class="form-grid" style="margin-top:16px;">
            <input type="hidden" name="update_product" value="1">
            <input type="hidden" name="product_id" value="<?= e((string)$editProduct['id']) ?>">

            <div class="form-group">
                <label>اسم المنتج</label>
                <input name="name" required value="<?= e($editProduct['name']) ?>">
            </div>

            <div class="form-group">
                <label>الكود / باركود (SKU)</label>
                <input name="sku" value="<?= e($editProduct['sku']) ?>">
            </div>

            <div class="form-group">
                <label>التصنيف</label>

                <select name="category_id">
                    <option value="">بدون تصنيف</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= e((string)$category['id']) ?>"
                            <?= (int)($editProduct['category_id'] ?? 0) === (int)$category['id'] ? 'selected' : '' ?>>
                            <?= e($category['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>وحدة القياس</label>

                <select name="unit_id">
                    <option value="">بدون وحدة</option>
                    <?php foreach ($units as $unit): ?>
                        <option value="<?= e((string)$unit['id']) ?>"
                            <?= (int)($editProduct['unit_id'] ?? 0) === (int)$unit['id'] ? 'selected' : '' ?>>
                            <?= e($unit['name']) ?> <?= !empty($unit['symbol']) ? '(' . e($unit['symbol']) . ')' : '' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>سعر الشراء</label>

                <input type="number" step="0.01" min="0" name="purchase_price" id="edit_purchase_price" required
                    value="<?= e((string)$editProduct['purchase_price']) ?>" oninput="calculateMargin()">
            </div>

            <div class="form-group">
                <label>سعر البيع</label>

                <input type="number" step="0.01" min="0" name="sale_price" id="edit_sale_price" required
                    value="<?= e((string)$editProduct['sale_price']) ?>" oninput="calculateMargin()">
            </div>

            <div class="form-group">
                <label>الكمية بالحساب الحالي</label>

                <input type="number" min="0" name="quantity" required
                    value="<?= e((string)$editProduct['quantity']) ?>">
            </div>

            <div class="form-group" style="grid-column: 1 / -1; background:#f9fafb; padding:10px; border-radius:6px;">
                <small id="margin_info" style="font-weight:bold; font-size:0.95rem;">
                    <!-- يتم حسابه تفاعليًا بـ JS -->
                </small>
            </div>

            <div class="form-group" style="grid-column: 1 / -1; text-align:left;">
                <button class="btn btn-warning" type="submit">حفظ التعديلات</button>
            </div>
        </form>
    </div>
<?php endif; ?>

<!-- فلترة وبحث المنتجات -->
<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
        <h3 style="margin:0;">
            <?= $showLowStock ? 'المنتجات الموشكة على النفاذ (< 10)' : 'قائمة منتجات المستودع' ?>
        </h3>

        <form method="get" style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
            <?php if ($showLowStock): ?>
                <input type="hidden" name="low_stock" value="1">
            <?php endif; ?>

            <input type="text" name="search" placeholder="بحث باسم أو كود المنتج..."
                value="<?= e($searchQuery) ?>" style="min-width:200px; padding:6px 10px;">

            <select name="category_filter" onchange="this.form.submit()">
                <option value="">كل التصنيفات</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= e((string)$category['id']) ?>"
                        <?= $selectedCategory === (int)$category['id'] ? 'selected' : '' ?>>
                        <?= e($category['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="unit_filter" onchange="this.form.submit()">
                <option value="">كل الوحدات</option>

                <?php foreach ($units as $unit): ?>
                    <option value="<?= e((string)$unit['id']) ?>"
                        <?= $selectedUnit === (int)$unit['id'] ? 'selected' : '' ?>>
                        <?= e($unit['name']) ?> <?= !empty($unit['symbol']) ? '(' . e($unit['symbol']) . ')' : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="btn btn-primary">تصفية</button>
            <a class="btn btn-secondary" href="products.php">إعادة ضبط</a>
        </form>
    </div>

    <!-- جدول عرض المنتجات المطور -->
    <div style="overflow-x:auto; margin-top:16px;">
        <table class="table" style="width:100%; border-collapse:collapse;">
            <thead>
                <tr>
                    <th>#</th>
                    <th>اسم المنتج</th>
                    <th>الكود</th>
                    <th>التصنيف</th>
                    <th>الوحدة</th>
                    <th>سعر الشراء</th>
                    <th>سعر البيع</th>
                    <th>الكمية</th>
                    <th>الحالة</th>
                    <th style="text-align:center;">إجراءات</th>
                </tr>
            </thead>

            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="10" style="text-align:center; padding:24px; color:#6b7280;">
                            لا توجد منتجات مطابقة لخيارات البحث أو الفلترة الحالية.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <?php
                        $qty = (int)$product['quantity'];
                        $isOutOfStock = $qty <= 0;
                        $isLowStock   = $qty > 0 && $qty < 10;

                        $unitText = '—';
                        if (!empty($product['unit_name'])) {
                            $unitText = $product['unit_name'];
                            if (!empty($product['unit_symbol'])) {
                                $unitText .= ' (' . $product['unit_symbol'] . ')';
                            }
                        }
                        ?>
                        <tr style="<?= $isOutOfStock ? 'background:#fef2f2;' : ($isLowStock ? 'background:#fffbe0;' : '') ?>">
                            <td><?= e((string)$product['id']) ?></td>

                            <td>
                                <strong><?= e($product['name']) ?></strong>
                            </td>

                            <td><code style="font-size:0.85rem; color:#4b5563;"><?= e($product['sku'] ?: '—') ?></code></td>

                            <td><?= e($product['category_name'] ?: ($product['category'] ?: 'بدون تصنيف')) ?></td>

                            <td><?= e($unitText) ?></td>

                            <td><?= format_money($pdo, $product['purchase_price']) ?></td>

                            <td><strong><?= format_money($pdo, $product['sale_price']) ?></strong></td>

                            <td class="<?= $isLowStock || $isOutOfStock ? 'danger-text' : '' ?>">
                                <strong style="font-size:1.05rem;"><?= e((string)$qty) ?></strong>
                            </td>

                            <td>
                                <?php if ($isOutOfStock): ?>
                                    <span class="badge" style="background:#ef4444; color:#fff; padding:2px 8px; border-radius:12px; font-size:0.8rem;">نفذت الكمية</span>
                                <?php elseif ($isLowStock): ?>
                                    <span class="badge" style="background:#f59e0b; color:#fff; padding:2px 8px; border-radius:12px; font-size:0.8rem;">حرج (<10)</span>
                                <?php else: ?>
                                    <span class="badge" style="background:#10b981; color:#fff; padding:2px 8px; border-radius:12px; font-size:0.8rem;">متوفر</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <div style="display:flex; gap:4px; justify-content:center;">
                                    <button type="button" class="btn btn-primary btn-quick-purchase"
                                        data-id="<?= e((string)$product['id']) ?>"
                                        data-name="<?= e($product['name']) ?>"
                                        data-sku="<?= e($product['sku']) ?>"
                                        data-price="<?= e((string)$product['purchase_price']) ?>"
                                        data-unit="<?= e($unitText) ?>">
                                        شراء
                                    </button>

                                    <a class="btn btn-warning" href="products.php?edit=<?= e((string)$product['id']) ?>">
                                        تعديل
                                    </a>

                                    <form method="post" onsubmit="return confirm('هل أنت تأكد من حذف المنتج النهائي من المستودع؟')" style="display:inline;">
                                        <input type="hidden" name="delete_product" value="1">
                                        <input type="hidden" name="product_id" value="<?= e((string)$product['id']) ?>">
                                        <button class="btn btn-danger" type="submit">حذف</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- مودال استيراد ملف الـ Excel / CSV -->
<div class="modal" id="importExcelModal">
    <div class="modal-content" style="max-width:500px; border-radius:8px;">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; border-bottom:1px solid #e5e7eb; padding-bottom:12px;">
            <h3 style="margin:0;">استيراد المنتجات من ملف Excel (CSV)</h3>
            <button type="button" class="btn btn-secondary" onclick="closeModal('importExcelModal')">إغلاق</button>
        </div>

        <form method="post" enctype="multipart/form-data" style="margin-top:16px;">
            <input type="hidden" name="import_excel" value="1">
            
            <div class="form-group" style="margin-bottom:12px;">
                <label>اختر ملف CSV:</label>
                <input type="file" name="excel_file" accept=".csv" required style="width:100%; padding:6px; border:1px solid #d1d5db; border-radius:4px;">
                <small style="color:#6b7280; display:block; margin-top:4px;">
                    ملاحظة: يجب أن يكون الملف متوافقاً مع صيغة التصدير (الأعمدة مرتبة: ID, اسم المنتج, SKU, التصنيف, الوحدة, سعر الشراء, سعر البيع, الكمية).
                </small>
            </div>

            <div class="form-group" style="text-align:left; margin-top:16px;">
                <button type="submit" class="btn btn-success">بدء الاستيراد</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal('importExcelModal')">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<!-- مودال فاتورة الشراء المباشر -->
<div class="modal" id="quickPurchaseModal">
    <div class="modal-content" style="max-width:760px; border-radius:8px;">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; border-bottom:1px solid #e5e7eb; padding-bottom:12px;">
            <h3 style="margin:0;">تسجيل فاتورة شراء صنف إلى المستودع</h3>
            <button type="button" class="btn btn-secondary" onclick="closeModal('quickPurchaseModal')">إغلاق</button>
        </div>

        <form method="post" class="form-grid" style="margin-top:16px;">
            <input type="hidden" name="save_quick_purchase" value="1">
            <input type="hidden" name="product_id" id="quick_product_id">

            <div class="form-group">
                <label>اسم المنتج</label>
                <input id="quick_product_name" readonly style="background:#f3f4f6; font-weight:bold;">
            </div>

            <div class="form-group">
                <label>كود المنتج / SKU</label>
                <input id="quick_product_sku" readonly style="background:#f3f4f6;">
            </div>

            <div class="form-group">
                <label>وحدة القياس</label>
                <input id="quick_product_unit" readonly style="background:#f3f4f6;">
            </div>

            <div class="form-group">
                <label>الكمية المشتراة</label>
                <input type="number" min="1" step="1" name="purchase_quantity" id="quick_quantity" value="1" oninput="calculateQuickPurchase()" required>
            </div>

            <div class="form-group">
                <label>سعر الشراء للقطعة</label>
                <input type="number" min="0" step="0.01" name="purchase_unit_price" id="quick_unit_price" oninput="calculateQuickPurchase()" required>
            </div>

            <div class="form-group">
                <label>اختيار المورد</label>
                <select name="supplier_id" id="quick_supplier_id" onchange="calculateQuickPurchase()" required>
                    <option value="" data-balance="0">-- اختر المورد --</option>
                    <?php foreach ($suppliers as $supplier): ?>
                        <option value="<?= e((string)$supplier['id']) ?>" data-balance="<?= e((string)$supplier['balance']) ?>">
                            <?= e($supplier['name']) ?> (الدين السابق: <?= format_money($pdo, $supplier['balance']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>إجمالي قيمة الفاتورة</label>
                <input id="quick_total_amount" readonly style="font-weight:bold; color:#2563eb; background:#eff6ff;">
            </div>

            <div class="form-group">
                <label>المبلغ المدفوع نقداً</label>
                <input type="number" min="0" step="0.01" name="paid_amount" id="quick_paid_amount" value="0" oninput="calculateQuickPurchase()" required>
                <div style="display:flex; gap:4px; margin-top:4px;">
                    <button type="button" class="btn btn-secondary" style="font-size:0.75rem; padding:2px 6px;" onclick="setPaidFull()">دفع كامل</button>
                    <button type="button" class="btn btn-secondary" style="font-size:0.75rem; padding:2px 6px;" onclick="setPaidZero()">آجل (0)</button>
                </div>
            </div>

            <div class="form-group">
                <label>المتبقي من الفاتورة</label>
                <input id="quick_remaining_amount" readonly style="color:#dc2626; background:#fef2f2;">
            </div>

            <div class="form-group">
                <label>إجمالي دين المورد بعد العملية</label>
                <input id="quick_total_debt" readonly style="font-weight:bold; background:#f9fafb;">
            </div>

            <div class="form-group" style="grid-column:1/-1;">
                <label>ملاحظات الشراء</label>
                <textarea name="purchase_notes" rows="2" placeholder="أدخل أي ملاحظات إضافية تخص عملية الشراء..."></textarea>
            </div>

            <div class="form-group" style="grid-column:1/-1; display:flex; gap:8px; justify-content:flex-end;">
                <button class="btn btn-success" type="submit">حفظ وتأكيد فاتورة الشراء</button>
                <button class="btn btn-secondary" type="button" onclick="closeModal('quickPurchaseModal')">إغلاق</button>
            </div>
        </form>
    </div>
</div>

<script>
const quickCurrency = ' <?= addslashes(app_setting($pdo, 'currency', 'ل.س')) ?>';

function moneyText(val) {
    return Number(val || 0).toFixed(2) + quickCurrency;
}

document.addEventListener('click', function (e) {
    const btn = e.target.closest('.btn-quick-purchase');
    if (btn) {
        openQuickPurchase(
            btn.dataset.id,
            btn.dataset.name,
            btn.dataset.sku,
            btn.dataset.price,
            btn.dataset.unit
        );
    }
});

function openQuickPurchase(productId, productName, sku, purchasePrice, unitName) {
    document.getElementById('quick_product_id').value   = productId;
    document.getElementById('quick_product_name').value = productName;
    document.getElementById('quick_product_sku').value  = sku || '—';
    document.getElementById('quick_product_unit').value = unitName || '—';

    document.getElementById('quick_quantity').value   = 1;
    document.getElementById('quick_unit_price').value = Number(purchasePrice || 0).toFixed(2);
    document.getElementById('quick_paid_amount').value = 0;
    document.getElementById('quick_supplier_id').value = '';

    calculateQuickPurchase();
    openModal('quickPurchaseModal');
}

function calculateQuickPurchase() {
    const qty       = parseFloat(document.getElementById('quick_quantity').value || 0);
    const unitPrice = parseFloat(document.getElementById('quick_unit_price').value || 0);
    const paid      = parseFloat(document.getElementById('quick_paid_amount').value || 0);

    const supplierSelect = document.getElementById('quick_supplier_id');
    const selectedOption = supplierSelect.options[supplierSelect.selectedIndex];
    const previousDebt   = parseFloat((selectedOption && selectedOption.dataset.balance) || 0);

    const total     = Math.max(0, qty * unitPrice);
    const remaining = Math.max(0, total - paid);
    const extraPaid = Math.max(0, paid - total);
    const totalDebt = Math.max(0, previousDebt + remaining - extraPaid);

    document.getElementById('quick_total_amount').value     = moneyText(total);
    document.getElementById('quick_remaining_amount').value = moneyText(remaining);
    document.getElementById('quick_total_debt').value       = moneyText(totalDebt);
}

function setPaidFull() {
    const qty       = parseFloat(document.getElementById('quick_quantity').value || 0);
    const unitPrice = parseFloat(document.getElementById('quick_unit_price').value || 0);
    document.getElementById('quick_paid_amount').value = (qty * unitPrice) ? (qty * unitPrice).toFixed(2) : 0;
    calculateQuickPurchase();
}

function setPaidZero() {
    document.getElementById('quick_paid_amount').value = 0;
    calculateQuickPurchase();
}

function calculateMargin() {
    const purchase = parseFloat(document.getElementById('edit_purchase_price')?.value || 0);
    const sale     = parseFloat(document.getElementById('edit_sale_price')?.value || 0);
    const profit   = sale - purchase;
    const margin   = purchase > 0 ? ((profit / purchase) * 100).toFixed(1) : 0;

    const infoElem = document.getElementById('margin_info');
    if (infoElem) {
        infoElem.textContent = `هامش الربح المتوقع للقطعة: ${profit.toFixed(2)}${quickCurrency} (${margin}%)`;
        infoElem.style.color = profit >= 0 ? '#10b981' : '#ef4444';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('edit_purchase_price')) {
        calculateMargin();
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>