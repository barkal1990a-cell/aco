<?php
require_once 'config/database.php';

/*
|--------------------------------------------------------------------------
| الدوال المساعدة
|--------------------------------------------------------------------------
*/
function reportEscape($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function reportValidDate($value, string $fallback): string
{
    if (!is_string($value)) {
        return $fallback;
    }

    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);

    return $date && $date->format('Y-m-d') === $value
        ? $value
        : $fallback;
}

function reportFetch(PDO $pdo, string $sql, array $params = []): array
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function reportSum(PDO $pdo, string $sql, array $params = []): float
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return (float)$stmt->fetchColumn();
}

function reportMoney($value, string $currency): string
{
    return number_format((float)$value, 2) . ' ' . $currency;
}

function reportUrl(
    string $report,
    string $startDate,
    string $endDate,
    array $extra = []
): string {
    return 'reports.php?' . http_build_query(array_merge([
        'report' => $report,
        'start_date' => $startDate,
        'end_date' => $endDate,
    ], $extra));
}

function reportCsvCell($value): string
{
    $value = (string)$value;

    if (preg_match('/^[\s]*[=+\-@]/u', $value)) {
        return "'" . $value;
    }

    return $value;
}

/*
|--------------------------------------------------------------------------
| الفترة الزمنية
|--------------------------------------------------------------------------
*/
$startDate = reportValidDate(
    $_GET['start_date'] ?? null,
    date('Y-m-01')
);

$endDate = reportValidDate(
    $_GET['end_date'] ?? null,
    date('Y-m-t')
);

if ($startDate > $endDate) {
    [$startDate, $endDate] = [$endDate, $startDate];
}

$from = $startDate . ' 00:00:00';

$until = (new DateTimeImmutable($endDate))
    ->modify('+1 day')
    ->format('Y-m-d 00:00:00');

$periodParams = [$from, $until];

/*
|--------------------------------------------------------------------------
| العملة من قاعدة البيانات مباشرة
|--------------------------------------------------------------------------
| لا نعتمد على تحميل app_setting داخل header.php.
|--------------------------------------------------------------------------
*/
$currency = 'ل.س';
$currencyWarning = '';

try {
    $currencyStmt = $pdo->prepare("
        SELECT setting_value
        FROM settings
        WHERE setting_key = ?
        LIMIT 1
    ");

    $currencyStmt->execute(['currency']);

    $savedCurrency = $currencyStmt->fetchColumn();

    if (
        $savedCurrency !== false
        && trim((string)$savedCurrency) !== ''
    ) {
        $currency = trim((string)$savedCurrency);
    } else {
        $currencyWarning = 'لم توجد عملة محفوظة؛ تستخدم العملة الافتراضية ل.س.';
    }
} catch (PDOException $exception) {
    error_log('Reports currency error: ' . $exception->getMessage());

    $currencyWarning = 'تعذر قراءة إعداد العملة؛ تستخدم العملة الافتراضية ل.س.';
}

/*
|--------------------------------------------------------------------------
| دليل التقارير
|--------------------------------------------------------------------------
*/
$reports = [
    'sales' => [
        'title' => 'تقرير المبيعات التفصيلي',
        'desc' => 'الفواتير وأصنافها والمبالغ المسجلة عند إنشاء الفاتورة.',
        'icon' => '🧾',
        'current' => false,
    ],
    'purchases' => [
        'title' => 'تقرير المشتريات والفواتير',
        'desc' => 'فواتير الموردين وتفاصيل المواد والمبالغ المدفوعة.',
        'icon' => '🛒',
        'current' => false,
    ],
    'profits' => [
        'title' => 'تقرير الأرباح والخسائر',
        'desc' => 'تقدير الربح بتكلفة المنتجات الحالية وبعد المصروفات.',
        'icon' => '📈',
        'current' => false,
    ],
    'treasury' => [
        'title' => 'تقرير حركة الصندوق',
        'desc' => 'القبض والصرف والرصيد المرحل والرصيد التراكمي.',
        'icon' => '💵',
        'current' => false,
    ],
    'customers_debt' => [
        'title' => 'تقرير حسابات الزبائن',
        'desc' => 'ديون الزبائن وأرصدتهم الدائنة الحالية.',
        'icon' => '👥',
        'current' => true,
    ],
    'suppliers_debt' => [
        'title' => 'تقرير حسابات الموردين',
        'desc' => 'مستحقات الموردين والأرصدة الموجودة لنا لديهم.',
        'icon' => '🚚',
        'current' => true,
    ],
    'inventory' => [
        'title' => 'تقرير جرد المخزون',
        'desc' => 'الكميات الحالية وقيمة المخزون بسعر الشراء والبيع.',
        'icon' => '📦',
        'current' => true,
    ],
    'top_products' => [
        'title' => 'المنتجات الأكثر مبيعًا',
        'desc' => 'ترتيب المنتجات حسب الكميات المباعة خلال الفترة.',
        'icon' => '🔥',
        'current' => false,
    ],
    'expenses' => [
        'title' => 'تقرير المصروفات',
        'desc' => 'المصاريف المسجلة حسب تاريخ المصروف.',
        'icon' => '📋',
        'current' => false,
    ],
];

$selectedReport = is_string($_GET['report'] ?? null)
    ? $_GET['report']
    : 'sales';

if (!isset($reports[$selectedReport])) {
    $selectedReport = 'sales';
}

/*
|--------------------------------------------------------------------------
| القيم الأولية
|--------------------------------------------------------------------------
*/
$errorMessage = '';
$columns = [];
$rows = [];
$reportNote = '';
$reportSummary = [];

$totalSales = 0;
$totalPurchases = 0;
$totalExpenses = 0;
$totalCustomerDebts = 0;
$totalCustomerCredits = 0;
$totalSupplierDebts = 0;
$totalSupplierCredits = 0;
$estimatedCost = 0;
$missingCostItems = 0;
$estimatedProfit = null;

$chartLabels = [];
$chartSales = [];
$chartPurchases = [];

/*
|--------------------------------------------------------------------------
| تحميل بيانات التقارير
|--------------------------------------------------------------------------
*/
try {
    $totalSales = reportSum(
        $pdo,
        "SELECT COALESCE(SUM(total_amount), 0)
         FROM invoices
         WHERE created_at >= ? AND created_at < ?",
        $periodParams
    );

    $totalPurchases = reportSum(
        $pdo,
        "SELECT COALESCE(SUM(total_amount), 0)
         FROM purchase_invoices
         WHERE created_at >= ? AND created_at < ?",
        $periodParams
    );

    $totalExpenses = reportSum(
        $pdo,
        "SELECT COALESCE(SUM(amount), 0)
         FROM expenses
         WHERE expense_date >= ? AND expense_date <= ?",
        [$startDate, $endDate]
    );

    $customerStats = reportFetch(
        $pdo,
        "SELECT
            COALESCE(SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END), 0) AS debts,
            COALESCE(SUM(CASE WHEN balance < 0 THEN -balance ELSE 0 END), 0) AS credits
         FROM customers"
    )[0];

    $totalCustomerDebts = (float)$customerStats['debts'];
    $totalCustomerCredits = (float)$customerStats['credits'];

    $supplierStats = reportFetch(
        $pdo,
        "SELECT
            COALESCE(SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END), 0) AS debts,
            COALESCE(SUM(CASE WHEN balance < 0 THEN -balance ELSE 0 END), 0) AS credits
         FROM suppliers"
    )[0];

    $totalSupplierDebts = (float)$supplierStats['debts'];
    $totalSupplierCredits = (float)$supplierStats['credits'];

    $costStats = reportFetch(
        $pdo,
        "SELECT
            COALESCE(SUM(ii.quantity * p.purchase_price), 0) AS cost,
            COALESCE(SUM(
                CASE WHEN p.id IS NULL OR p.purchase_price IS NULL
                THEN 1 ELSE 0 END
            ), 0) AS missing
         FROM invoice_items ii
         INNER JOIN invoices i ON i.id = ii.invoice_id
         LEFT JOIN products p ON p.id = ii.product_id
         WHERE i.created_at >= ? AND i.created_at < ?",
        $periodParams
    )[0];

    $estimatedCost = (float)$costStats['cost'];
    $missingCostItems = (int)$costStats['missing'];

    if ($missingCostItems === 0) {
        $estimatedProfit = $totalSales - $estimatedCost - $totalExpenses;
    }

    /*
     * بيانات الرسم: 12 شهرًا حتى شهر نهاية الفترة.
     */
    $chartEnd = (new DateTimeImmutable($endDate))
        ->modify('first day of this month')
        ->setTime(0, 0)
        ->modify('+1 month');

    $chartStart = $chartEnd->modify('-12 months');

    $chartParams = [
        $chartStart->format('Y-m-d H:i:s'),
        $chartEnd->format('Y-m-d H:i:s'),
    ];

    $salesMonthly = reportFetch(
        $pdo,
        "SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key,
                SUM(total_amount) AS total
         FROM invoices
         WHERE created_at >= ? AND created_at < ?
         GROUP BY DATE_FORMAT(created_at, '%Y-%m')",
        $chartParams
    );

    $purchasesMonthly = reportFetch(
        $pdo,
        "SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key,
                SUM(total_amount) AS total
         FROM purchase_invoices
         WHERE created_at >= ? AND created_at < ?
         GROUP BY DATE_FORMAT(created_at, '%Y-%m')",
        $chartParams
    );

    $salesMap = array_column($salesMonthly, 'total', 'month_key');
    $purchasesMap = array_column($purchasesMonthly, 'total', 'month_key');

    for ($index = 0; $index < 12; $index++) {
        $monthKey = $chartStart
            ->modify("+{$index} months")
            ->format('Y-m');

        $chartLabels[] = $monthKey;
        $chartSales[] = (float)($salesMap[$monthKey] ?? 0);
        $chartPurchases[] = (float)($purchasesMap[$monthKey] ?? 0);
    }

    switch ($selectedReport) {
        case 'sales':
            $columns = [
                'رقم الفاتورة', 'الزبون', 'الأصناف',
                'الإجمالي', 'المدفوع عند الإنشاء',
                'صافي الفاتورة', 'التاريخ', 'ملاحظات',
            ];

            $data = reportFetch(
                $pdo,
                "SELECT i.*, c.name AS customer_name,
                    (
                        SELECT GROUP_CONCAT(
                            CONCAT(ii.product_name, ' × ', ii.quantity)
                            SEPARATOR '، '
                        )
                        FROM invoice_items ii
                        WHERE ii.invoice_id = i.id
                    ) AS items
                 FROM invoices i
                 LEFT JOIN customers c ON c.id = i.customer_id
                 WHERE i.created_at >= ? AND i.created_at < ?
                 ORDER BY i.created_at DESC, i.id DESC",
                $periodParams
            );

            foreach ($data as $item) {
                $rows[] = [
                    $item['invoice_number'],
                    $item['customer_name'] ?? 'نقدي',
                    $item['items'] ?? '',
                    reportMoney($item['total_amount'], $currency),
                    reportMoney($item['paid_amount'], $currency),
                    reportMoney(
                        (float)$item['total_amount'] - (float)$item['paid_amount'],
                        $currency
                    ),
                    $item['created_at'],
                    $item['notes'] ?? '',
                ];
            }

            $reportSummary = [
                'إجمالي المبيعات' => reportMoney($totalSales, $currency),
                'عدد الفواتير' => count($data),
            ];

            $reportNote = 'المدفوع هو المسجل عند إنشاء الفاتورة. '
                . 'الدفعات اللاحقة بالصندوق قد لا تحدّث حقول الفاتورة. '
                . 'صافي الفاتورة ليس رصيد الزبون التراكمي.';
            break;

        case 'purchases':
            $columns = [
                'رقم الفاتورة', 'المورد', 'الأصناف',
                'الإجمالي', 'المدفوع عند الإنشاء',
                'صافي أثر الفاتورة', 'التاريخ', 'ملاحظات',
            ];

            $data = reportFetch(
                $pdo,
                "SELECT pi.*, s.name AS supplier_name,
                    (
                        SELECT GROUP_CONCAT(
                            CONCAT(pii.product_name, ' × ', pii.quantity)
                            SEPARATOR '، '
                        )
                        FROM purchase_invoice_items pii
                        WHERE pii.purchase_invoice_id = pi.id
                    ) AS items
                 FROM purchase_invoices pi
                 LEFT JOIN suppliers s ON s.id = pi.supplier_id
                 WHERE pi.created_at >= ? AND pi.created_at < ?
                 ORDER BY pi.created_at DESC, pi.id DESC",
                $periodParams
            );

            foreach ($data as $item) {
                $rows[] = [
                    $item['purchase_number'],
                    $item['supplier_name'] ?? 'مورد غير موجود',
                    $item['items'] ?? '',
                    reportMoney($item['total_amount'], $currency),
                    reportMoney($item['paid_amount'], $currency),
                    reportMoney(
                        (float)$item['total_amount'] - (float)$item['paid_amount'],
                        $currency
                    ),
                    $item['created_at'],
                    $item['notes'] ?? '',
                ];
            }

            $reportSummary = [
                'إجمالي المشتريات' => reportMoney($totalPurchases, $currency),
                'عدد الفواتير' => count($data),
            ];

            $reportNote = 'صافي أثر الفاتورة = الإجمالي − المدفوع عند الإنشاء. '
                . 'رصيد المورد التراكمي موجود في تقرير حسابات الموردين.';
            break;

        case 'profits':
            $columns = ['البيان', 'القيمة'];

            $rows = [
                ['إجمالي المبيعات', reportMoney($totalSales, $currency)],
                [
                    'تكلفة المبيعات المقدرة للأسعار الحالية المتاحة',
                    reportMoney($estimatedCost, $currency),
                ],
                ['المصروفات المسجلة', reportMoney($totalExpenses, $currency)],
                ['بنود البيع ذات التكلفة غير المتاحة', $missingCostItems],
                [
                    'صافي الربح / الخسارة المقدر',
                    $estimatedProfit === null
                        ? 'غير متاح: توجد تكلفة ناقصة'
                        : reportMoney($estimatedProfit, $currency),
                ],
            ];

            $reportNote = 'التكلفة مبنية على سعر الشراء الحالي وليست تكلفة تاريخية محفوظة وقت البيع. '
                . 'لا يُخصم إجمالي المشتريات بدل تكلفة البضاعة المباعة. '
                . 'المصروفات تشمل فقط جدول expenses.';
            break;

        case 'treasury':
            $columns = [
                'التاريخ', 'النوع', 'المبلغ', 'البيان', 'الرصيد بعد الحركة',
            ];

            $opening = reportSum(
                $pdo,
                "SELECT COALESCE(SUM(
                    CASE WHEN type = 'in' THEN amount ELSE -amount END
                 ), 0)
                 FROM cashbox
                 WHERE created_at < ?",
                [$from]
            );

            $data = reportFetch(
                $pdo,
                "SELECT * FROM cashbox
                 WHERE created_at >= ? AND created_at < ?
                 ORDER BY created_at ASC, id ASC",
                $periodParams
            );

            $runningBalance = $opening;
            $cashIn = 0;
            $cashOut = 0;

            foreach ($data as $item) {
                $amount = (float)$item['amount'];
                $isIn = $item['type'] === 'in';

                $runningBalance += $isIn ? $amount : -$amount;

                if ($isIn) {
                    $cashIn += $amount;
                } else {
                    $cashOut += $amount;
                }

                $rows[] = [
                    $item['created_at'],
                    $isIn ? 'قبض' : 'صرف',
                    reportMoney($amount, $currency),
                    $item['description'] ?? '',
                    reportMoney($runningBalance, $currency),
                ];
            }

            $reportSummary = [
                'الرصيد المرحل قبل الفترة' => reportMoney($opening, $currency),
                'المقبوضات' => reportMoney($cashIn, $currency),
                'المدفوعات' => reportMoney($cashOut, $currency),
                'رصيد نهاية الفترة' => reportMoney($runningBalance, $currency),
            ];

            $reportNote = 'الترحيل محسوب من الحركات السابقة في cashbox. '
                . 'لا تضاف الأرصدة الشهرية مرة أخرى لتجنب التكرار. '
                . 'أي رصيد افتتاحي غير ممثل في الحركات لا يدخل في الحساب.';
            break;

        case 'customers_debt':
            $columns = ['الزبون', 'الهاتف', 'العنوان', 'الحالة', 'المبلغ'];

            $data = reportFetch(
                $pdo,
                "SELECT name, phone, address, balance
                 FROM customers
                 ORDER BY balance DESC, name ASC"
            );

            foreach ($data as $item) {
                $balance = (float)$item['balance'];

                $rows[] = [
                    $item['name'],
                    $item['phone'] ?? '',
                    $item['address'] ?? '',
                    $balance > 0 ? 'على الزبون'
                        : ($balance < 0 ? 'للزبون رصيد لدينا' : 'لا يوجد رصيد'),
                    reportMoney(abs($balance), $currency),
                ];
            }

            $reportSummary = [
                'ديون الزبائن' => reportMoney($totalCustomerDebts, $currency),
                'أرصدة لصالح الزبائن' => reportMoney($totalCustomerCredits, $currency),
            ];

            $reportNote = 'الأرصدة الحالية من customers.balance. '
                . 'فلتر التاريخ لا يعيد بناء رصيد تاريخي.';
            break;

        case 'suppliers_debt':
            $columns = ['المورد', 'الهاتف', 'العنوان', 'الحالة', 'المبلغ'];

            $data = reportFetch(
                $pdo,
                "SELECT name, phone, address, balance
                 FROM suppliers
                 ORDER BY balance DESC, name ASC"
            );

            foreach ($data as $item) {
                $balance = (float)$item['balance'];

                $rows[] = [
                    $item['name'],
                    $item['phone'] ?? '',
                    $item['address'] ?? '',
                    $balance > 0 ? 'للمورد مستحقات'
                        : ($balance < 0 ? 'لنا عند المورد رصيد' : 'لا يوجد رصيد'),
                    reportMoney(abs($balance), $currency),
                ];
            }

            $reportSummary = [
                'مستحقات الموردين' => reportMoney($totalSupplierDebts, $currency),
                'أرصدة لنا لدى الموردين' => reportMoney($totalSupplierCredits, $currency),
            ];

            $reportNote = 'الأرصدة الحالية من suppliers.balance. '
                . 'الأرصدة السالبة تظهر كأموال لنا عند المورد.';
            break;

        case 'inventory':
            $columns = [
                'المنتج', 'SKU', 'التصنيف', 'الكمية',
                'سعر الشراء', 'سعر البيع',
                'قيمة الشراء', 'قيمة البيع', 'الحالة',
            ];

            $data = reportFetch(
                $pdo,
                "SELECT * FROM products ORDER BY quantity ASC, name ASC"
            );

            $inventoryCost = 0;
            $inventorySale = 0;

            foreach ($data as $item) {
                $quantity = (float)$item['quantity'];
                $costValue = $quantity * (float)$item['purchase_price'];
                $saleValue = $quantity * (float)$item['sale_price'];

                $inventoryCost += $costValue;
                $inventorySale += $saleValue;

                $rows[] = [
                    $item['name'],
                    $item['sku'] ?? '',
                    $item['category'] ?? '',
                    $item['quantity'],
                    reportMoney($item['purchase_price'], $currency),
                    reportMoney($item['sale_price'], $currency),
                    reportMoney($costValue, $currency),
                    reportMoney($saleValue, $currency),
                    $quantity <= 0 ? 'نافد / يحتاج مراجعة'
                        : ($quantity < 10 ? 'مخزون منخفض' : 'متوفر'),
                ];
            }

            $reportSummary = [
                'قيمة المخزون بسعر الشراء' => reportMoney($inventoryCost, $currency),
                'قيمة المخزون بسعر البيع' => reportMoney($inventorySale, $currency),
            ];

            $reportNote = 'يعرض المخزون الحالي، وليس مخزون نهاية الفترة.';
            break;

        case 'top_products':
            $columns = [
                'المنتج', 'الكمية المباعة', 'قيمة البيع',
                'التكلفة المقدرة', 'الربح المقدر قبل المصروفات',
            ];

            $data = reportFetch(
                $pdo,
                "SELECT
                    ii.product_id,
                    ii.product_name,
                    SUM(ii.quantity) AS sold_quantity,
                    SUM(ii.total_price) AS revenue,
                    SUM(ii.quantity * p.purchase_price) AS cost,
                    SUM(
                        CASE WHEN p.id IS NULL OR p.purchase_price IS NULL
                        THEN 1 ELSE 0 END
                    ) AS missing
                 FROM invoice_items ii
                 INNER JOIN invoices i ON i.id = ii.invoice_id
                 LEFT JOIN products p ON p.id = ii.product_id
                 WHERE i.created_at >= ? AND i.created_at < ?
                 GROUP BY ii.product_id, ii.product_name
                 ORDER BY sold_quantity DESC, revenue DESC",
                $periodParams
            );

            foreach ($data as $item) {
                $missing = (int)$item['missing'] > 0;

                $rows[] = [
                    $item['product_name'],
                    $item['sold_quantity'],
                    reportMoney($item['revenue'], $currency),
                    $missing ? 'غير متاحة' : reportMoney($item['cost'], $currency),
                    $missing ? 'غير متاح' : reportMoney(
                        (float)$item['revenue'] - (float)$item['cost'],
                        $currency
                    ),
                ];
            }

            $reportNote = 'الترتيب حسب الكمية. التكلفة بالأسعار الحالية، '
                . 'ولا يشمل ربح المنتج المصروفات أو توزيع خصم الفاتورة.';
            break;

        case 'expenses':
            $columns = ['عنوان المصروف', 'المبلغ', 'تاريخ المصروف', 'ملاحظات'];

            $data = reportFetch(
                $pdo,
                "SELECT title, amount, expense_date, notes
                 FROM expenses
                 WHERE expense_date >= ? AND expense_date <= ?
                 ORDER BY expense_date DESC, id DESC",
                [$startDate, $endDate]
            );

            foreach ($data as $item) {
                $rows[] = [
                    $item['title'],
                    reportMoney($item['amount'], $currency),
                    $item['expense_date'],
                    $item['notes'] ?? '',
                ];
            }

            $reportSummary = [
                'إجمالي المصروفات' => reportMoney($totalExpenses, $currency),
                'عدد السجلات' => count($data),
            ];

            $reportNote = 'التصفية حسب تاريخ المصروف expense_date.';
            break;
    }
} catch (PDOException $exception) {
    error_log('Reports error: ' . $exception->getMessage());

    $errorMessage = 'تعذر تحميل بيانات التقارير. '
        . 'تحقق من قاعدة البيانات والجداول والأعمدة المستخدمة.';

    $rows = [];
}

/*
|--------------------------------------------------------------------------
| تصدير CSV قبل إرسال أي HTML
|--------------------------------------------------------------------------
*/
if (($_GET['export'] ?? '') === 'csv') {
    if ($errorMessage !== '') {
        http_response_code(500);
        header('Content-Type: text/plain; charset=UTF-8');
        exit($errorMessage);
    }

    header('Content-Type: text/csv; charset=UTF-8');
    header(
        'Content-Disposition: attachment; filename="report-'
        . $selectedReport . '-' . $startDate . '-' . $endDate . '.csv"'
    );

    $stream = fopen('php://output', 'w');

    fwrite($stream, "\xEF\xBB\xBF");

    fputcsv($stream, [$reports[$selectedReport]['title']]);

    fputcsv($stream, [
        $reports[$selectedReport]['current']
            ? 'بيانات حالية'
            : 'الفترة: ' . $startDate . ' إلى ' . $endDate,
    ]);

    fputcsv($stream, ['العملة', reportCsvCell($currency)]);

    if ($currencyWarning !== '') {
        fputcsv($stream, [$currencyWarning]);
    }

    foreach ($reportSummary as $label => $value) {
        fputcsv($stream, [
            reportCsvCell($label),
            reportCsvCell($value),
        ]);
    }

    fputcsv($stream, [reportCsvCell($reportNote)]);
    fputcsv($stream, $columns);

    foreach ($rows as $row) {
        fputcsv($stream, array_map('reportCsvCell', $row));
    }

    fclose($stream);
    exit;
}

/*
|--------------------------------------------------------------------------
| واجهة النظام
|--------------------------------------------------------------------------
*/
require_once 'includes/header.php';

$jsonFlags = JSON_UNESCAPED_UNICODE
    | JSON_HEX_TAG
    | JSON_HEX_AMP
    | JSON_HEX_APOS
    | JSON_HEX_QUOT;
?>

<style>
.reports-page {
    direction: rtl;
    color: #334155;
}

.reports-header,
.reports-panel {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 22px;
    box-shadow: 0 2px 10px rgba(0,0,0,.04);
}

.reports-header,
.reports-panel-head,
.reports-actions,
.reports-filter {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
}

.reports-header h2,
.reports-panel h3 {
    margin: 0 0 7px;
    color: #0f172a;
}

.reports-muted {
    color: #64748b;
    font-size: 13px;
    line-height: 1.8;
}

.reports-filter label {
    font-size: 13px;
}

.reports-filter input,
.reports-search {
    padding: 9px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    background: #fff;
    font: inherit;
}

.reports-btn {
    display: inline-block;
    padding: 9px 14px;
    border: 1px solid #2563eb;
    border-radius: 8px;
    background: #2563eb;
    color: #fff;
    text-decoration: none;
    cursor: pointer;
    font: inherit;
    font-size: 13px;
}

.reports-btn.light {
    background: #fff;
    color: #2563eb;
}

.reports-btn.green {
    background: #059669;
    border-color: #059669;
}

.reports-kpis {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 16px;
    margin-bottom: 22px;
}

.reports-kpi {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 20px;
}

.reports-kpi strong {
    display: block;
    margin: 10px 0;
    font-size: 23px;
    color: #2563eb;
}

.reports-cards {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 16px;
}

.reports-card {
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 18px;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.reports-card.selected {
    border-color: #2563eb;
    background: #eff6ff;
}

.reports-card h4 {
    margin: 0;
    color: #0f172a;
}

.reports-card p {
    margin: 0;
    flex: 1;
}

.reports-card-icon {
    font-size: 26px;
}

.reports-card-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.reports-note {
    background: #fffbeb;
    border: 1px solid #fde68a;
    border-radius: 9px;
    padding: 12px;
    margin: 15px 0;
    font-size: 13px;
    line-height: 1.9;
}

.reports-error {
    background: #fef2f2;
    border: 1px solid #fecaca;
    color: #b91c1c;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 20px;
}

.reports-summary {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin: 15px 0;
}

.reports-summary span {
    background: #f1f5f9;
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 13px;
}

.reports-table-wrap {
    overflow-x: auto;
    max-height: 650px;
}

.reports-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.reports-table th,
.reports-table td {
    padding: 12px;
    text-align: right;
    border-bottom: 1px solid #e2e8f0;
    vertical-align: top;
}

.reports-table th {
    background: #f8fafc;
    position: sticky;
    top: 0;
    white-space: nowrap;
}

.reports-table tbody tr:hover {
    background: #f8fafc;
}

.reports-page [hidden] {
    display: none !important;
}

.reports-chart-box {
    height: 370px;
    position: relative;
}

.reports-chart-table {
    margin-top: 18px;
}

@media (max-width: 1000px) {
    .reports-kpis,
    .reports-cards {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 600px) {
    .reports-kpis,
    .reports-cards {
        grid-template-columns: 1fr;
    }

    .reports-header,
    .reports-panel {
        padding: 14px;
    }

    .reports-filter {
        width: 100%;
        align-items: stretch;
    }

    .reports-filter input {
        max-width: 100%;
    }
}

@media print {
    body * {
        visibility: hidden;
    }

    #selectedReport,
    #selectedReport * {
        visibility: visible;
    }

    #selectedReport {
        position: absolute;
        top: 0;
        right: 0;
        width: 100%;
        box-sizing: border-box;
        border: 0;
        box-shadow: none;
        padding: 0;
    }

    #selectedReport .no-print {
        display: none !important;
    }

    #selectedReport .reports-table-wrap {
        max-height: none;
        overflow: visible;
    }

    #selectedReport .reports-table th {
        position: static;
    }

    #selectedReport .reports-table thead {
        display: table-header-group;
    }

    #selectedReport .reports-table tr {
        break-inside: avoid;
    }
}
</style>

<div class="reports-page">

    <div class="reports-header">
        <div>
            <h2>مركز التقارير والتحليلات</h2>

            <div class="reports-muted">
                بيانات المبيعات والمشتريات والمخزون والحسابات.
                العملة:
                <?= reportEscape($currency) ?>
            </div>
        </div>

        <form method="get" class="reports-filter">
            <input
                type="hidden"
                name="report"
                value="<?= reportEscape($selectedReport) ?>"
            >

            <label for="reportStart">من:</label>

            <input
                type="date"
                id="reportStart"
                name="start_date"
                required
                value="<?= reportEscape($startDate) ?>"
            >

            <label for="reportEnd">إلى:</label>

            <input
                type="date"
                id="reportEnd"
                name="end_date"
                required
                value="<?= reportEscape($endDate) ?>"
            >

            <button type="submit" class="reports-btn">
                تصفية
            </button>
        </form>
    </div>

    <?php if ($currencyWarning !== ''): ?>
        <div class="reports-note">
            <?= reportEscape($currencyWarning) ?>
        </div>
    <?php endif; ?>

    <?php if ($errorMessage !== ''): ?>
        <div class="reports-error">
            <?= reportEscape($errorMessage) ?>
        </div>
    <?php else: ?>
        <div class="reports-kpis">
            <div class="reports-kpi">
                <span>إجمالي المبيعات</span>

                <strong>
                    <?= reportEscape(reportMoney($totalSales, $currency)) ?>
                </strong>

                <div class="reports-muted">خلال الفترة المحددة</div>
            </div>

            <div class="reports-kpi">
                <span>إجمالي المشتريات</span>

                <strong style="color:#0891b2;">
                    <?= reportEscape(reportMoney($totalPurchases, $currency)) ?>
                </strong>

                <div class="reports-muted">خلال الفترة المحددة</div>
            </div>

            <div class="reports-kpi">
                <span>صافي الربح / الخسارة المقدر</span>

                <strong
                    style="color:<?= $estimatedProfit !== null && $estimatedProfit < 0
                        ? '#dc2626' : '#059669' ?>;"
                >
                    <?= $estimatedProfit === null
                        ? 'تكلفة ناقصة'
                        : reportEscape(reportMoney($estimatedProfit, $currency)) ?>
                </strong>

                <div class="reports-muted">
                    بأسعار الشراء الحالية وبعد المصروفات المسجلة
                </div>
            </div>

            <div class="reports-kpi">
                <span>ديون الزبائن الحالية</span>

                <strong style="color:#dc2626;">
                    <?= reportEscape(reportMoney($totalCustomerDebts, $currency)) ?>
                </strong>

                <div class="reports-muted">
                    أرصدة لصالح الزبائن:
                    <?= reportEscape(reportMoney($totalCustomerCredits, $currency)) ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="reports-panel">
        <h3>دليل التقارير السريعة</h3>

        <p class="reports-muted">
            اختر تقريرًا لعرضه، أو صدّره إلى CSV، أو اطبعه.
        </p>

        <div class="reports-cards">
            <?php foreach ($reports as $id => $report): ?>
                <div
                    class="reports-card <?= $id === $selectedReport ? 'selected' : '' ?>"
                >
                    <div class="reports-card-icon">
                        <?= reportEscape($report['icon']) ?>
                    </div>

                    <h4><?= reportEscape($report['title']) ?></h4>

                    <p class="reports-muted">
                        <?= reportEscape($report['desc']) ?>
                    </p>

                    <div class="reports-muted">
                        <?= $report['current']
                            ? 'بيانات حالية'
                            : 'حسب الفترة المحددة' ?>
                    </div>

                    <div class="reports-card-actions">
                        <a
                            class="reports-btn"
                            href="<?= reportEscape(reportUrl(
                                $id,
                                $startDate,
                                $endDate
                            )) ?>#selectedReport"
                        >
                            عرض التقرير
                        </a>

                        <a
                            class="reports-btn light"
                            href="<?= reportEscape(reportUrl(
                                $id,
                                $startDate,
                                $endDate,
                                ['export' => 'csv']
                            )) ?>"
                        >
                            تصدير CSV
                        </a>

                        <a
                            class="reports-btn light"
                            href="<?= reportEscape(reportUrl(
                                $id,
                                $startDate,
                                $endDate,
                                ['print' => '1']
                            )) ?>#selectedReport"
                        >
                            طباعة
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if ($errorMessage === ''): ?>
        <div class="reports-panel" id="selectedReport">
            <div class="reports-panel-head">
                <div>
                    <h3>
                        <?= reportEscape($reports[$selectedReport]['title']) ?>
                    </h3>

                    <div class="reports-muted">
                        <?php if ($reports[$selectedReport]['current']): ?>
                            بيانات حالية وقت فتح التقرير
                        <?php else: ?>
                            الفترة:
                            <?= reportEscape($startDate) ?>
                            إلى
                            <?= reportEscape($endDate) ?>
                        <?php endif; ?>

                        — العملة:
                        <?= reportEscape($currency) ?>
                    </div>
                </div>

                <div class="reports-actions no-print">
                    <a
                        class="reports-btn green"
                        href="<?= reportEscape(reportUrl(
                            $selectedReport,
                            $startDate,
                            $endDate,
                            ['export' => 'csv']
                        )) ?>"
                    >
                        تصدير CSV
                    </a>

                    <button
                        type="button"
                        class="reports-btn light"
                        id="printReport"
                    >
                        طباعة التقرير
                    </button>
                </div>
            </div>

            <div class="reports-note">
                <?= reportEscape($reportNote) ?>

                <?php if ($currencyWarning !== ''): ?>
                    <br>
                    <?= reportEscape($currencyWarning) ?>
                <?php endif; ?>
            </div>

            <?php if ($reportSummary): ?>
                <div class="reports-summary">
                    <?php foreach ($reportSummary as $label => $value): ?>
                        <span>
                            <?= reportEscape($label) ?>:
                            <?= reportEscape($value) ?>
                        </span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="reports-actions no-print" style="margin:15px 0;">
                <span class="reports-muted">
                    عدد السجلات:
                    <?= count($rows) ?>
                </span>

                <input
                    type="search"
                    class="reports-search"
                    id="reportSearch"
                    placeholder="بحث في التقرير..."
                    aria-label="بحث في التقرير"
                >
            </div>

            <div class="reports-table-wrap">
                <table class="reports-table" id="reportTable">
                    <thead>
                        <tr>
                            <?php foreach ($columns as $column): ?>
                                <th><?= reportEscape($column) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (!$rows): ?>
                            <tr>
                                <td colspan="<?= max(1, count($columns)) ?>">
                                    لا توجد بيانات لهذا التقرير.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($rows as $row): ?>
                                <tr data-report-row>
                                    <?php foreach ($row as $cell): ?>
                                        <td><?= reportEscape($cell) ?></td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <p
                id="noSearchResults"
                class="reports-muted no-print"
                hidden
            >
                لا توجد نتائج مطابقة للبحث.
            </p>
        </div>

        <div class="reports-panel">
            <div class="reports-panel-head">
                <div>
                    <h3>التحليل البياني للمبيعات والمشتريات</h3>

                    <p class="reports-muted">
                        آخر 12 شهرًا حتى شهر نهاية الفترة المختارة.
                        المشتريات ليست صافي الربح.
                    </p>
                </div>

                <div class="reports-actions">
                    <button
                        type="button"
                        class="reports-btn"
                        id="chartLine"
                    >
                        رسم خطي
                    </button>

                    <button
                        type="button"
                        class="reports-btn light"
                        id="chartBar"
                    >
                        أعمدة
                    </button>
                </div>
            </div>

            <div class="reports-chart-box" id="chartBox">
                <canvas id="salesChart"></canvas>
            </div>

            <p class="reports-muted" id="chartUnavailable" hidden>
                تعذر تحميل مكتبة الرسم.
                الأرقام الفعلية متاحة في الجدول التالي.
            </p>

            <div class="reports-table-wrap reports-chart-table">
                <table class="reports-table">
                    <thead>
                        <tr>
                            <th>الشهر</th>
                            <th>المبيعات</th>
                            <th>المشتريات</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($chartLabels as $index => $month): ?>
                            <tr>
                                <td><?= reportEscape($month) ?></td>

                                <td>
                                    <?= reportEscape(reportMoney(
                                        $chartSales[$index],
                                        $currency
                                    )) ?>
                                </td>

                                <td>
                                    <?= reportEscape(reportMoney(
                                        $chartPurchases[$index],
                                        $currency
                                    )) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.8/dist/chart.umd.min.js"></script>

<script>
(function () {
    'use strict';

    const search = document.getElementById('reportSearch');
    const noResults = document.getElementById('noSearchResults');

    if (search) {
        search.addEventListener('input', function () {
            const keyword = this.value.trim().toLocaleLowerCase();
            let visible = 0;

            document.querySelectorAll('[data-report-row]').forEach(function (row) {
                const matches = row.textContent
                    .toLocaleLowerCase()
                    .includes(keyword);

                row.hidden = !matches;

                if (matches) {
                    visible++;
                }
            });

            if (noResults) {
                noResults.hidden = visible > 0 || keyword === '';
            }
        });
    }

    const printButton = document.getElementById('printReport');

    if (printButton) {
        printButton.addEventListener('click', function () {
            window.print();
        });
    }

    const canvas = document.getElementById('salesChart');

    const labels = <?= json_encode($chartLabels, $jsonFlags) ?>;
    const sales = <?= json_encode($chartSales, $jsonFlags) ?>;
    const purchases = <?= json_encode($chartPurchases, $jsonFlags) ?>;

    // نفس العملة التي تمت قراءتها من جدول settings.
    const currency = <?= json_encode($currency, $jsonFlags) ?>;

    let chart = null;

    function drawChart(type) {
        if (!canvas || typeof Chart === 'undefined') {
            return;
        }

        if (chart) {
            chart.destroy();
        }

        chart = new Chart(canvas, {
            type: type,
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'المبيعات (' + currency + ')',
                        data: sales,
                        borderColor: '#2563eb',
                        backgroundColor: type === 'bar'
                            ? 'rgba(37,99,235,.7)'
                            : 'rgba(37,99,235,.08)',
                        borderWidth: 2,
                        fill: type === 'line',
                        tension: 0.3
                    },
                    {
                        label: 'المشتريات (' + currency + ')',
                        data: purchases,
                        borderColor: '#0891b2',
                        backgroundColor: type === 'bar'
                            ? 'rgba(8,145,178,.7)'
                            : 'rgba(8,145,178,.08)',
                        borderWidth: 2,
                        fill: type === 'line',
                        tension: 0.3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        rtl: true
                    },
                    tooltip: {
                        rtl: true,
                        callbacks: {
                            label: function (context) {
                                return context.dataset.label + ': '
                                    + Number(context.parsed.y).toLocaleString(
                                        undefined,
                                        {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        }
                                    )
                                    + ' ' + currency;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function (value) {
                                return Number(value).toLocaleString()
                                    + ' ' + currency;
                            }
                        }
                    }
                }
            }
        });
    }

    if (canvas) {
        if (typeof Chart === 'undefined') {
            document.getElementById('chartBox').hidden = true;
            document.getElementById('chartUnavailable').hidden = false;
        } else {
            drawChart('line');
        }
    }

    const lineButton = document.getElementById('chartLine');
    const barButton = document.getElementById('chartBar');

    if (lineButton) {
        lineButton.addEventListener('click', function () {
            drawChart('line');
        });
    }

    if (barButton) {
        barButton.addEventListener('click', function () {
            drawChart('bar');
        });
    }

    <?php if (($_GET['print'] ?? '') === '1' && $errorMessage === ''): ?>
    window.addEventListener('load', function () {
        window.print();
    });
    <?php endif; ?>
})();
</script>

<?php require_once 'includes/footer.php'; ?>